package com.ust.pom;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.base.BaseUI;


public class guruTour extends BaseUI{

	WebDriver driver;
	
	/*****************  Page factory initialization  *****************/
	
	public guruTour(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	/*******************   Locator values  ************************/
	
	@FindBy(name="userName")
	WebElement userName;
	
	@FindBy(name="password")
	WebElement password;
	
	@FindBy(name="submit")
	WebElement loginSubmitbutton;
	
	@FindBy(xpath="//a[text()='Flights' ]")
	WebElement Flightclick;
	
	@FindBy(xpath="//input[@value='roundtrip']")
	WebElement roundwaytrip;
	
	@FindBy(xpath="//select[@name=\"passCount\"] /option[3]")
	WebElement passengerNos;
	
	@FindBy(xpath="//select[@name=\"fromPort\"] /option[4]")
	WebElement departingfrom;
	
	@FindBy(xpath="//select[@name=\"fromMonth\"] /option[5]")
	WebElement fromMonth;
	
	@FindBy(xpath="//select[@name=\"fromDay\"] /option[10]")
	WebElement fromDay;
	
	@FindBy(xpath="//select[@name='toPort']/option[3]")
	WebElement arrival;
	
	@FindBy(xpath="//select[@name='toMonth']/option[3]")
	WebElement returningMonth;
	
	@FindBy(xpath="//select[@name='toDay']/option[10]")
	WebElement returningDay;
	
	@FindBy(xpath="//select[@name='airline']/option[3]")
	WebElement airlineselection;
	
	@FindBy(xpath="//input[@name='findFlights']")
	WebElement ContinuebuttonClick;
	
	@FindBy(xpath="//img[@src='images/home.gif']")
	WebElement backtohomebutton;
	
	
	/***************  Storing locator values as methods  ****************/
	
	public void userName(String username) {
		sendtext(userName,username );
	}
	
	public void password(String Password) {
		sendtext(password,Password );
	}
	
	public void loginSubmitbutton() {
		clickOn(loginSubmitbutton);
	}
	public void Flightclick() {
		clickOn(Flightclick);
	}
	public void roundwaytrip() {
		clickOn(roundwaytrip);
	}
	public void passengerNos() {
		clickOn(passengerNos);
	}
	public void departingfrom() {
		clickOn(departingfrom);
	}
	public void fromMonth() {
		clickOn(fromMonth);
	}
	public void fromDay() {
		clickOn(fromDay);
	}
	public void arrival() {
		clickOn(arrival);
	}
	public void returningMonth() {
		clickOn(returningMonth);
	}
	public void returningDay() {
		clickOn(returningDay);
	}
	public void airlineselection() {
		clickOn(airlineselection);
	}
	public void ContinuebuttonClick() {
		clickOn(ContinuebuttonClick);
	}
	public void backtohomebutton() {
		clickOn(backtohomebutton);
	}

	public String getTitle() {	
		return driver.getTitle();
	}
	
}