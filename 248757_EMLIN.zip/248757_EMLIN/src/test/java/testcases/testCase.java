package testcases;


import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ust.base.BaseUI;
import com.ust.pom.guruTour;
import com.ust.utilities.excelUtils;


public class testCase extends BaseUI {
	WebDriver driver;
	 guruTour commerce;
	 String[][] data;
	 
	
	 /************  This method is used for checking the functionality of the invoking the browsers ***************/
	
	@BeforeTest
	public void setup() {
		driver = invokebrowser();
		openBrowser("applicationURL");
	}
	
	/************  This method is used to call data from excel data sheet ***************/
	
	@DataProvider(name = "testData")
	public Object[][] testdata(){
		data= excelUtils.testdata();
		return data;
	}
	
	/************ This testcase is used to check validity of the url provided ***************/
	
	@Test(priority=1,dataProvider = "testData")
	public void loginClick(String name,String password1) {
		guruTour guru=new guruTour(driver);
		guru.userName(name);
		guru.password(password1);
		guru.loginSubmitbutton();
		
		String a=driver.getCurrentUrl();
		 SoftAssertions.assertSoftly(softAssertions -> {
		 softAssertions.assertThat(a.contains("https://demo.guru99.com/test/newtours/"));
		 });
	}
	
	/*************** 
	 * This method indicates the Number of passengers, departure and arrival 
	****************/
	
	@Test(priority=2)
	public void flightclick() {
		guruTour guru=new guruTour(driver);
		guru.Flightclick();
		guru.roundwaytrip();
		guru.passengerNos();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//select[@name=\"passCount\"] /option[3]")).isSelected());
        	});
		guru.departingfrom();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//select[@name=\"fromPort\"] /option[4]")).isSelected());
        	});
		guru.fromMonth();
		guru.fromDay();
		guru.arrival();
		guru.returningMonth();
		guru.returningDay();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//select[@name='toDay']/option[10]")).isSelected());
        	});
		guru.airlineselection();
		guru.ContinuebuttonClick();
		guru.backtohomebutton();
	}

}
