package ust.show.base;

import java.util.Collections;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.remote.CapabilityType;

public class BrowserConfig {
	static WebDriver driver;
	
	//Initializes and configures a Edge WebDriver instance with specific options like  disabling notifications.
	 
	public static WebDriver getBrowser() {
	
	EdgeOptions edgeOptions = new EdgeOptions();
	edgeOptions.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
	edgeOptions.addArguments("--guest");
	edgeOptions.setExperimentalOption("useAutomationExtension", false);
	edgeOptions.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
	WebDriver driver=new EdgeDriver(edgeOptions);
	driver.manage().window().maximize();
	return driver;

}
}
