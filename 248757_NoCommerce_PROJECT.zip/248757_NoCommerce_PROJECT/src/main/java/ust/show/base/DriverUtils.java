package ust.show.base;

import java.io.File;

import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import ust.show.utils.DateUtils;
import ust.show.utils.FileIO;


public class DriverUtils {
	private static WebDriver driver;
	public static Properties prop;
	public static String browserChoice;

	public static ExtentReports extent;
	public static ExtentTest logger;
	public static String timestamp = DateUtils.getTimeStamp();

	public DriverUtils() {
		prop = FileIO.initProperties();
	}

	/***************** invoke browser **************/
	public static WebDriver invokebrowser() {
		browserChoice = prop.getProperty("browserName");
		if (browserChoice.equalsIgnoreCase("edge")) {
			driver = BrowserConfig.getBrowser();
		}
		return driver;
	}

	/***************** open website url **************/
	public static void openBrowser(String websiteurl) {
		driver.get(prop.getProperty(websiteurl));
	}

	

	public static boolean isElementPresent(By locator, Duration timeout) {
		try {
			new WebDriverWait(driver, timeout).until(ExpectedConditions.presenceOfElementLocated(locator));
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	

	public static String getText(WebElement element) {
		String text = null;
		try {
			new WebDriverWait(driver, Duration.ofSeconds(30)).until(ExpectedConditions.visibilityOf(element));
			text = element.getText();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return text;
	}

	

	public static void sendtext(WebElement element, String text) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.visibilityOf(element));
			element.sendKeys(text);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void clickOn(WebElement element) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.visibilityOf(element));
			element.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void jsClick(WebElement element, WebDriver driver) throws InterruptedException {
		final JavascriptExecutor executor = (JavascriptExecutor) driver;
		((RemoteWebDriver) executor).executeScript("arguments[0].click();", element);
	}

	/************** For taking screenshot ****************/
	public static void takeScreenShot(String filePath) {
		try {
			File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(src, new File(filePath));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}


	
	
	public String getTextfromAlertandAccept() {
		String text = null;
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			text = alert.getText();
			alert.accept();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return text;
	}

	/******* Retrieving error msg *******/
	public static String rettext(WebElement element) {
		String text = null;
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.visibilityOf(element));
			text = element.getText();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return text;
	}

	
	
	public static String getSelectedOptionFromDropdown(WebElement element) {
		String text = null;
		try {
			new WebDriverWait(driver, Duration.ofSeconds(30)).until(ExpectedConditions.visibilityOf(element));
			Select s = new Select(element);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return text;
	}

	/******* wait for text *******/
	public static void waitForText(WebDriver driver, String text, By by, String timeoutMsg) throws Exception {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(10))
					.until(ExpectedConditions.textToBePresentInElementLocated(by, text));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	public static void mouseOver(By locator) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15))
					.until(ExpectedConditions.presenceOfElementLocated(locator));
			WebElement target = driver.findElement(locator);
			Actions actions = new Actions(driver);
			actions.moveToElement(target).perform();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void mousesOver(WebElement element) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(30)).until(ExpectedConditions.visibilityOf(element));
			Actions actions = new Actions(driver);
			actions.moveToElement(element).perform();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*********** ScrollDown *********/
	public static void ScrollDown() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		try {
			js.executeScript("window.scrollBy(0, 500)"); // Scroll down by 500 pixels vertically
		} catch (Exception e) {
			e.printStackTrace();
			// Handle the exception appropriately
		}
	}

	/*********** ScrollDown to particular element *********/
	public static void ScrollDownToElement() {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, 5000)");
	}

}

