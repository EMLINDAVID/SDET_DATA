package ust.show.utils;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

	/** This method reads test data from the first sheet of an Excel file  **/

	public class ExcelUtils {
	public static String[][] testdata1() {

		FileInputStream fis;
		XSSFWorkbook workbook = null;
		try {
			fis = new FileInputStream(System.getProperty("user.dir") + "\\TestExcel\\DataTest.xlsx");
			workbook = new XSSFWorkbook(fis);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		XSSFSheet sheet = workbook.getSheetAt(0);
		int rowCount = sheet.getPhysicalNumberOfRows();
		System.out.println("Total number of rows used in sheet: " + rowCount);
		int colCount = sheet.getRow(0).getPhysicalNumberOfCells();
		System.out.println("Total nummber of columns used in sheet: " + colCount);

		String[][] testdata1 = new String[rowCount][colCount];
		for (int i = 0; i < rowCount; i++) {
			for (int j = 0; j < colCount; j++) {
				testdata1[i][j] = sheet.getRow(i).getCell(j).getStringCellValue();
			}
		}
		return testdata1;

	}
	
	/** This method reads test data from the second sheet of an Excel file */
	
	public static String[][] testdata2() {
		
		FileInputStream fis;
		XSSFWorkbook workbook = null;
		try {
			fis = new FileInputStream(System.getProperty("user.dir") + "\\TestExcel\\DataTest.xlsx");
			workbook = new XSSFWorkbook(fis);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		XSSFSheet sheet = workbook.getSheetAt(1);
		int rowCount = sheet.getPhysicalNumberOfRows();
		System.out.println("Total number of rows used in sheet: " + rowCount);
		int colCount = sheet.getRow(0).getPhysicalNumberOfCells();
		System.out.println("Total nummber of columns used in sheet: " + colCount);

		String[][] testdata2 = new String[rowCount][colCount];
		DataFormatter df = new DataFormatter();
		for (int i = 0; i < rowCount; i++) {
			for (int j = 0; j < colCount; j++) {
				testdata2[i][j] = df.formatCellValue(sheet.getRow(i).getCell(j));
			}
		}
		return testdata2;
	}

}
