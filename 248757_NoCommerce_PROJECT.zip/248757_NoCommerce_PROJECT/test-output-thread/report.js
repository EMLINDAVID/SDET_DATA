$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"6df124cf-6be8-47bb-8f9c-5ea8e65e1a55","feature":"Login page feature","scenario":"Login page title","start":1695990286261,"group":1,"content":"","tags":"","end":1695990294481,"className":"passed"},{"id":"fb7e8008-321c-4a01-8f0e-06e9b0073600","feature":"Login page feature","scenario":"Login with correct credentials","start":1695990294495,"group":1,"content":"","tags":"","end":1695990300613,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});