package ust.show.base;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

public class BaseTest  extends DriverUtils{
	public static WebDriver driver;
	public static Properties prop;
	public static String browserChoice;

	@BeforeMethod
	public void setup()
	
	{
		driver=invokebrowser();
		openBrowser("appURL");
		
	}
 

}



