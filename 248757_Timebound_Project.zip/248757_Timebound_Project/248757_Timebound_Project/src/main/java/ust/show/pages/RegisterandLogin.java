//package ust.show.pages;
//
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.FindBy;
//import org.openqa.selenium.support.PageFactory;
//
//import ust.show.base.DriverUtils;
//
//	public class RegisterandLogin extends DriverUtils{
//		
//		WebDriver driver;
//		
//		
//		public RegisterandLogin(WebDriver driver) {
//			this.driver = driver;
//			PageFactory.initElements(driver, this);
//		}
//	
//		
//		@FindBy(xpath="/html/body/div[6]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")
//		 WebElement Login;
//			
//		 @FindBy(id="Email")
//		 WebElement Email;
//		 @FindBy(id="Password")
//		 WebElement Password;
//		 @FindBy(xpath="//button[@class='button-1 login-button']")
//		 WebElement submit;
//		 @FindBy(id="Email-error")
//		 WebElement errorm;
//		 @FindBy(id="FirstName")
//		 WebElement FirstName;
//		 @FindBy(id="LastName")
//		 WebElement LastName;
//		 @FindBy(id="Email")
//		 WebElement Email1;
//		 @FindBy(id="Password")
//		 WebElement Password1;
//		 @FindBy(id="ConfirmPassword")
//		 WebElement ConfirmPassword;
//		 @FindBy(id="register-button")
//		 WebElement register;
//		 @FindBy(xpath="//a[text()='Register']")
//		 WebElement reg1;
//		
//		 /*****	creating Methods to store the web elements *******/
//		 public String getTitle() {
//		 return driver.getTitle();
//		 }
//		 public void login() {
//		 clickOn(Login);
//		 }
//		 public void Email(String email) {
//		 sendtext(Email,email);
//		 }
//		 public void password(String uname) {
//		 sendtext(Password,uname);
//		 }
//		 public void submit() {
//		 clickOn(submit);
//		 }
//		 public String errorm()
//		 {	
//		 return rettext(errorm);
//		 }
//		 public void FirstName(String iname) {
//		 sendtext(FirstName,iname);
//		 }
//		 public void Email1(String iemail) {
//		 sendtext(Email,iemail);
//		 }
//		 public void Password1(String pwd) {
//		 sendtext(Password,pwd);
//		 }
//		 public void LastName(String lname) {
//		 sendtext(LastName,lname);
//		 }
//		 public void confirmPas(String cpas) {
//		 sendtext(ConfirmPassword,cpas);
//		 }
//		 public void Register() {
//		 clickOn(register);
//		 }
//		 public void Register1() {
//		 clickOn(reg1);
//		 }
//
//}