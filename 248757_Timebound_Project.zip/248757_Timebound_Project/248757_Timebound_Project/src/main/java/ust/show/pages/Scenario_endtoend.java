//package ust.show.pages;
//
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.FindBy;
//import org.openqa.selenium.support.PageFactory;
//import org.testng.annotations.Test;
//
//import ust.show.base.DriverUtils;
//
//
//
//public class Scenario_endtoend extends DriverUtils{
//	
//	WebDriver driver;
//	
//	
//	public Scenario_endtoend(WebDriver driver) {
//		this.driver = driver;
//		PageFactory.initElements(driver, this);
//	}
//	// WebElement declarations using @FindBy annotations
//    // ...
//	
//	@FindBy(xpath="(//a[text()='Apparel '])[1]")
//	private WebElement apparel;
//	@FindBy(xpath="(//a[text()='Clothing '])[1]")
//	private WebElement clothing;
//	@FindBy(xpath="//select[@aria-label='Select product sort order']")
//	private WebElement sortfilter;
//	@FindBy(xpath="(//select[@aria-label='Select product sort order'])/option[5]")
//	private WebElement sortselection;
//	@FindBy(xpath="(//a[@href='/levis-511-jeans'])[2]")
//	private WebElement productselection;
//	@FindBy(xpath="//button[@id=\"add-to-cart-button-30\"]")
//	private WebElement addtocart;
//	@FindBy(xpath="//span[@class=\"cart-label\"]")
//	private WebElement cartSelection;
//	@FindBy(xpath="//input[@id=\"termsofservice\"]")
//	private WebElement terms;
//	@FindBy(xpath="//button[@id=\"checkout\"]")
//	private WebElement checkout;
//	
//	
//	
//	
//	
//
//		public String getTitle() {
//			 return driver.getTitle();
//			 }
//			
//		 public void apparel() {
//			 mousesOver(apparel);
//		 }
//		 
//		 public void clothing() {
//			 clickOn(clothing);
//		 }
//		
//		 public void Sortfilter() {
//			 clickOn(sortfilter);
//		 }
//		 
//		 public void Sortoption() {
//			 clickOn(sortselection);
//		 }
//		 
//		 public void productselection() {
//			 clickOn(productselection);
//		 }
//		 
//		 public void addtocart() {
//			 clickOn(addtocart);
//		 }
//		 public void cartselection() {
//			 clickOn(cartSelection);
//		 }
//		 public void terms() {
//			 ScrollDown();
//			 clickOn(terms);
//		 }
//		 public void Checkout() {
//			 clickOn(checkout);
//		 }
//
//}
