//package ust.show.pages;
//
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.FindBy;
//import org.openqa.selenium.support.PageFactory;
//
//import ust.show.base.DriverUtils;
//
//public class SearchScenario extends DriverUtils{
//	
//	WebDriver driver;
//	
//	
//	public SearchScenario(WebDriver driver) {
//		this.driver = driver;
//		PageFactory.initElements(driver, this);
//	}
//	
//	@FindBy(xpath="//input[@class='search-box-text ui-autocomplete-input']")
//	WebElement search;
//	@FindBy(xpath="//button[@class='button-1 search-box-button']")
//	WebElement searchclickbutton;
//	@FindBy(xpath="//a[text()='Apple MacBook Pro 13-inch']")
//	WebElement product_apple;
//	@FindBy(xpath=" addtocart_id=add-to-cart-button-4")
//	WebElement addtocartsearch;
//	@FindBy(xpath="//span[@class=\"cart-label\"]")
//	private WebElement cartSelection;
//	@FindBy(xpath="//input[@id=\"termsofservice\"]")
//	private WebElement terms;
//	@FindBy(xpath="//button[@id=\"checkout\"]")
//	private WebElement checkout;
//	
//	public void searchbutton(String value) {
//	sendtext(search,value);
//	}
//	public void searchbuttonclick() {
//	clickOn(searchclickbutton);
//	}
//	
//	 public void product_appleclick() {
//	 clickOn(product_apple);
//	 }
//	public void addtocartsearchclick() {
//	clickOn(addtocartsearch);
//	}
//	public void cartselection() {
//		 clickOn(cartSelection);
//	 }
//	 public void terms() {
//		 ScrollDown();
//		 clickOn(terms);
//	 }
//	 public void Checkout() {
//		 clickOn(checkout);
//	 }
//}
