//package StepDefinitions;
//
//import org.openqa.selenium.WebDriver;
//import org.junit.Assert;
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//import ust.show.base.BrowserConfig;
//import ust.show.pages.RegisterandLogin;
//
//public class loginsteps{
//	public static String title;
//	public WebDriver driver1=BrowserConfig.getBrowser();
//	public RegisterandLogin p= new RegisterandLogin(driver1);
//	
//	
//	@Given("user is on login page")
//	public void user_is_on_login_page() {
//		driver1.get("https://demo.nopcommerce.com/");
//	}
//	@When("user gets the title of  page")
//	public void user_gets_the_title_of_page() {
//		title=p.getTitle();
//		System.out.println(title);
//	}
//	@Then("page title should be {string}")
//	public void page_title_should_be(String string) {
//		title=p.getTitle();
//		Assert.assertEquals(title,string);
//	}
//	@When("user clicks login")
//	public void user_clicks_login() {
//	    p.login();
//	}
//	@When("user enters email {string}")
//	public void user_enters_email(String mail) {
//	    p.Email(mail);
//	}
//	@When("user enters password {string}")
//	public void user_enters_password(String password) {
//		p.password(password);
//	   
//	}
//	@When("user clicks on submit button")
//	public void user_clicks_on_submit_button() {
//	   p.submit();
//	}
//}