package ust.show.tests;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import ust.show.base.BaseTest;

//import ust.show.pages.RegisterandLogin;
//import ust.show.pages.Scenario_endtoend;
//import ust.show.pages.SearchScenario;
import ust.show.pages.amazon;
import ust.show.utils.ExcelUtils;

//@Listeners(ust.show.utils.SampleListener.class)

public class TestCases extends BaseTest {

	String[][] data;

	//Provides test data for the test methods.

//	@DataProvider(name = "testdata1")
//	public Object[][] testdata1() {
//		data = ExcelUtils.testdata1();
//		return data;
//
//	}
//
//	//Provides test data for the test methods.
//	 
//	@DataProvider(name = "testdata2")
//	public Object[][] testdata2() {
//		data = ExcelUtils.testdata2();
//		return data;
//
//	}
	
	@DataProvider(name = "testdata3")
	public Object[][] testdata3() {
		data = ExcelUtils.testdata3();
		return data;

	}


//	//Test case for registering the user account.
//	 
//	@Test(priority = 1, dataProvider = "testdata1")
//	public void register(String firstname, String lastname, String mail, String password, String confPass) {
//		RegisterandLogin R = new RegisterandLogin(driver);
//		R.Register1();
//		R.FirstName(firstname);
//		R.LastName(lastname);
//		R.Email1(mail);
//		R.Password1(password);
//		R.confirmPas(confPass);
//		R.Register();
//	}
//
//	// Method to perform login and corresponding assertions
//	@Test(priority = 2, dataProvider = "testdata2")
//	public void loginTest(String email, String password) {
//		String a = "https://demo.nopcommerce.com/";
//		driver.get(a);
//		RegisterandLogin R = new RegisterandLogin(driver);
//		R.login();
//		R.Email(email);
//		R.password(password);
//		R.submit();
//		SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(a.contains("https://demo.nopcommerce.com/"));
//		});
//		String j = R.errorm();
//		if ((email.equals("IncorrectUser"))) {
//			SoftAssertions.assertSoftly(softAssertions -> {
//				softAssertions.assertThat(
//						j.equalsIgnoreCase("Login was not successful. Please correct the errors and try again.\r\n"
//								+ "No customer account found"));
//			});
//		} else if (password.equals(" ")) {
//			SoftAssertions.assertSoftly(softAssertions -> {
//				softAssertions.assertThat(
//						j.equalsIgnoreCase("Login was not successful. Please try again.\r\n"
//								+ "No customer account found"));
//			});
//		} else {
//			SoftAssertions.assertSoftly(softAssertions -> {
//				softAssertions.assertThat(a.contains("https://demo.nopcommerce.com/"));
//			});
//		}
//
//	}
//	@Test(priority = 3)
//	public void productSelect() throws InterruptedException {
//		String a = "https://demo.nopcommerce.com/";
//		driver.get(a);
//		Scenario_endtoend s = new Scenario_endtoend(driver);
//		s.apparel();
//		SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(a.contains("(//a[text()='Apparel '])[1]"));
//		});
//		s.clothing();
//		SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(driver.findElement(By.xpath("(//a[text()='Clothing '])[1]")).isSelected());
//		});
//		s.Sortfilter();
//		SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(a.contains("//select[@aria-label='Select product sort order']"));
//		});
//		s.Sortoption();
//		SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(driver.findElement(By.xpath("(//select[@aria-label='Select product sort order'])/option[5]")).isDisplayed());
//		});
//		Thread.sleep(2000);
//		s.productselection();
//		s.addtocart();
//		SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(driver.findElement(By.xpath("//button[@id=\"add-to-cart-button-30\"]")).isSelected());
//		});	
//		s.cartselection();
//		s.ScrollDown();
//		s.terms();
//
//		s.Checkout();
//		
//		
//	}
//	@Test(priority = 4)
//	public void Searchselect() throws InterruptedException {
//		String a = "https://demo.nopcommerce.com/";
//		driver.get(a);
//		SearchScenario p = new SearchScenario(driver);
//		p.searchbutton("Apple MacBook Pro 13-inch");
//		p.searchbuttonclick();
//		SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(a.contains("//button[@class='button-1 search-box-button']"));
//		});
//		p.product_appleclick();
//		SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(a.contains("(//button[@class='button-2 product-box-add-to-cart-button'])[2]"));
//		});
//		p.addtocartsearchclick();
//		Thread.sleep(2000);
//		p.cartselection();
//		p.terms();
//		p.Checkout();
//		
//	}
//	
	
	@Test(priority = 1,dataProvider = "testdata3")
	public void amazontest(String name) {
		amazon A = new amazon(driver);
		String a = "https://www.amazon.in/";
		driver.get(a);
		
//		A.searchh();
		A.searchenter(name);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(a.contains("//input[@id='twotabsearchtextbox']"));
		});
	}
	
}
