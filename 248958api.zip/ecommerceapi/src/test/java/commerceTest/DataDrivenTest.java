package commerceTest;

import org.testng.Assert;
import org.testng.annotations.Test;

import UserModel.Model;
import Utilities.DataProviders;
import endpoints.endpoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DataDrivenTest {

	@Test(priority = 1, dataProvider = "data", dataProviderClass = DataProviders.class)
	public void testPostUser(String id, String name, String price, String desc) {
		RestAssured.useRelaxedHTTPSValidation();
		Model user = new Model();

		user.setName(name);
		user.setPrice(price);
		user.setDescription(desc);

		Response response = endpoints.createUser(user);
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 201);
	}

	
	@Test(priority = 2, dataProvider = "ids", dataProviderClass = DataProviders.class)
	public void testGetUserById(String id) {
		// RestAssured.useRelaxedHTTPSValidation();
		Response response = endpoints.getUser(Integer.parseInt(id));
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);
	}
	
	 @Test(priority = 3, dataProvider = "ids", dataProviderClass = DataProviders.class)
	    public void testUpdateuserById(String id)
	   {
		   //RestAssured.useRelaxedHTTPSValidation();
		   Model  user=new Model ();
		   user.setName("has");
			user.setPrice("783");
			user.setDescription("kdsjbdkj");
		   Response response = endpoints.updateUser(Integer.parseInt(id),user);
	        response.then().log().all();
	        Assert.assertEquals(response.getStatusCode(),200);
	   }

	@Test(priority = 4, dataProvider = "ids", dataProviderClass = DataProviders.class)
	public void testDeleteById(String id) {
		Response response = endpoints.deleteUser(Integer.parseInt(id));
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 204);
	}

}
