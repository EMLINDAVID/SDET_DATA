package APItestcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import endpoints.UserEndPoints;
import io.restassured.response.Response;
import payload.UserModel;
import utilities.DataProviders;

public class DataDrivenTest {

	@Test(priority=1,dataProvider="data",dataProviderClass=DataProviders.class)
	
	public void testPostuser(String id,String title,String dueDate,String completed) {
		 UserModel user=new UserModel();
		 
		 user.setTitle(title);
		 user.setDueDate(dueDate);
		 user.setCompleted(completed);
		 user.setId(id);
		 
		 Response response=UserEndPoints.createUser(user);
		 response.then().log().all();
		 Assert.assertEquals(response.getStatusCode(),404);
	}
	
	@Test(priority=2,dataProvider="UserNames",dataProviderClass=DataProviders.class)
	
	public void testDeleteByUserName(String id)
	{
		 Response response=UserEndPoints.deleteUser(id);
		 response.then().log().all();
		 Assert.assertEquals(response.getStatusCode(), 404);
		
	}
	
}
