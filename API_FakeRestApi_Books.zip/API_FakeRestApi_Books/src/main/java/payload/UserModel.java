package payload;

public class UserModel {
	
	private int id;
	private String title;
	private String description;
	private String pageCount;
	private String excerpt;
	private String publishDate;
	public int getId() {
 return id;
	}
	public void setId(int id) {
 this.id = id;
	}
	public String getTitle() {
 return title;
	}
	public void setTitle(String title) {
 this.title = title;
	}
	public String getDescription() {
 return description;
	}
	public void setDescription(String description) {
 this.description = description;
	}
	public String getPageCount() {
 return pageCount;
	}
	public void setPageCount(String pageCount) {
 this.pageCount = pageCount;
	}
	public String getExcerpt() {
 return excerpt;
	}
	public void setExcerpt(String excerpt) {
 this.excerpt = excerpt;
	}
	public String getPublishDate() {
 return publishDate;
	}
	public void setPublishDate(String publishDate) {
 this.publishDate = publishDate;
	}
}