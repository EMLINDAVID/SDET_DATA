package APItestcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import endpoints.UserEndPoints;
import io.restassured.response.Response;
import payload.UserModel;
import utilities.DataProviders;

public class DataDrivenTest {

	@Test(priority=1,dataProvider="data",dataProviderClass=DataProviders.class)
	
	public void testPostuser(String titleID,String title,String description,String pagecount,String excerpt,String publishDate) {
		 UserModel user=new UserModel();
		 user.setTitle(titleID);
		 user.setTitle(title);
		 user.setDescription(description);
		 user.setPageCount(pagecount);
		 user.setExcerpt(excerpt);
		 user.setPublishDate(publishDate);
		 
		 Response response=UserEndPoints.createUser(user);
		 response.then().log().all();
		 Assert.assertEquals(response.getStatusCode(),400);
	}
	
	@Test(priority=2,dataProvider="UserNames",dataProviderClass=DataProviders.class)
	
	public void testDeleteByUserName(String id)
	{
		 Response response=UserEndPoints.deleteUser(id);
		 response.then().log().all();
		 Assert.assertEquals(response.getStatusCode(), 400);
		
	}
	
}
