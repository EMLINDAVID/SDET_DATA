package APItestcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import endpoints.UserEndPoints;
import io.restassured.response.Response;
import payload.UserModel;
import utilities.DataProviders;

public class DataDrivenTest {

	@Test(priority=1,dataProvider="data",dataProviderClass=DataProviders.class)
	
	public void testPostuser(String userID,String username,String firstname,String lastname,String email,String password,String phone) {
		 UserModel user=new UserModel();
		 user.setId(Integer.parseInt(userID));
		 user.setUsername(username);
		 user.setFirstname(firstname);
		 user.setLastname(lastname);
		 user.setEmail(email);
		 user.setPassword(password);
		 user.setPhone(phone);
		 
		 Response response=UserEndPoints.createUser(user);
		 response.then().log().all();
		 Assert.assertEquals(response.getStatusCode(),200);
	}
	
	@Test(priority=2,dataProvider="UserNames",dataProviderClass=DataProviders.class)
	
	public void testDeleteByUserName(String username)
	{
		 Response response=UserEndPoints.deleteUser(username);
		 response.then().log().all();
		 Assert.assertEquals(response.getStatusCode(), 200);
		
	}
	
}
