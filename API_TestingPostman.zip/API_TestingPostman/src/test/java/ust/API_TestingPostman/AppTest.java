package ust.API_TestingPostman;

import static org.junit.Assert.assertThat;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.response.Response;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void automateGetRequest()
    {
    	
    	int bookingId=given().
    			baseUri("http://restful-booker.herokuapp.com").
    			contentType("application/json").
    	when().
    		get("/booking").
    	then().
    		extract().
    		response().
    		path("bookingid[0]");
    	System.out.println(bookingId);
    	//assert using hamcrest	
    	assertThat(bookingId,equalTo(1810));
    	//assert using testNG
    	Assert.assertEquals(bookingId,1810);
    }
    
    @Test
    public void automaticPostRequest()
    {
    	String getToken;
    	String payload="{\n"+"\"username\":\"admin\",\n"+"\"password\":\"password123\"\n"+"}";
    	Response response =given().
    			baseUri("http://restful-booker.herokuapp.com").
    			contentType("application/json").
    			body(payload).
    		when().
        		post("/auth").
        	then().
        		log().all().
        		extract().
        		response();
    		getToken=response.jsonPath().getString("token");
    		System.out.println(getToken);
    
    }
    
	
}
