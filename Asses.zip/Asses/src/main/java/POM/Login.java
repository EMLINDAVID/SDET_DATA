package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.BaseUI;



public class Login extends BaseUI{

	WebDriver driver;
    Login login;
	public Login(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath="//header[@id=\"SiteHeader\"]/div[1]//span[@class='site-nav__icon-label small--hide']")
	WebElement account;
	
	@FindBy(xpath="//input[@id='CustomerEmail']")
	WebElement Email;
	
	@FindBy(xpath="//input[@id='CustomerPassword']")
	WebElement Password;
	
	@FindBy(xpath="//button[@class='btn btn--full']")
	WebElement SignIn;
	
	@FindBy(xpath="//*[@id=\"SiteHeader\"]/div[2]/div/ul/li[2]/a")
	WebElement MouseOver;
	
	@FindBy(xpath="//a[@class='site-nav__dropdown-link site-nav__dropdown-link--second-level']")
	WebElement DropSelect;
	
	@FindBy(xpath="//*[@id=\"CollectionSidebarFilterWrap\"]/div/form/div[1]/div/button/span/span[1]")
	WebElement availabilitySort;
	
	@FindBy(className="tag__checkbox")
	WebElement availabilitySortSelect;
	
	@FindBy(xpath="//*[@id=\"CollectionAjaxContent\"]/div/div/div[2]/div/div/div[2]/div[1]/div/a/div[2]/div[1]/div")
	WebElement productSelect;
	
	@FindBy(xpath="//*[@id=\"AddToCartForm-template--15564373229743__main-6759853228207\"]/div[2]/button")
	WebElement product;
	
	@FindBy(xpath="//*[@id=\"HeaderCart\"]/div/form/div[3]/div[3]")
	WebElement checkout;
	
	@FindBy(xpath="//*[@id=\"SiteHeader\"]/div[1]/div[1]/div/div[4]/div/div[2]/button")
	WebElement close;
	
	@FindBy(className="section-header__link")
	WebElement logout;
	
	
    
	public void  account() {
		clickOn(account);	
	}
	public void Email(String em) {
		sendtext(Email,em);
	}
	public void pass(String passw) {
		sendtext(Password,passw);
	}
	public void SignIn() {
		clickOn(SignIn);
	}
	public void MouseOver() {
		mouseOver(MouseOver);
	}
	public void DropSelect() {
		clickOn(DropSelect);
	}
	public void availabilitySort() {
		clickOn(availabilitySort);
	}
	public void availabilitySortSelect() {
		clickOn(availabilitySortSelect);
	}
	public void  productSelect() {
		clickOn(productSelect);
	}
	public void product() {
		clickOn(product);
	}
	public void checkoutcart() {
		clickOn(checkout);
	}
	public void close() {
		clickOn(close);
	}
	public void logout() {
		clickOn(logout);
	}
}
