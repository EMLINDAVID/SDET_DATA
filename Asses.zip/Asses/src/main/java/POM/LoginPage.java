package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
	public WebDriver driver;

	By emailid = By.xpath("//input[@id='CustomerEmail']");
	By password = By.xpath("//input[@id='CustomerPassword']");
	By signInButton = By.xpath("//button[@class='btn btn--full']");
//	By forgotPwdLink = By.xpath("//a[@title='Recover your forgotten password']");

	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

	public String getLoginPageTitle() {
		return driver.getTitle();
	}

//	public boolean isforgtpaswrdexists() {
//		return driver.findElement(forgotPwdLink).isDisplayed();
//	}

	public void sendusername(String uname) {
		driver.findElement(emailid).sendKeys(uname);
	}

	public void sendPassword(String paswrd) {
		driver.findElement(password).sendKeys(paswrd);
	}

	public void clickSubmit() {
		driver.findElement(signInButton).click();
	}




}
