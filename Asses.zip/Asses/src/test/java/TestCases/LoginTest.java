package TestCases;

import org.assertj.core.api.SoftAssertions;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Base.BaseUI;
import POM.Login;

import Utility.excelUtility;

@Listeners(Utility.SampleListener.class)


public class LoginTest extends BaseUI {

	WebDriver driver;
	Login login;
	String[][] data;
	@BeforeTest
	public void setup() {
		driver = invokeBrowser();
		openBrowser("appURL");
	}
	@DataProvider(name = "testData")
	public Object[][] testdata(){
		data= excelUtility.testdata();
		return data;
	}
	
	@Test(priority=0)
	public void accclick() {
		Login login=new Login(driver);
		login.account();;
	}
	
	@Test(priority=1,dataProvider = "testData")
	public void LoginTests(String email1,String  password1) {
		Login login=new Login(driver);
		login.Email(email1);
		login.pass(password1);
		login.SignIn();
		String a=driver.getCurrentUrl();
		 SoftAssertions.assertSoftly(softAssertions -> {
		 softAssertions.assertThat(a.contains("https://www.tastynibbles.in/"));
		 });
	}
	
	@Test(priority=2)
	public void mouseTest() {
		Login login=new Login(driver);
		login. MouseOver();
		login.DropSelect();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//a[@class='site-nav__dropdown-link site-nav__dropdown-link--second-level']")).isSelected());
        	});
	}
	@Test(priority=3)
	public void mouseTest1() {
		Login login=new Login(driver);
		login.availabilitySort();
		login.availabilitySortSelect();
		login.productSelect();
		login.product();
//		SoftAssertions.assertSoftly(softAssertions -> {
//        	softAssertions.assertThat(driver.findElement(By.xpath("//*[@id=\"AddToCartForm-template--15564373229743__main-6759853228207\"]/div[2]/button")).isSelected());
//        	});
		login.checkoutcart();
		login.account();
		login.logout();
	


}
}
