package ust.biotique.base;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;


public class BaseTest extends DriverUtils{
	public static WebDriver driver;
	public static Properties prop;
	public static String browserChoice;

	@BeforeMethod
	public void setup()
	{
		
		driver=invokebrowser();
		openBrowser("appURL");
		
	}
	
//	 @AfterMethod
//	    public  void tearDownDriver() {
//	        driver.close();  // close the default window
//	        driver.quit();  // close the session
//	    } 

}
