package ust.biotique.base;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;

public class BaseTest1 extends DriverUtils {

	public static WebDriver driver;
	public static Properties prop;
	public static String browserChoice;
	
	@BeforeTest
	public void setup()
	{
	driver=invokebrowser();
	openBrowser("appURL");
	}
}
