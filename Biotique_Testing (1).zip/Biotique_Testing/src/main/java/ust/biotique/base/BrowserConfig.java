package ust.biotique.base;

import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class BrowserConfig {
	static WebDriver driver;
	public static WebDriver geTBrowser() {
		ChromeOptions option=new ChromeOptions();
		option.addArguments("--disable-notifications");
		option.addArguments("--remote-allow-origins=*");
		option.setPageLoadStrategy(PageLoadStrategy.NONE);
		driver=new ChromeDriver(option);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
//		option.addArguments("start-maximized");
//		option.addArguments("disable-infobars");
		//option.addArguments("--disable-extensions");
		return driver;
	}

}
