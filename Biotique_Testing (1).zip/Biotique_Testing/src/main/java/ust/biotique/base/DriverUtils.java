package ust.biotique.base;

import java.io.File;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import ust.biotique.utils.DateUtils;
import ust.biotique.utils.FileIo;

public class DriverUtils {

	private static WebDriver driver;
	public static Properties prop;
	public static String browserChoice;
	
	public static ExtentReports extent;
	public static ExtentTest logger;
	public static String timestamp = DateUtils.getTimeStamp();
	
	public DriverUtils() {
		prop=FileIo.initProperties();
	}
	/*****************invoke browser**************/
	public static WebDriver invokebrowser() {
		browserChoice=prop.getProperty("browserName");
		if(browserChoice.equalsIgnoreCase("chrome")) {
			driver=BrowserConfig.geTBrowser();
		}
		return driver;
	}
	/*****************open website url**************/
	public static void openBrowser(String websiteurl) {
		driver.get(prop.getProperty(websiteurl));
	}
	/*************check if the element is present********/
	public static boolean isElementPresent(By locator,Duration timeout) {
		try {
			new WebDriverWait(driver,timeout)
			.until(ExpectedConditions.presenceOfElementLocated(locator));
			return true;
		}catch(Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	 /************** Get text of element ****************/

    public static String getText(WebElement element) {
        String text = null;
        try {
            new WebDriverWait(driver, Duration.ofSeconds(30)).until(ExpectedConditions.visibilityOf(element));
            text = element.getText();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return text;
    }
    
    /************** Send text of element ****************/
    public static void sendtext(WebElement element,String text) {
		try {
			new WebDriverWait(driver,Duration.ofSeconds(15))
			.until(ExpectedConditions.visibilityOf(element));
			element.sendKeys(text);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
    
    /************** For clicking an element ****************/
    public static void clickOn(WebElement element) {
		try {
			new WebDriverWait(driver,Duration.ofSeconds(15))
			.until(ExpectedConditions.visibilityOf(element));
			element.click();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
    
    /************** For taking screenshot ****************/
    public static void takeScreenShot(String filePath) {
		try {
			File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(src, new File(filePath));
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
    
    /**** switch to alert and accept********/
	public void switchtoAlert() {
		try {
			new WebDriverWait(driver,Duration.ofSeconds(15))
			.until(ExpectedConditions.alertIsPresent());
			driver.switchTo().alert().accept();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	/****Switch to alert and extract text*******/
	public String getTextfromAlertandAccept() {
		String text=null;
		try {
			new WebDriverWait(driver,Duration.ofSeconds(15))
			.until(ExpectedConditions.alertIsPresent());
			Alert alert =driver.switchTo().alert();
			text=alert.getText();
			alert.accept();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return text;
	}
	
	/*******Retrieving error msg*******/
	public static String rettext(WebElement element) 
	{
		String text=null;
		try 
		{
			new WebDriverWait(driver,Duration.ofSeconds(15))
			.until(ExpectedConditions.visibilityOf(element));
			text=element.getText();
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		return text;
	}
	
	/*******For dropdown selection*******/
	public static String getSelectedOptionFromDropdown(WebElement element) {
		String text = null;
		try {
		new WebDriverWait(driver, Duration.ofSeconds(30)).until(ExpectedConditions.visibilityOf(element));
		Select s = new Select(element);
		} catch (Exception e) {
		e.printStackTrace();
		}
		return text;
	}
	
	/*******wait for text*******/
	public static void waitForText(WebDriver driver, String text, By by, String timeoutMsg) throws Exception {
        try {
        	 new WebDriverWait(driver,Duration.ofSeconds(10)).until(ExpectedConditions.textToBePresentInElementLocated(by, text));
        } catch (Exception e) {
            e.printStackTrace();
    }
	}
	
	/***********ScrollDown*********/
	public static void ScrollDown() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		try {
		    js.executeScript("window.scrollBy(0, 500)"); // Scroll down by 500 pixels vertically
		} catch (Exception e) {
		    e.printStackTrace();
		    // Handle the exception appropriately
		}
	}
	
	/***********ScrollDown to particular element*********/
	public static void ScrollDownToElement() {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, 5000)");
	}
	
	/***********Mousehover*********/
	public static void mousehOver(WebElement element) {
		 try {
		 new WebDriverWait(driver, Duration.ofSeconds(30)).until(ExpectedConditions.visibilityOf(element));
		 Actions actions = new Actions(driver);
	     actions.moveToElement(element).perform();
		 }catch(Exception e) {
		 e.printStackTrace();
		 }
	}
	
	/***********Scroll down to an particular method*********/
	 public static void scrollDownToElement(WebElement element) {
	        try {
	            JavascriptExecutor js = (JavascriptExecutor) driver;
	            // Scroll to the WebElement using JavaScript
	            js.executeScript("arguments[0].scrollIntoView(true);", element);

	            //Thread.sleep(1000); // Optional: Add a small delay to allow scrolling to complete
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	 

		/***********Click at an particular method*d********/
		 public static void clickAtElement(WebElement element) {
		        try {
		            JavascriptExecutor js = (JavascriptExecutor) driver;
		            js.executeScript("arguments[0].click();", element);
		          

		            Thread.sleep(1000); // Optional: Add a small delay to allow scrolling to complete
		        } catch (Exception e) {
		            e.printStackTrace();
		        }
		    }
	 
	 
}
