package ust.biotique.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.biotique.base.DriverUtils;

public class DigitalGift_page extends DriverUtils {
	
	 WebDriver driver;
	 public DigitalGift_page(WebDriver driver) {
			
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}	
	@FindBy(xpath="//a[@id='link_9']")
	private WebElement digitalgifts;
	
	@FindBy(xpath="//a[text()='occasion']")
	private WebElement occasion;
	
	@FindBy(xpath="//label[@for='gc_value_0']")
	private WebElement giftcardvalue;
	
	@FindBy(xpath="//button[@id='_gcp-purchase-form-continue'][1]")
	private WebElement continues;
	
	@FindBy(xpath="//input[@type='email']")
	private WebElement email;
	
	@FindBy(xpath="//input[@type='tel']")
	private WebElement mobile;
	
	@FindBy(xpath="//input[@name='properties[_gcp_recipient_name]']")
	private WebElement name;
	
	@FindBy(xpath="//label[text()='Send Now']")
	private WebElement sendnow;
	
	@FindBy(xpath="//label[text()='Send Later']")
	private WebElement sendlater;
	
	@FindBy(xpath="//input[@class='gc__input_field gc__datetime_input']")
	private WebElement dateandtym;
	
	@FindBy(xpath="//select[@class='gc__timezone_input gc__input_field']")
	private WebElement centre;
	
	@FindBy(xpath="//option[text()='(GMT +5:30) Bombay, Calcutta, Madras, New Delhi']")
	private WebElement scrolldown;
	
	@FindBy(xpath="(//button[@id='_gcp-purchase-form-continue'])[2]")
	private WebElement cntn2;
	
	@FindBy(xpath="(//p[@class='gc__input_field_error_message'])[3]")
	private WebElement namerror;
	
	@FindBy(xpath="(//p[@class='gc__input_field_error_message'])[1]")
	private WebElement mailerror;
	
	@FindBy(xpath="(//p[@class='gc__input_field_error_message'])[2]")
	private WebElement phone;
	
	@FindBy(xpath="//a[text()='Home']")
	private WebElement home;
	
	
	public void digitalgiftsclick() {
	clickOn(digitalgifts);
	}
	public void Occasionclick() {
	clickOn(occasion);
	}
	public void giftcardclick() {
	clickOn(giftcardvalue);
	}
	public void continueclick() {
	clickOn(continues);
	}
	public void emailclick(String emailid) {
	sendtext(email,emailid);
	}
	public void mobileclick(String mobilenum) {
	sendtext(mobile,mobilenum);
	}
	public void nameclick(String nameenter) {
	sendtext(name,nameenter);
	}
	public void sendnowclick() {
	clickOn(sendnow);
	}
	public void sendlaterclick() {
	clickOn(sendlater);
	}
	
	public void dateandtymclick(String dateandtymdetails) {
	sendtext(dateandtym,dateandtymdetails);
	}
	
	public void centreclick() {
	clickOn(centre);
	}
	
	public void scrolldownclick() {
	clickOn(scrolldown);
	}
	
	public void cont2() {
	clickOn(cntn2);
	}
	
	public String emailerror() {
	return  rettext(mailerror);
	}
	
	public String nameerror() {
	return  rettext(namerror);
	}
	
	public String phoneerror() {
	return  rettext(phone);
	}
	
	 public String getURL(){
	 String url=driver.getCurrentUrl();
	 return url;
	}
	 
	 public String Homeclick() {
	 return  rettext(home);
	}
}
