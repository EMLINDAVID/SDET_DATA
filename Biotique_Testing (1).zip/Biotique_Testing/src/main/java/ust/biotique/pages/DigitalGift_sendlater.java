package ust.biotique.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.biotique.base.DriverUtils;

public class DigitalGift_sendlater extends DriverUtils{
	WebDriver driver;
	public DigitalGift_sendlater(WebDriver driver) {
	this.driver = driver;
	PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//a[@id='link_9']")
	private WebElement digitalgifts;
	
	@FindBy(xpath="//a[text()='occasion']")
	private WebElement occasion;
	
	@FindBy(xpath="//label[@for='gc_value_0']")
	private WebElement giftcardvalue;
	
	@FindBy(xpath="//button[@id='_gcp-purchase-form-continue'][1]")
	private WebElement continues;
	
	@FindBy(xpath="//input[@type='email']")
	private WebElement email;
	
	@FindBy(xpath="//div[@class='selected-flag']")
	private WebElement flag;
	
	@FindBy(xpath="//li[@data-country-code='in']")
	private WebElement india;
	
	@FindBy(xpath="//input[@type='tel']")
	private WebElement mobile;
	
	@FindBy(xpath="//input[@name='properties[_gcp_recipient_name]']")
	private WebElement name;
	
	@FindBy(xpath="//label[text()='Send Later']")
	private WebElement sendlater;
	
	@FindBy(xpath="//input[@id='gcpDeliveryDate']")
	private WebElement dateandtym;
	
	@FindBy(xpath="//select[@class='gc__timezone_input gc__input_field']")
	private WebElement centre;
	
	@FindBy(xpath="//option[text()='(GMT +5:30) Bombay, Calcutta, Madras, New Delhi']")
	private WebElement scrolldown;
	
	@FindBy(xpath="(//button[@id='_gcp-purchase-form-continue'])[2]")
	private WebElement cntn2;
	
	@FindBy(xpath="//input[@name='properties[_gcp_message_from]']")
	private WebElement fromname;
	
	@FindBy(xpath="//textarea[@name='properties[_gcp_message_text]']")
	private WebElement frommessage;
	
	
	@FindBy(xpath="(//button[@name='gcp_submit'])[3]")
	private WebElement addtocart;
	
	@FindBy(xpath="//button[@title='Go to cart']")
	 private WebElement gotocart;
	
	@FindBy(xpath="//i[@class='far fa-plus']")
	private WebElement plus;
	
	 @FindBy(xpath="//p[@class='n8k95w1 _1frageme0 n8k95w2']")
	  private WebElement hbrand;
	 
	 @FindBy(xpath="//input[@id='phone']")
	  private WebElement contact;
	 
	 @FindBy(xpath="//input[@id='email']")
	  private WebElement shmail;
	 
	 @FindBy(xpath="//input[@name='firstName']")
	  private WebElement fname;
	 
	 @FindBy(xpath="//input[@name='lastName']")
	  private WebElement lname;
	 
	 @FindBy(xpath="//input[@name='address1']")
	  private WebElement shadd;
	 
	 @FindBy(xpath="//input[@name='city']")
	  private WebElement city;
	 
	 @FindBy(xpath="//input[@name='postalCode']")
	  private WebElement code;
	 
	 @FindBy(xpath="//input[@name='phone']")
	  private WebElement phone;
	 
	 @FindBy(xpath="//button[@class='QT4by _1fragemey rqC98 hodFu _7QHNJ VDIfJ j6D1f janiy']")
	  private WebElement continuesh;
	 
	 @FindBy(xpath="//a[@id='checkout']")
	  private WebElement checkout;
	 
	 @FindBy(xpath="//select[@name='zone']")
	  private WebElement statslct;
	 
	 @FindBy(xpath="//option[@value='KL']")
	  private WebElement state;
	
	
	public void digitalgiftsclick() {
	clickOn(digitalgifts);
	}
	
	public void Occasionclick() {
	clickOn(occasion);
	}
	
	public void giftcardclick() {
	clickOn(giftcardvalue);
	}
	
	public void continueclick() {
	clickOn(continues);
	}
	public void emailclick(String emailid) {
	sendtext(email,emailid);
	}
	public void flagclick() {
	clickOn(flag);
	}
	public void indiaclick() {
	clickOn(india);
	}
	public void mobileclick(String mobilenum) {
	sendtext(mobile,mobilenum);
	}
	
	public void nameclick(String nameenter) {
	sendtext(name,nameenter);
	}
	
	public void sendlaterclick() {
	clickOn(sendlater);
	}
	
	public void dateandtymclick(String dateandtymdetails) {
	sendtext(dateandtym,dateandtymdetails);
	}
	
	public void centreclick() {
	clickOn(centre);
	}
	
	public void scrolldownclick() {
	clickOn(scrolldown);
	}
	
	public void cont2() {
	clickOn(cntn2);
	}
	
	public void gotocart() {
		clickOn(gotocart);
		}
	
	public void fromnameclick(String namefrom) {
	sendtext(fromname,namefrom);
	}
	
	public void frommessage(String messagefrom) {
	sendtext(frommessage,messagefrom);
	}
	
	public void addtocartclick() {
	clickOn(addtocart);
	}
	
	public String getURL(){
	String url=driver.getCurrentUrl();
	return url;
	}

	 public void hbrandclick() {
		 clickOn(hbrand);
	 }
	 
	 public void contact(String cnt) {
		 scrollDownToElement(contact);
		 sendtext(contact,cnt);
	 }
	 
	 public void mail(String am) {
		 sendtext(shmail,am);
	 }
	 
	 public void fname(String fname1) {
		 sendtext(fname,fname1);
	 }
	 
	 public void lname(String lm) {
		 sendtext(lname,lm);
	 }
	 public void add(String ad) {
		 sendtext(shadd,ad);
	 }
	 public void city(String ac) {
		 sendtext(city,ac);
	 }
	 public void code(String cd) {
		 sendtext(code,cd);
	 }
	 public void phone(String ph) {
		 sendtext(phone,ph);
	 }
	 
	 public void checkout() {
		 clickOn(checkout);
	 }
	 
	 public void contsh() {
		 clickOn(continuesh);
	 }
	 
	 public void statedrop() {
		 clickOn(statslct);
	 }
	 
	 public void stateclick(){
		 clickOn(state);
	 }
	
}
