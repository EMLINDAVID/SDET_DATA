package ust.biotique.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.biotique.base.DriverUtils;

public class HotelAndSpa_Page extends DriverUtils{

	 private WebDriver driver;
	 public HotelAndSpa_Page(WebDriver driver) {
			
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}	

	  @FindBy(xpath="//a[text()='Hotel & Spa']")
	  private WebElement Hotel;
	  
	  @FindBy(id="ContactForm-hname")
	  private WebElement HotelName;
	  
	  @FindBy(id="ContactForm-name")
	  private WebElement PersonName;
	  
	  @FindBy(id="ContactForm-hnum")
	  private WebElement hotelnos;
	  
	  @FindBy(id="ContactForm-desg")
	  private WebElement designation;
	  
	  @FindBy(id="ContactForm-gnum")
	  private WebElement guestnum;
	  
	  @FindBy(name="contact[Contact No]")
	  private WebElement contactNum;
	  
	  @FindBy(id="ContactForm-ra")
	  private WebElement roomAmenties;
	  
	  @FindBy(id="ContactForm-email")
	  private WebElement email;
	  
	  @FindBy(id="ContactForm-ocup")
	  private WebElement occup;
	  
	  @FindBy(name="contact[website]")
	  private WebElement website;
	  
	  @FindBy(name="contact[State]")
	  private WebElement state;
	  
	  @FindBy(name="contact[City]")
	  private WebElement city;
	  
	  @FindBy(xpath="//button[@class='view-all-btn']")
	  private WebElement submit;
	  
	  @FindBy(xpath="//li[text()='Email is invalid.']")
	  private WebElement errormail;
	  
	  @FindBy(xpath="//h3[@class='sccess-form']")
	  private WebElement msgsuccess;
	  
	  @FindBy(xpath="//div[@class='recaptcha-checkbox-border']")
	  private WebElement captcha;
	  
	  @FindBy(xpath="//a[@class='breadcrumbs__link']")
	  private WebElement home;
	    
	  public String getTitle() {
	  return driver.getTitle();
	  }
	    
	 public void Hotellogin() {
	  ScrollDown();
	  clickOn(Hotel);
	  }
	 
	 public void hotelName(String hname) {
		 sendtext(HotelName,hname);
	 }
	 
	 public void ContactPersonName(String cname) {
		 sendtext(PersonName,cname);
	 }
	 
	 public void hotelNums(String hno) {
		 sendtext(hotelnos,hno);
	 }
	 
	 public void Designation(String designt) {
		 sendtext(designation,designt);
	 }
	 
	 public void GuestNums(String gno) {
		 sendtext(guestnum,gno);
	 }
	 
	 public void contactNums(String cno) {
		 sendtext(contactNum,cno);
	 }
	 
	 public void roomAmen(String rooma) {
		 sendtext(roomAmenties,rooma);
	 }
	 
	 public void Email(String mail) {
		 sendtext(email,mail);
	 }
	 
	 public void Maxoccup(String occupancy) {
		 sendtext(occup,occupancy);
	 }
	 
	 public void Website(String web) {
		 sendtext(website,web);
	 }
	 
	 public void State(String occupancy) {
		 sendtext(state,occupancy);
	 }
	 
	 public void City(String city1) {
		 sendtext(city,city1);
	 }

	 public void hotelSubmit() {
		 clickOn(submit);
	 }
	 
	 public String errorm() {	
		return rettext(errormail);	
	}
	 
	 public String succmsg() {	
		return rettext(msgsuccess);	
	}
	 
	 public String captcha() {	
			return rettext(captcha);	
	}
	 
	 public String getURL(){
			String url=driver.getCurrentUrl();
			return url;
	}

	    
}
