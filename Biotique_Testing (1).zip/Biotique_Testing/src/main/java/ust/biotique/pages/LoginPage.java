package ust.biotique.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.biotique.base.DriverUtils;

public class LoginPage extends DriverUtils{

	 WebDriver driver;
	 public LoginPage(WebDriver driver) {
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}
	 
	 @FindBy(xpath="//img[@class='icon-header lazyloaded']")
	  private WebElement Login;
	 
	 @FindBy(xpath="//a[text()='LOGIN']")
	  private WebElement Loginbtn;
	 
	 @FindBy(id="CustomerEmail")
	  private WebElement custEmail;
	 
	 @FindBy(id="CustomerPassword")
	  private WebElement custpass;
	 
	 @FindBy(className="signin-form-validation")
	  private WebElement custlogin;
	 
	 @FindBy(className="login-emp-error")
	  private WebElement emailerror;
	 
	 @FindBy(className="login-pass-emp")
	  private WebElement passError;
	 
	 @FindBy(className="errors")
	  private WebElement icrcterror;
	 
	 @FindBy(className="breadcrumbs__link")
	  private WebElement Homebtn;
	 
	 public void login1() {
		 mousehOver(Login);
	 }
	 
	 public void logBtnClick() {
		 clickOn(Loginbtn);
	 }
	 
	 public void eMail(String mail) {
		 sendtext(custEmail,mail);
	 }
	 
	 public void Password(String cpass) {
		 sendtext(custpass,cpass);
	 }
	 
	 public void custLogin() {
		 clickOn(custlogin);
	 }
	 
	 public void home() {
		 clickOn(Homebtn);
	 }
	 
	 public String passwordError() {
		return  rettext(passError);
	 }
		 
	 public String emailError() {
			return  rettext(emailerror);
	 }
	 
	 public String IncrctEmaileror() {
			return  rettext(icrcterror);
	 }
	 
	 public String getURL(){
	  String url=driver.getCurrentUrl();
	  return url;
	}
	 
	public String getTitle() {
	return driver.getTitle();
		  }
}
