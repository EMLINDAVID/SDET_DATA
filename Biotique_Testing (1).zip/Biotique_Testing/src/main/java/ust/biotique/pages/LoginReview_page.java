package ust.biotique.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.biotique.base.DriverUtils;


public class LoginReview_page extends DriverUtils {

	 WebDriver driver;
	public LoginReview_page(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		
		}
	
	@FindBy(xpath="//img[@class='icon-header lazyloaded']")
	  private WebElement Login;
	 
	 @FindBy(xpath="//a[text()='LOGIN']")
	  private WebElement Loginbtn;
	 
	 @FindBy(id="CustomerEmail")
	  private WebElement custEmail;
	 
	 @FindBy(id="CustomerPassword")
	  private WebElement custpass;
	
	 @FindBy(className="signin-form-validation")
	  private WebElement custlogin;
	
	@FindBy(xpath="//a[@class='breadcrumbs__link']") 
	private WebElement home;
	
	@FindBy(id="Search")
	private WebElement search;
	
	@FindBy(className="btn-searchbar")
	private WebElement searchs;
	
	@FindBy(className="prd-h-img")
	private WebElement img;

	
	@FindBy(xpath="//button[@class='btn-add-alireview alireview-btn--1']")
	private WebElement rev1;
	
	@FindBy(xpath="//iframe[@class='aliReviewsFrame']")
	private WebElement rev2;
	
	
	@FindBy(xpath="//input[@id='your_name']")
	private WebElement yourname;
	
	@FindBy(id="your_email")
	private WebElement youremail;
	
	@FindBy(id="btn-add-review")
	private WebElement  submitreview;
	

	//WebElement frame=driver.findElement(By.xpath("//iframe[@class='aliReviewsFrame']"));
	
	 public void login1() {
		 mousehOver(Login);
	 }
	 
	 public void logBtnClick() {
		 clickOn(Loginbtn);
	 }
	 
	 public void eMail(String mail) {
		 sendtext(custEmail,mail);
	 }
	 
	 public void Password(String cpass) {
		 sendtext(custpass,cpass);
	 }
	 
	 public void custLogin() {
		 clickOn(custlogin);
	 }
     public void Home() {
 		clickOn(home);
 	}
     public void Search1(String search1) {
    	 sendtext(search, search1);	 
     }
     public void Search2() {
  		clickOn(searchs);
  	}
     public void Image() {
   		clickOn(img);
   	}
     
     public void Scroll() {
     //driver.switchTo().frame(frame);
	 scrollDownToElement(rev1);
     }
     
   public void Review() { 
	 
	   clickAtElement(rev1); 
    }
   
//  public void Feedback(String feedback1) {
//	 sendtext(feedback, feedback1);	 
//  }
  
 public void YourName(String yourname1) {
	 sendtext(yourname, yourname1);	 
 }
 
// public void YourEmail(String youremail1) {
//	 sendtext(youremail, youremail1);	 
// }
// 
// public void SubmitReview() {
//	 clickOn(submitreview);
// }
// 
 public String getURL(){
	  String url=driver.getCurrentUrl();
	  return url;
	}
}
