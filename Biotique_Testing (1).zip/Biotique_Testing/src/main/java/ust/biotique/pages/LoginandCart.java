package ust.biotique.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.biotique.base.DriverUtils;

public class LoginandCart extends DriverUtils {
	
	 WebDriver driver;
	 public LoginandCart(WebDriver driver) {
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}
	 
	 @FindBy(xpath="//img[@class='icon-header lazyloaded']")
	  private WebElement Login;
	 
	 @FindBy(xpath="//a[text()='LOGIN']")
	  private WebElement Loginbtn;
	 
	 @FindBy(id="CustomerEmail")
	  private WebElement custEmail;
	 
	 @FindBy(id="CustomerPassword")
	  private WebElement custpass;
	 
	 @FindBy(className="signin-form-validation")
	  private WebElement custlogin;
	 
	 @FindBy(xpath="(//a[@class='menu_link'])[2]")
	  private WebElement skin;
	 
	 @FindBy(xpath="(//a[@href='/collections/skin-serums'])[1]")
	  private WebElement serums;

	 @FindBy(className="breadcrumbs__link")
	  private WebElement Homebtn;
	 
	 @FindBy(xpath="//li[@class='Anti Aging']")
	  private WebElement antiage;
	 
	 @FindBy(className="sortbar")
	  private WebElement sort;
	 
	 @FindBy(xpath="//option[@value='created-descending']")
	  private WebElement sortdate;
	 
	 @FindBy(xpath="(//button[@class='add-cart-btn hs-event-static'])[1]")
	  private WebElement addtocart;
	 
	 @FindBy(xpath="//button[@title='Go to cart']")
	  private WebElement gotocart;
	 
	 @FindBy(xpath="//i[@class='far fa-plus']")
	  private WebElement plus;
	 
	 @FindBy(xpath="//p[@class='n8k95w1 _1frageme0 n8k95w2']")
	  private WebElement hbrand;
	 
	 @FindBy(xpath="//input[@id='phone']")
	  private WebElement contact;
	 
	 @FindBy(xpath="//input[@id='email']")
	  private WebElement shmail;
	 
	 @FindBy(xpath="//input[@name='firstName']")
	  private WebElement fname;
	 
	 @FindBy(xpath="//input[@name='lastName']")
	  private WebElement lname;
	 
	 @FindBy(xpath="//input[@name='address1']")
	  private WebElement shadd;
	 
	 @FindBy(xpath="//input[@name='city']")
	  private WebElement city;
	 
	 @FindBy(xpath="//input[@name='postalCode']")
	  private WebElement code;
	 
	 @FindBy(xpath="//input[@name='phone']")
	  private WebElement phone;
	 
	 @FindBy(xpath="//button[@class='QT4by _1fragemey rqC98 hodFu _7QHNJ VDIfJ j6D1f janiy']")
	  private WebElement continuesh;
	 
	 @FindBy(xpath="//a[@id='checkout']")
	  private WebElement checkout;
	 
	 @FindBy(xpath="//select[@name='zone']")
	  private WebElement statslct;
	 
	 @FindBy(xpath="//option[@value='KL']")
	  private WebElement state;
	 
	 
	 public void login1() {
		 mousehOver(Login);
	 }
	 
	 public void logBtnClick() {
		 clickOn(Loginbtn);
	 }
	 
	 public void eMail(String mail) {
		 sendtext(custEmail,mail);
	 }
	 
	 public void Password(String cpass) {
		 sendtext(custpass,cpass);
	 }
	 
	 public void custLogin() {
		 clickOn(custlogin);
	 }

	 public void skinCare() {
		 mousehOver(skin);
	 }
	 
	 public void serums() {
		 clickOn(serums);
	 }
	 
	 public void home() {
		 clickOn(Homebtn);
	 }
	 
	 public void antiAging() {
		 scrollDownToElement(antiage);
		 clickOn(antiage);
	 }

	 public void sortClick() {
		 clickOn(sort);
	 }
	 
	 public void sortOption() {
		 clickOn(sortdate);
	 }
	 
	 public void cartclick() {
		 clickOn(addtocart);
	 }
	 
	 
	 public void addclick() {
		 clickOn(plus);
	 }
	 
	 public void gotoclick() {
		 clickOn(gotocart);
	 }
	 
	 public void hbrandclick() {
		 clickOn(hbrand);
	 }
	 
	 public void contact(String cnt) {
		 scrollDownToElement(contact);
		 sendtext(contact,cnt);
	 }
	 
	 public void mail(String am) {
		 sendtext(shmail,am);
	 }
	 
	 public void fname(String fname1) {
		 sendtext(fname,fname1);
	 }
	 
	 public void lname(String lm) {
		 sendtext(lname,lm);
	 }
	 public void add(String ad) {
		 sendtext(shadd,ad);
	 }
	 public void city(String ac) {
		 sendtext(city,ac);
	 }
	 public void code(String cd) {
		 sendtext(code,cd);
	 }
	 public void phone(String ph) {
		 sendtext(phone,ph);
	 }
	 
	 public void checkout() {
		 clickOn(checkout);
	 }
	 
	 public void contsh() {
		 clickOn(continuesh);
	 }
	 
	 public void statedrop() {
		 clickOn(statslct);
	 }
	 
	 public void stateclick(){
		 clickOn(state);
	 }
	 
	 public String getURL(){
	  String url=driver.getCurrentUrl();
	  return url;
	}


}
