package ust.biotique.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.biotique.base.DriverUtils;

public class Registration_page extends DriverUtils{

	 private WebDriver driver;
	 public Registration_page(WebDriver driver) {
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}	
	 
	 @FindBy(xpath="//img[@class='icon-header lazyloaded']")
	  private WebElement Login;
	 
	 @FindBy(xpath="//a[text()='LOGIN']")
	  private WebElement Loginbtn;
	 
	 @FindBy(xpath="//a[@href='/account/register']")
	  private WebElement createlnk;
	 

	 @FindBy(id="RegisterForm-FirstName")
	  private WebElement firstName;
	 
	 @FindBy(id="RegisterForm-LastName")
	  private WebElement lastName;
	 
	 @FindBy(id="RegisterForm-email")
	  private WebElement Email;
	 
	 @FindBy(id="RegisterForm-password")
	  private WebElement Password;
	 
	 @FindBy(xpath="//button[@class='form-register']")
	  private WebElement createbtn;
	 
	 @FindBy(xpath="//p[@class='err-field pass-emp-error']")
	  private WebElement pswdmsg;
	 
	 @FindBy(xpath="//p[@class='err-field pass-emp-val']")
	  private WebElement pswdmsg2;
	 
	 @FindBy(xpath="//span[@id='RegisterForm-email-error']")
	  private WebElement emailerror;
	 
	 @FindBy(xpath="//*[@id=\"create_customer\"]/p[2]")
	  private WebElement emailempty;
	 
	 @FindBy(xpath="//p[@class='err-field fname-emp-error']")
	  private WebElement nameempty;
	 
	 @FindBy(xpath="//a[@class='breadcrumbs__link']")
	 private WebElement home;
	 
	 @FindBy(xpath="//span[@class='h_google_text h_google_full']")
	 private WebElement signgooglebtn;
	 
	 public void LoginMousehover() {
		 mousehOver(Login); 
	}
	 
	 public void Loginbtn() {
		 clickOn(Loginbtn); 
	}
	 
	 public void Createacnt() {
		 clickOn(createlnk); 
	}
	 
	 public void firstName(String fn) {
		 sendtext(firstName,fn);
	 }
	 
	 public void Nlastame(String ln) {
		 sendtext(lastName,ln);
	 }
	 
	 public void Mail(String email) {
		 sendtext(Email,email);
	 }
	 
	 public void passWord(String pass) {
		 sendtext(Password,pass);
	 }
	 
	 public void createbtnClick() {
		 clickOn(createbtn);
	 }
	 
	 public String passwordempty() {
		 return rettext(pswdmsg);
	 }
	 
	 public String passworderror() {
		return  rettext(pswdmsg2);
	 }
	 
	 public String emailerror() {
		return  rettext(emailerror);
	 }
	 
	 public String emailEmpty() {
		return  rettext(emailempty);
	}
	 
	 public String fnameEmpty() {
			return  rettext(nameempty);
	}
	 
	 public void Home() {
			clickOn(home);
	}
	 
	 public String getURL(){
			String url=driver.getCurrentUrl();
			return url;
	}
}
