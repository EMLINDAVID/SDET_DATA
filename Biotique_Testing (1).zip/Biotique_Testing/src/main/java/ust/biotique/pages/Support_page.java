package ust.biotique.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.biotique.base.DriverUtils;

public class Support_page extends DriverUtils {

	 WebDriver driver;
	
	public Support_page(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(xpath="//span[normalize-space()='Support']")
	private WebElement support;
	
	@FindBy(id="ContactForm-name")
	 WebElement name;
	
	@FindBy(id="ContactForm-email")
	private WebElement email;
	
	@FindBy(id="ContactForm-phone")
	private WebElement phn;
	
	@FindBy(id="ContactForm-body")
	private WebElement query;
	
	@FindBy(className="contact-submit") 
	private WebElement submit;
	
	@FindBy(xpath="//a[@class='breadcrumbs__link']") 
	private WebElement home;
	
	@FindBy(xpath="//a[text()='faq']")
	private WebElement faq;
	
	@FindBy(xpath="//div[text()='Browser Requirements']")
	private WebElement req;
	
	public void Supportclick() {
		clickOn(support);
		scrollDownToElement(name);
	}
	public void Name(String name1) {
		sendtext(name,name1);
		}
	public void Email(String email1) {
		sendtext(email,email1);
		}
	public void Phone(String phn1) {
		sendtext(phn,phn1);
		}
	
	public void Query(String query1) {
		sendtext(query,query1);
		}
	public void Submit() {
		clickOn(submit);
	}
	public void Home() {
		clickOn(home);
	}
	public void Faq() {
		scrollDownToElement(name);
		clickOn(faq);
	}
	public void Req() {
		scrollDownToElement(req);
		clickOn(req);
	}
	
	 public String getURL(){
			String url=driver.getCurrentUrl();
			return url;
	}
}
