package ust.biotique.utils;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excelutils2 {
	public static String[][] testdata(){

		FileInputStream fis;
		
		XSSFWorkbook workbook = null;
		try {
			fis=new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\testdata\\Registerdata.xlsx");
			workbook = new XSSFWorkbook(fis);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 XSSFSheet sheet=workbook.getSheetAt(0);
	        int rowCount=sheet.getPhysicalNumberOfRows();
	        System.out.println("Total number of rows used in sheet: "+rowCount);
	        int colCount=sheet.getRow(0).getPhysicalNumberOfCells();
	        System.out.println("Total number of columns used in sheet: "+colCount);
	        String[][] testdata=new String[rowCount][colCount];
	        DataFormatter df= new DataFormatter();
	        for (int i = 0; i < rowCount; i++) {
	            for (int j = 0; j < colCount; j++) {

	            	testdata[i][j] = df.formatCellValue(sheet.getRow(i).getCell(j));
	            }

	        }
	        return testdata;

	}

}
