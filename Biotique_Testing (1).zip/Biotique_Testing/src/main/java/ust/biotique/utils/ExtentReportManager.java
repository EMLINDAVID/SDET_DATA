package ust.biotique.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import ust.biotique.base.DriverUtils;

public class ExtentReportManager extends DriverUtils{
	public static ExtentReports extent;
	public static ExtentSparkReporter spark;

	public static ExtentReports getReportInstance() {
		extent=new ExtentReports();
		String repName="TestReport-"+DriverUtils.timestamp+".html";
		spark=new ExtentSparkReporter(System.getProperty("user.dir")
				+"/TestOutput/"+repName);
		extent.attachReporter(spark);
		extent.setSystemInfo("Host Name", "UST");
		extent.setSystemInfo("Environment","Production");
		extent.setSystemInfo("User Name","Anjali");
		spark.config().setDocumentTitle("Biotique Ecommerce Report");
		//Name of the report
		spark.config().setReportName("Biotique Ecommerce Report");
		//Dark Theme
		spark.config().setTheme(Theme.DARK);
		return extent;
	}
}
