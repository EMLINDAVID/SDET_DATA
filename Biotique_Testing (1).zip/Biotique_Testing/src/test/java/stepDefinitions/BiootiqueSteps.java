package stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import ust.biotique.base.BrowserConfig;
import ust.biotique.pages.LoginPage;

public class BiootiqueSteps {
	
	public static String title;
	public WebDriver driver1=BrowserConfig.geTBrowser();
	public LoginPage c1=new LoginPage(driver1);
	
	@Given("user is on Home page")
	public void user_is_on_home_page() throws InterruptedException {
		driver1.get("https://www.biotique.com/");
		Thread.sleep(2000);
	}

	@When("user gets the title of the page")
	public void user_gets_the_title_of_the_page() {
		try {
		LoginPage c1=new LoginPage(driver1);
		Thread.sleep(2000);
		title=c1.getTitle();
		System.out.println("Title"+title);
		}catch (Exception e) {
	        e.printStackTrace();
	    }
	}

	@Then("page title should be {string}")
	public void page_title_should_be(String string) {
		LoginPage c1=new LoginPage(driver1);
		title=c1.getTitle();
		Assert.assertEquals(title,string);
	}

	@When("user enters username {string}")
	public void user_enters_username(String string){
	   LoginPage c1=new LoginPage(driver1);
	   //Thread.sleep(2000);
	   c1.login1();
	   c1.logBtnClick();
	   c1.eMail(string);
	}

	@When("user enters password {string}")
	public void user_enters_password(String string) {
		LoginPage c1=new LoginPage(driver1);
	    c1.Password(string);
	}

	@When("user clicks on Login button")
	public void user_clicks_on_login_button() {
		LoginPage c1=new LoginPage(driver1);
	   c1.custLogin();
	}

}
