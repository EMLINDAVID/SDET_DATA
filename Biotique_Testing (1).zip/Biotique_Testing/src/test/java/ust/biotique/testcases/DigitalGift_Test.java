package ust.biotique.testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import ust.biotique.base.BaseTest;
import ust.biotique.pages.DigitalGift_page;
import ust.biotique.utils.Excelutils3;

@Listeners(ust.biotique.utils.SampleListener.class)
public class DigitalGift_Test extends BaseTest{
	
	String[][] data;
	
	//Method to get the value from excel
	@DataProvider(name = "giftData")
	public Object[][] testdata(){
		data= Excelutils3.testdata();
		return data;
	}

	@Test(priority=1,dataProvider="giftData")
	public void hotelField(String mail,String phone,String name){
		DigitalGift_page d=new DigitalGift_page(driver);
		d.digitalgiftsclick();
		
		String a1=d.getURL();
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(a1.contains("https://www.biotique.com/a/gc/gift-card/"));
		});	
		
		d.Occasionclick();
		d.giftcardclick();
		d.continueclick();
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//input[@type='email']")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//input[@type='tel']")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//input[@name='properties[_gcp_recipient_name]']")).isDisplayed());
			
		});
		
		d.emailclick(mail);
		d.mobileclick(phone);
		d.nameclick(name);
		d.sendnowclick();
		d.cont2();
		
		String e1=d.emailerror();
		String n1=d.nameerror();
		String p1=d.phoneerror();
		
		if(mail.equals(" ") && (mail.equals("anu"))) {
			
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(e1.equalsIgnoreCase(" Please enter a valid email address"));
			});
			
		}
		else if(phone.equals(" ")) {
			
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(n1.equalsIgnoreCase("Please enter a valid phone number"));
			});
		}
		else if(name.equals(" ")) {
			
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(p1.equalsIgnoreCase("Please enter a recipient name"));
			});
			
		}
		else if(name.equals("Anu")) {
			
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(a1.contains("https://www.biotique.com/a/gc/gift-card/?step=gift_message"));
			});	
			d.Homeclick();
			
		}
		}
}
