package ust.biotique.testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import ust.biotique.base.BaseTest1;
import ust.biotique.pages.DigitalGift_sendlater;
import ust.biotique.utils.Excelutils3;
import ust.biotique.utils.Excelutils5;

@Listeners(ust.biotique.utils.SampleListener.class)
public class DigitalSendLater_Test extends BaseTest1{
	
	String[][] data;
	
	//Method to get the value from excel
	@DataProvider(name = "giftData")
	public Object[][] testdata(){
		data= Excelutils3.testdata1();
		return data;
	}
String[][] data1;
String[][] data2;
String[][] data3;
	
	//Method to get the value from excel
	@DataProvider(name = "giftData1")
	public Object[][] testdata1(){
		data1= Excelutils3.testdata2();
		return data1;
	}	
	
	//Method to get the value from excel
		@DataProvider(name = "giftData2")
		public Object[][] testdata2(){
			data2= Excelutils5.testdata3();
			return data2;
		}
	
	//Method to get the value from excel
		@DataProvider(name = "giftData3")
				public Object[][] testdata3(){
					data3= Excelutils5.testdata1();
					return data3;
				}
	
	@Test(priority=1)
	public void digitalfieldclick(){
		DigitalGift_sendlater d=new DigitalGift_sendlater(driver);
		d.digitalgiftsclick();
		
		String a1=d.getURL();
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(a1.contains("https://www.biotique.com/a/gc/gift-card/"));
		});	
	}
	
	@Test(priority=2,dataProvider="giftData")
	public void giftselection(String mail,String phone,String name,String date){
		DigitalGift_sendlater d=new DigitalGift_sendlater(driver);
		d.Occasionclick();
		d.giftcardclick();
		d.continueclick();
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//input[@type='email']")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//input[@type='tel']")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//input[@name='properties[_gcp_recipient_name]']")).isDisplayed());
			
		});
		
		d.emailclick(mail);
		d.mobileclick(phone);
		d.nameclick(name);
		d.sendlaterclick();
	}
	
	@Test(priority=3)
	public void dateAndtimeselect(){
		DigitalGift_sendlater d=new DigitalGift_sendlater(driver);
		d.dateandtymclick("9/27/2023");
		d.centreclick();
		d.scrolldownclick();
		d.cont2();
	}
	@Test(priority=4,dataProvider="giftData1")
	public void fromandMsg(String fname,String msg){
		DigitalGift_sendlater d=new DigitalGift_sendlater(driver);
		d.fromnameclick(fname);
		d.frommessage(msg);
		d.addtocartclick();
		d.gotocart();
	}
	
	@Test(priority=5,dataProvider="giftData2")
	public void contact(String phn) throws InterruptedException{
		try {
		DigitalGift_sendlater d=new DigitalGift_sendlater(driver);
		d.contact(phn);
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//input[@id='phone']")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//a[@id='checkout']")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//span[text()='Grand total']")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//textarea[@name='note']")).isDisplayed());
			
		});
		
		d.checkout();
		}catch (Exception e) {
            e.printStackTrace();
        }
}
	@Test(priority=5,dataProvider="giftData3")
	public void shipdetails(String mail,String fname,String lname,String add,String city,String code,String phone) throws InterruptedException{
		DigitalGift_sendlater d=new DigitalGift_sendlater(driver);
				
		d.mail(mail);
		d.fname(fname);
		d.lname(lname);
		d.add(add);
		d.city(city);
		d.code(code);
		d.phone(phone);
		d.contsh();
		d.hbrandclick();
	}
}
