package ust.biotique.testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import ust.biotique.base.BaseTest;
import ust.biotique.pages.HotelAndSpa_Page;
import ust.biotique.utils.Excelutils;

@Listeners(ust.biotique.utils.SampleListener.class)
public class Hotelandspa_Tests extends BaseTest{
	
		String[][] data;
	//Method to get the value from excel
		@DataProvider(name = "testData")
		public Object[][] testdata()
		{
			data= Excelutils.testdata();
			return data;

		}
	
	
	@Test(priority=1,dataProvider="testData")
	public void hotelDetails(String hname,String contactname,String noofhotels,String design,String noguest,String phonenum,String brand,String email,String avgroom,String website,String stat,String city){
		try{
	
			HotelAndSpa_Page h1=new HotelAndSpa_Page(driver);
		h1.Hotellogin();
		String a1=h1.getURL();
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(a1.contains("https://www.biotique.com/pages/hotel-spa?contact_posted=true"));
		});

		Thread.sleep(2000);
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("ContactForm-hname")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("ContactForm-name")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("ContactForm-hnum")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("ContactForm-desg")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("ContactForm-gnum")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.name("contact[Contact No]")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("ContactForm-ra")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("ContactForm-email")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("ContactForm-ocup")).isDisplayed());
			
		});
		

		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.name("contact[website]")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.name("contact[State]")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.name("contact[City]")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//button[@class='view-all-btn']")).isDisplayed());
			
		});
		
		
		
		
		h1.hotelName(hname);
		h1.ContactPersonName(contactname);
		h1.hotelNums(noofhotels);
		h1.Designation(design);
		h1.GuestNums(noguest);
		h1.contactNums(phonenum);
		h1.roomAmen(brand);
		h1.Email(email);
		h1.Maxoccup(avgroom);
		h1.Website(website);
		h1.State(stat);
		h1.City(city);
		h1.hotelSubmit();
		
		h1.captcha();
		String j=h1.errorm();
		String j1=h1.succmsg();
		
		if(email.equals(" ")) {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(j.equalsIgnoreCase("Email is invalid."));
			});
		}
		else if(hname.equals("Raju")) {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(j1.equalsIgnoreCase("Thanks for contacting us. We will Get back to you shortly."));
			});
		}
	}
	catch (Exception e) {
        e.printStackTrace();
    }
	}
}
