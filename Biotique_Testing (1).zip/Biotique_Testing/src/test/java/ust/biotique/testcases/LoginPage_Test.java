package ust.biotique.testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import ust.biotique.base.BaseTest;
import ust.biotique.pages.LoginPage;
import ust.biotique.utils.Excelutils5;

@Listeners(ust.biotique.utils.SampleListener.class)
public class LoginPage_Test extends BaseTest{
	
	String[][] data;
	
	//Method to get the value from excel
	@DataProvider(name = "LoginData")
	public Object[][] testdata()
	{
		data= Excelutils5.testdata();
		return data;

	}
	
	@Test(priority=1,dataProvider="LoginData")
	public void loginTest(String mail,String password) {
		try {
		LoginPage l1=new LoginPage(driver);
		l1.login1();
		l1.logBtnClick();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//input[@class='email-info']")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("CustomerPassword")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.className("signin-form-validation")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//a[@href='/account/register']")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//a[@href='#recover']")).isDisplayed());
			
		});
		
		l1.eMail(mail);
		l1.Password(password);
		l1.custLogin();
		
		String a=l1.getURL();
		String p=l1.passwordError();
		String n1=l1.IncrctEmaileror();
		String m1=l1.emailError();
		
		if(mail.equals(" ")) {
			
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(m1.equalsIgnoreCase("Email can't be empty!"));
			});
			
		}
		else if(password.equals(" ")) {
			
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(p.equalsIgnoreCase("Password can't be empty!"));
			});
		}
		else if(mail.equals("anu")) {
			
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(n1.equalsIgnoreCase("Incorrect email or password."));
			});
			
		}
		else if(mail.equals("saradadam1@gmail.com")) {
			l1.home();
		
		}
	}catch (Exception e) {
        e.printStackTrace();
    }
	}
}
