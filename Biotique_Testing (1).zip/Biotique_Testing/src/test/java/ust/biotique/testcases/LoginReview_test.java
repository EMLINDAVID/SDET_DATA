package ust.biotique.testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ust.biotique.base.BaseTest1;
import ust.biotique.pages.LoginReview_page;
import ust.biotique.utils.ExcelUtils6;


public class LoginReview_test extends BaseTest1 {
	
    String[][] data;
	
    @DataProvider(name = "testData")
	public Object[][] testdata(){
		data= ExcelUtils6.testdata();
		return data;
	}
    @DataProvider(name = "testData1")
   	public Object[][] testdata1(){
   		data= ExcelUtils6.testdata1();
   		return data;
   	}
    @DataProvider(name = "testData2")
   	public Object[][] testdata2(){
   		data= ExcelUtils6.testdata2();
   		return data;
   	}
    
    @Test(priority=0)
	public void Login() {
		
		LoginReview_page l=new LoginReview_page(driver);
		l.login1();
		l.logBtnClick();
		String a=l.getURL();
	    
		 SoftAssertions.assertSoftly(softAssertions -> {
		 softAssertions.assertThat(a.contains("https://www.biotique.com/account"));
		 });
	}
    
	@Test(priority=1,dataProvider = "testData")
	public void signin(String email1,String password1)  {
		try {
		LoginReview_page l1=new LoginReview_page(driver);
		l1.eMail(email1);
		l1.Password(password1);
		l1.custLogin();
		l1.Home();
		
		Thread.sleep(2000);
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//span[normalize-space()='Support']")).isDisplayed());});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//button[text()='Search']")).isDisplayed());});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//span[text()='Cart']")).isDisplayed());});
		
	}catch (Exception e) {
        e.printStackTrace();
    }
	}
	@Test(priority=2,dataProvider = "testData1")
	public void Searchtext(String search1) {
		LoginReview_page l2=new LoginReview_page(driver);
		l2.Search1(search1);
		l2.Search2();
		l2.Image();
		String a=l2.getURL();
		
		SoftAssertions.assertSoftly(softAssertions -> {
			 softAssertions.assertThat(a.contains("https://www.biotique.com/products/honey-gel-soothe-nourish-foaming-face-wash?_pos=1&_sid=e65f5198d&_ss=r"));
			 });
		
	}
	@Test(priority=3,dataProvider="testData2")
	public void Review(String feedback1, String yourname1,String youremail1) throws InterruptedException {
		LoginReview_page l3=new LoginReview_page(driver);
		l3.Scroll();
		
	    //l3.Review();
	    
//	    SoftAssertions.assertSoftly(softAssertions -> {
////			softAssertions.assertThat(driver.findElement(By.id("content")).isDisplayed());});
//	    SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(driver.findElement(By.id("your_name")).isDisplayed());});
//	    SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(driver.findElement(By.id("your_email")).isDisplayed());});
//	    SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(driver.findElement(By.id("btn-add-review")).isDisplayed());});
	    
	    
	   // l3.Feedback(feedback1);
	    l3.YourName("hi");
//	    l3.YourEmail(youremail1);
//	    l3.SubmitReview();
	}

}
