package ust.biotique.testcases;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import ust.biotique.base.BaseTest1;
import ust.biotique.pages.LoginandCart;
import ust.biotique.utils.Excelutils5;

@Listeners(ust.biotique.utils.SampleListener.class)
public class LoginandCartTest extends BaseTest1{
	
	String[][] data;
	
	//Method to get the value from excel
	@DataProvider(name = "LoginData")
	public Object[][] testdata()
	{
		data= Excelutils5.testdata1();
		return data;

	}
	
	@Test(priority=1)
	public void loginTest(){
		try {
		LoginandCart  l1=new LoginandCart (driver);
		
		l1.login1();
		
		l1.logBtnClick();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//input[@class='email-info']")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("CustomerPassword")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.className("signin-form-validation")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//a[@href='/account/register']")).isDisplayed());
			
		});
		
		l1.eMail("saradadam1@gmail.com");
		l1.Password("Serah10##");
		l1.custLogin();
		l1.home();
		}catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	@Test(priority=2)
	public void selectByMosuehover() {
		LoginandCart  l1=new LoginandCart (driver);
		l1.skinCare();
		l1.serums();
	}
	@Test(priority=3)
	public void productSelect() throws InterruptedException {
		LoginandCart  l1=new LoginandCart (driver);
	
		
		l1.antiAging();
		Thread.sleep(2000);
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//a[text()='anti aging']")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//a[text()='acne & oil control']")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//a[text()='All']")).isDisplayed());
			
		});
		
		
		l1.sortClick();
		l1.sortOption();
		l1.cartclick();
		l1.gotoclick();
}
	
	@Test(priority=4)
	public void cartDetails() throws InterruptedException {
		LoginandCart  l1=new LoginandCart (driver);
		l1.contact("9876543210");
		Thread.sleep(2000);

		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//input[@id='phone']")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//a[@id='checkout']")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//span[text()='Grand total']")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//textarea[@name='note']")).isDisplayed());
			
		});
		
		l1.checkout();
		}
	@Test(priority=5,dataProvider="LoginData")
	public void shippAddress(String mail,String fname,String lname,String add,String city,String code,String phone) throws InterruptedException {
		LoginandCart  l1=new LoginandCart (driver);
		Thread.sleep(2000);
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//input[@name='email']")).isDisplayed());
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//select[@name='countryCode']")).isDisplayed());
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//input[@name='firstName']")).isDisplayed());
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//input[@name='lastName']")).isDisplayed());
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//input[@name='address1']")).isDisplayed());
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//input[@name='address2']")).isDisplayed());
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//input[@name='city']")).isDisplayed());
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//input[@name='postalCode']")).isDisplayed());
		});
		

		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//input[@name='phone']")).isDisplayed());
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("(//button[@type='submit'])[1]")).isDisplayed());
		});
		
		
		l1.mail(mail);
		l1.fname(fname);
		l1.lname(lname);
		l1.add(add);
		l1.city(city);
		l1.statedrop();
		l1.stateclick();
		l1.code(code);
		l1.phone(phone);
		l1.contsh();
		l1.hbrandclick();
	}
}
