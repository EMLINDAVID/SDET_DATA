package ust.biotique.testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import ust.biotique.base.BaseTest;
import ust.biotique.pages.Registration_page;
import ust.biotique.utils.Excelutils2;

@Listeners(ust.biotique.utils.SampleListener.class)
public class Registationpage_Test extends BaseTest {
	

	String[][] data;
	
	//Method to get the value from excel
	@DataProvider(name = "RegisterData")
	public Object[][] testdata()
	{
		data= Excelutils2.testdata();
		return data;

	}
	
	@Test(priority=1,dataProvider="RegisterData")
	public void Registrationcheck(String fname,String lname,String mail,String pass) {
		try {
		Registration_page r1=new Registration_page(driver);
		r1.LoginMousehover();
		r1.Loginbtn();
		r1.Createacnt();
		
		String a1=r1.getURL();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(a1.contains("https://www.biotique.com/account/register"));
		});

		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("RegisterForm-FirstName")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("RegisterForm-LastName")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("RegisterForm-email")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("RegisterForm-password")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//button[@class='form-register']")).isDisplayed());
			
		});
		
		
		r1.firstName(fname);
		r1.Nlastame(lname);
		r1.Mail(mail);
		r1.passWord(pass);
		r1.createbtnClick();
		String p=r1.passwordempty();
		String n1=r1.fnameEmpty();
		String m1=r1.emailEmpty();
		String m2=r1.emailerror();
		
		if(pass.equals(" ")) {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(p.equalsIgnoreCase("Password Can't Be empty!!"));
			});
		}
		else if(fname.equals("")) {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(n1.equalsIgnoreCase("First Name can't be empty!!"));
			});
		}
		else if(mail.equals(" ")) {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(m1.equalsIgnoreCase("Email can't be empty!!"));
			});
		}
		else if(mail.equals("saramail")) {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(m2.equalsIgnoreCase("Email is invalid."));
			});
		}
	}catch (Exception e) {
        e.printStackTrace();
    }
}
}
