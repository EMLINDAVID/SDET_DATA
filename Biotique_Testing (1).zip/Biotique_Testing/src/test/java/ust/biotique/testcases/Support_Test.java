package ust.biotique.testcases;

import org.assertj.core.api.SoftAssertions;
import org.junit.Assert;
import org.openqa.selenium.By;

import org.openqa.selenium.WebElement;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import ust.biotique.base.BaseTest1;
import ust.biotique.pages.Support_page;
import ust.biotique.utils.ExcelUtility4;

@Listeners(ust.biotique.utils.SampleListener.class)
public class Support_Test extends BaseTest1 {
	WebElement element;
	Support_page sup;
	String[][] data;
	
	@DataProvider(name = "testData")
	public Object[][] testdata(){
		data= ExcelUtility4.testdata();
		return data;
	}
	@Test(priority=0,dataProvider = "testData")
    public void supportfield(String name1,String email1,String phn1, String query1){
		
		try
		{
			
		Support_page s=new Support_page(driver);
	    s.Supportclick();
	    String a=s.getURL();
	    
		 SoftAssertions.assertSoftly(softAssertions -> {
		 softAssertions.assertThat(a.contains("https://www.biotique.com/pages/contact"));
		 });		 

		 Thread.sleep(2000);
		 SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.className("page--title")).isDisplayed());});
	
		 SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//a[text()='contact@biotique.com']")).isDisplayed());});
		 
		 SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//a[@href='tel:1800-103-9825']")).isDisplayed());});
		 
		 SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("ContactForm-name")).isDisplayed());});
		
		 SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.id("ContactForm-email")).isDisplayed());});
		 
		 SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.id("ContactForm-phone")).isDisplayed());});
		 
		 SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.id("ContactForm-body")).isDisplayed());});
		 
      	 SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.className("contact-submit")).isDisplayed());});
		 
		s.Name(name1);
		s.Email(email1);
		s.Phone(phn1);
		s.Query(query1);
		s.Submit();
//		SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(driver.findElement(By.xpath("//h3[text()='Thanks for contacting us. We will Get back to you shortly.']")).isDisplayed());});
		s.Home();
	}
	catch (Exception e) {
    e.printStackTrace();
}
	}
	
	@Test(priority=1)
	public void faq() {
		Support_page s=new Support_page(driver);
	    s.Supportclick();
	    s.Faq();
	    String a=s.getURL();
	    
		 SoftAssertions.assertSoftly(softAssertions -> {
		 softAssertions.assertThat(a.contains("https://www.biotique.com/pages/faqs"));
		 });
	    s.Req();
	    s.Home();
	}
}
