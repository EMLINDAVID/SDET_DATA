package com.ustt.Base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

public class DriverConfig {
static WebDriver driver;
	
	public static WebDriver getBrowser() {
		//System.setProperty("webdriver.chrome.driver",
			//	"C:\\Users\\k.kirubakaran\\Downloads\\chromedriver_win32 (12)\\chromedriver.exe");
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		driver=new ChromeDriver(options);
		driver.get("https://www.bunnycart.com/");
		driver.manage().window().maximize();
		return driver;
	}

}
