package com.ustt.POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ustt.Base.BaseUI;

public class CreateAccount extends BaseUI {
	WebDriver driver;
	public CreateAccount(WebDriver driver) {
		// Pass WebDriver as an input to a the constructor 
		this.driver = driver;
		// Call initElements() method by using PageFactory reference and pass driver and this as parameters. 
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath="//a[@href='https://www.bunnycart.com/customer/account/create/']")
	WebElement create;
	
	@FindBy(id = "firstname")
	WebElement first;
	
	@FindBy(id = "lastname")
	WebElement last;
	
	@FindBy(name = "email")
	WebElement email;
	
	@FindBy(id="password")
	WebElement pass;
	
	@FindBy(id="password-confirmation")
	WebElement cpass;
	@FindBy(xpath="//button[contains(@title,'Create')]")
	WebElement submit;
	
	public void ccontact() {
	
		clickOn(create);
	}
	
	public void sendFName(String fname) {
		sendtext(first, fname);
	}
	public void sendLName(String lname) {
		sendtext(last, lname);
	}
	public void sendEmail(String mail) {
		sendtext(email,mail);
	}
	public void sendPass(String password) {
		sendtext(pass,password);
	}
	public void sendCPass(String cpassword) {
		sendtext(cpass,cpassword);
	}
	
	public void ClickCreate() {
		clickOn(submit);
	}
	



}
