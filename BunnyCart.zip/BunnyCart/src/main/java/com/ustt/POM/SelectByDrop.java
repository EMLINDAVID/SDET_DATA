package com.ustt.POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ustt.Base.BaseUI;

public class SelectByDrop extends BaseUI {
	WebDriver driver;
	public SelectByDrop(WebDriver driver) {
		// Pass WebDriver as an input to a the constructor 
		this.driver = driver;
		// Call initElements() method by using PageFactory reference and pass driver and this as parameters. 
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath="(//a[@href='javascript:void(0)'])[1]")
	WebElement selectall;
	
	@FindBy(xpath = "//a[@href='https://www.bunnycart.com/fishes']//span")
	WebElement fish;
	
	@FindBy(xpath = "//a[@href='https://www.bunnycart.com/fishes/guppies']//span")
	WebElement guppy;
	
	@FindBy(xpath = "//a[@href='https://www.bunnycart.com/fishes/chili-red-guppy']")
	WebElement chilliredguppy;
	
	@FindBy(xpath="//button[@id='product-addtocart-button']")
	WebElement addtocart;
	@FindBy(xpath="//div[@data-bind='html: $parent.prepareMessageForHtml(message.text)']")
	WebElement msg;
	
	public void clickall() {
	
		getName(selectall);
	}
	
	public void getFish() {
		getName(fish);
	}
	public void getGuppy() {
		getName(guppy);
		clickOn(guppy);
	}
	public void getRedGuppy() {
		clickOn(chilliredguppy);
	}
	public void addToCart() {
		clickOn(addtocart);
	}
	public String getMsg()
	{
		String s=getTextfromAlertandAccept();
		return s;
	}
}
