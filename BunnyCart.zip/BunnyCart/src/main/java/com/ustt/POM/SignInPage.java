package com.ustt.POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ustt.Base.BaseUI;

public class SignInPage extends BaseUI {
	WebDriver driver;
	public SignInPage(WebDriver driver) {
		// Pass WebDriver as an input to a the constructor 
		this.driver = driver;
		// Call initElements() method by using PageFactory reference and pass driver and this as parameters. 
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath="//a[@href='https://www.bunnycart.com/customer/account/login/']")
	WebElement signin;
	
	@FindBy(id = "email-login")
	WebElement email;
	
	@FindBy(id = "pass-login")
	WebElement password;

	@FindBy(xpath="//button[@id='send2-login']//span")
	WebElement submitsign;
	
	@FindBy(xpath="//li[contains(@class,'greet')]//span")
	WebElement getMsg;
	
	public void Clicksign() {
	
		clickOn(signin);
	}
	
	
	public void sendMail(String mail) {
		sendtext(email,mail);
	}
	public void sendPass(String pass) {
		sendtext(password,pass);
	}
	
	public void ClickSubmit() {
		clickOn(submitsign);
	}
	
  public String Message()
  {
	 String s= getText(getMsg);
	 return s;
  }

}
