package com.ustt.Utilities;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils {
	public static String[][] testdata() {
		FileInputStream fis;
		XSSFWorkbook workbook=null;
			try
			{
			fis=new FileInputStream("C:\\Users\\248796\\eclipse-workspace\\BunnyCart\\src\\test\\resources\\LoginDataBunny.xlsx");
			//.xlsx files (.xls->hssfworkbook)
			workbook=new XSSFWorkbook(fis);
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
			
			XSSFSheet sheet=workbook.getSheetAt(0);
			int rowCount=sheet.getPhysicalNumberOfRows();
			System.out.println("Total number of rows used in sheet: "+rowCount);
			int colCount=sheet.getRow(0).getPhysicalNumberOfCells();
			System.out.println("Total number of columns used in sheet: "+colCount);
			DataFormatter df=new DataFormatter();
			String[][] testdata=new String[rowCount][colCount];
			for (int i = 0; i < rowCount; i++) {
				for (int j = 0; j < colCount; j++) {
					
					testdata[i][j]=df.formatCellValue(sheet.getRow(i).getCell(j));
				}
				
			}
			return testdata;

		}

}
