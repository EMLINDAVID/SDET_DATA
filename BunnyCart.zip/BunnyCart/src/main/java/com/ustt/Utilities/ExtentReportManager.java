package com.ustt.Utilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.ustt.Base.BaseUI;

public class ExtentReportManager extends BaseUI{
	public static ExtentReports extent;
	public static ExtentSparkReporter spark;
	//************Getting report instance for Extent report
	public static ExtentReports getReportInstance() {
	extent=new ExtentReports();
	String repName="TestReport-"+BaseUI.timestamp+".html";
	spark=new ExtentSparkReporter(System.getProperty("user.dir")+"//TestoutputofShop//"+repName);
	extent.attachReporter(spark);
	extent.setSystemInfo("Host Name","UST");
	extent.setSystemInfo("Environment", "Production");
	extent.setSystemInfo("User Name", "kavya");
	spark.config().setDocumentTitle("Product_Shop");
	//name of the report
	spark.config().setReportName("Product Shop Report");
	//dark theme
	spark.config().setTheme(Theme.DARK);
	return extent;
	}
}
