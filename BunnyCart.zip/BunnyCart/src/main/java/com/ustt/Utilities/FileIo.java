package com.ustt.Utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class FileIo {

	private static Properties prop;
	public static Properties initProperties() {
		Properties prop=new Properties();
		try {
			FileInputStream fis=
					new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\Config\\config.properties");
			prop.load(fis);
			System.out.println(prop.getProperty("applicationURL"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return prop;
	}

}
