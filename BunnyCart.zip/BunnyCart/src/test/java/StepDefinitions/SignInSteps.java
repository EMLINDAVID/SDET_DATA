package StepDefinitions;

import org.openqa.selenium.WebDriver;

import com.ustt.Base.DriverConfig;
import com.ustt.POM.SignInPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;





public class SignInSteps {
	public static String title;
	public WebDriver driver=DriverConfig.getBrowser();
	public SignInPage sign=new SignInPage(driver);
	@Given("user is on signin page")
	public void user_is_on_signin_page() {
		driver.get("https://www.bunnycart.com/");
	}

	@When("user enters email {string}")
	public void user_enters_email(String string) {
	    sign.Clicksign();
	    sign.sendMail(string);
	}

	@When("user enters username {string}")
	public void user_enters_username(String string) {
	    sign.sendPass(string);
	}

	@When("user clicks on Login button")
	public void user_clicks_on_login_button() {
	    sign.ClickSubmit();
	}

	@Then("page contains {string}")
	public void page_contains(String string) {
	   String s=sign.Message();
	  
	}


}
