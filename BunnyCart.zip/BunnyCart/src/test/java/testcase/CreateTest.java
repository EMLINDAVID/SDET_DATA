package testcase;

import org.testng.annotations.Test;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ustt.Base.BaseUI;
import com.ustt.POM.CreateAccount;
import com.ustt.POM.SelectByDrop;
import com.ustt.Utilities.ExcelUtils;

public class CreateTest extends BaseUI {
	WebDriver driver;
	CreateAccount account;
	String[][] data;
	
	@BeforeMethod
	public void setup(){
		driver=invokebrowser();
		
		openBrowser("applicationURL");

	}
	
	@DataProvider(name = "testData")
	public Object[][] testdata(){
		data= ExcelUtils.testdata();
		return data;
	}
	
	@Test(priority=0,dataProvider = "testData")
	public void signinTest(String fname,String lname,String email,String pass,String cpass)  {
		CreateAccount account=new CreateAccount(driver);
		
		account.ccontact();
		account.sendFName(fname);
		account.sendLName(lname);
       account.sendEmail(email);
       account.sendPass(pass);
       account.sendCPass(cpass);
       account.ClickCreate();
      
		
}
	@Test(priority=1)
	public void selectByDropTest() throws InterruptedException  {
		SelectByDrop drop=new SelectByDrop(driver);
		
		drop.clickall();
		
		drop.getFish();
		drop.getGuppy();
		//JavascriptExecutor js=(JavascriptExecutor) driver;
		//js.executeScript("window.ScrollBy(0,100)", " ");
		drop.getRedGuppy();
		
		drop.addToCart();
		System.out.println(drop.getMsg());
		
}
}
