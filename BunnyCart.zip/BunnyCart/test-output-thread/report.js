$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"955bfe07-9618-4117-ac42-c563a6fc8ffa","feature":"Login page feature","scenario":"Signin with correct credentials","start":1692891575504,"group":1,"content":"","tags":"","end":1692891584073,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});