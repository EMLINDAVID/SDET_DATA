package com.APITestcases;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.endpoints.UserEndPoints;
import com.payload.UserModel;
import com.utilities.DataProviders;

import io.restassured.RestAssured;
import io.restassured.response.Response;

@Listeners(com.utilities.ExtentReportManager.class)
public class DataDrivenTest {
	@Test(priority=1,dataProvider="data",dataProviderClass=DataProviders.class)
	public void testPostUser(String userID,String title,String dueDate) {
	RestAssured.useRelaxedHTTPSValidation();
	UserModel user=new UserModel();
	user.setId(Integer.parseInt(userID));
	user.setTitle(title);
	user.setDueDate(dueDate);
	
	Response response=UserEndPoints.createUser(user);
	response.then().log().all();
	Assert.assertEquals(response.getStatusCode(),200);
	}
	@Test(priority=2,dataProvider="ids",dataProviderClass=DataProviders.class)
	public void testDeleteById(String id)
	{
		RestAssured.useRelaxedHTTPSValidation();
	Response response=UserEndPoints.deleteUser(Integer.parseInt(id));
	response.then().log().all();
	Assert.assertEquals(response.getStatusCode(),200);
	}


}
