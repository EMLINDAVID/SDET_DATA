package com.APITestcases;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.endpoints.UserEndPoints;
import com.payload.UserModel;
import com.utilities.DataProviders;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class UserTests {
	
    UserModel userPayload;
   
    @Test(priority = 1,dataProvider="data",dataProviderClass=DataProviders.class)
    public void testPostUser(String userID,String title,String dueDate) {
    	RestAssured.useRelaxedHTTPSValidation();
    	UserModel user=new UserModel();
    	user.setId(Integer.parseInt(userID));
    	user.setTitle(title);
    	user.setDueDate(dueDate);
    	
    	Response response=UserEndPoints.createUser(user);
    	response.then().log().all();
    	Assert.assertEquals(response.getStatusCode(),200);
    	}
    @Test(priority=2,dataProvider="ids",dataProviderClass=DataProviders.class)
    public void testGetUserById(String id)
    {
        Response response = UserEndPoints.getUser(Integer.parseInt(id));
       response.then().log().all();
       Assert.assertEquals(response.getStatusCode(),200);
    }
    @Test(priority=3,dataProvider="data",dataProviderClass=DataProviders.class)
    public void testGetUser(String userID,String title,String dueDate)
    {
        Response response = UserEndPoints.getUser1();
       response.then().log().all();
       Assert.assertEquals(response.getStatusCode(),200);
    }
   @Test(priority = 3,dataProvider="updates",dataProviderClass=DataProviders.class)
    public void testUpdateuserById(String userID,String title,String dueDate)
    {
    	RestAssured.useRelaxedHTTPSValidation();
	UserModel user=new UserModel();
	user.setId(Integer.parseInt(userID));
	user.setTitle(title);
	user.setDueDate(dueDate);
        
        Response response = UserEndPoints.updateUser(Integer.parseInt(userID),user);
        response.then().log().all();
        Assert.assertEquals(response.getStatusCode(),200);
        
    }
    /*@Test(priority = 4)
    public void testDeleteUserByName()
    {
        Response response = UserEndPoints.deleteUser(this.userPayload.getUsername());
        response.then().log().all();
        Assert.assertEquals(response.getStatusCode(),200);
    }*/

}
