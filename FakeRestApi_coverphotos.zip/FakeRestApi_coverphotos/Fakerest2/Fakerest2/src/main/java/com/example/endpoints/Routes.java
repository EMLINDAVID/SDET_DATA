package com.example.endpoints;

public class Routes {
	
	public static String baseuri="https://fakerestapi.azurewebsites.net/api/v1";
	public static String get_basePath1="/CoverPhotos";
	public static String get_basePath2="/CoverPhotos/books/covers/{id}";
	public static String get_basePath3="/CoverPhotos/{id}";
	public static String post_basePath="/CoverPhotos";
	public static String put_basePath="/CoverPhotos/{id}";
	public static String delete_basePath="/CoverPhotos/{id}";



	

}
