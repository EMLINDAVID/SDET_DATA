package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Base.BaseUI;
import Utilities.Excelutility2;

public class BankLogin extends BaseUI {
WebDriver driver;
	
	public BankLogin(WebDriver driver) {
 this.driver=driver;
	}
	
	By managerLogin=getlocator("managerbanklogin_xpath");
//	By customerlog=getlocator("coustomerlogin_xpath");
	By addcus=getlocator("addcustomer_xpath");
	By firstName=getlocator("firstname_xpath");
	By lastName=getlocator("lastname_xpath");
	By post=getlocator("post_xpath");
	By submit=getlocator("submit_xpath");
	By OpenAccount=getlocator("openaccount_xpath");
	By CustomerNamedropdown=getlocator("customernamedropdown_id");
	By CurrencyDropDown=getlocator("currencydropdown_id");
	By ProcessOpenAccount=getlocator("processopenaccount_xpath");
	By CustomerLast=getlocator("customerlast_xpath");
	By CustomerSearch=getlocator("customersearch_xpath");
	By CustomerDelete=getlocator("customerdelete_xpath");
	By Homebtn2=getlocator("Homebtn2_xpath");
	
	String name="anu";
	public void manager() {
 clickOn(managerLogin);
	}
//	public void customer() {
// clickon(customerlog);
//	}
//	
	public void addcustomer() {
 clickOn(addcus);
	}
	public void firstName(String firstname) {
 sendtext(firstName, firstname);
	}
	public void lastname(String lastname) {
 sendtext(lastName, lastname);
	}
	
	public void postcode(String postcode) {
 sendtext(post, postcode);
	}
	public void submit() {
 clickOn(submit);
	}
	public void openaccount() {
		 clickOn(OpenAccount);
			}
			
			public void customernamedropdown() {
		 dropcreate(CustomerNamedropdown);
			}
			
			public void currencydropdown() {
		 getName(CurrencyDropDown);
			}
			
			public void processopenaccount() {
		 clickOn(ProcessOpenAccount);
			}
			
			public void customerlast() {
		 clickOn(CustomerLast);
			}
			
			public void customersearch() {
		 sendtext(CustomerSearch, name);
			}
			
			public void customerdelete() {
		 clickOn(CustomerDelete);
			}
			public void  Home2() {
				clickOn(Homebtn2);
			}
}


