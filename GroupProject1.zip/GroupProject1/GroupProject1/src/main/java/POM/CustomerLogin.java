package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Base.BaseUI;

public class CustomerLogin extends BaseUI{

	WebDriver driver;
	public CustomerLogin(WebDriver driver) {
		this.driver=driver;
	}
	By Custlog=getlocator("custlog_xpath");
	By yourname=getlocator("yourname_name");
	By yournamelogin=getlocator("Login_xpath");
	By number=getlocator("Number_name");
	By transac=getlocator("Trans_xpath");
	By back=getlocator("back_xpath");
	By depo=getlocator("Deposit_xpath");
	By amount=getlocator("Depositamnt_xpath");
	By depobtn=getlocator("Depositbtn_xpath");
	By withdraw=getlocator("Wthrawal_xpath");
	By withamount=getlocator("Withamnt_xpath");
	By withbtn=getlocator("Withbtn_xpath");
	By Homebtn=getlocator("Homebtn_xpath");
	By logout=getlocator("logout_xpath");
	
	public void YourName() {
		getName(yourname);
	}
	public void getnum() {
		getName(number);
	}
	public void Custlog() {
		clickOn(Custlog);
	}
	public void YourNameLogin() {
		clickOn(yournamelogin);
	}
	public void Trans() {
		clickOn(transac);
	}
	public void Back() {
		clickOn(back);
	}
	public void Deposit() {
		clickOn(depo);
	}
	public void Amount() {
		getAmount(amount);
	}
	public void DepoBtn() {
		clickOn(depobtn);
	}
	public void Withdraw() {
		clickOn(withdraw);
	}
	public void WithAmount() {
		getAmount1(withamount);
	}
	public void WithBtn() {
		clickOn(withbtn);
	}
	
	public void  Home() {
		clickOn(Homebtn);
	}
	public void logout() {
		clickOn(logout);
	}

}