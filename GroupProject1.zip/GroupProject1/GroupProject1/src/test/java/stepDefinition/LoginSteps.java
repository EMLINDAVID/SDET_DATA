package stepDefinition;

import org.openqa.selenium.WebDriver;

import Base.BaseUI;
import Base.BrowserConfig;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps extends BaseUI{
	WebDriver driver;
	@Given("Open chrome and go to application")
	public void open_chrome_and_go_to_application() {
	    // Write code here that turns the phrase above into concrete actions
	   driver=BrowserConfig.getBrowser();
	   invokeBrowser();
	}

	@When("I login with valid credentials")
	public void i_login_with_valid_credentials() {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("I should be able to login succesfully")
	public void i_should_be_able_to_login_succesfully() {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("I login with invalid credentials")
	public void i_login_with_invalid_credentials() {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("I should be able to login")
	public void i_should_be_able_to_login() {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

}
