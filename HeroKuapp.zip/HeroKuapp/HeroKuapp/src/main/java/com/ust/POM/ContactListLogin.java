package com.ust.POM;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.Status;
import com.ust.Base.BaseUI6;
public class ContactListLogin extends BaseUI6 
{
	WebDriver driver;
	public ContactListLogin(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(id="email")
	WebElement Email;
	
	@FindBy(id="password")
	WebElement passWord;
	
	@FindBy(id="submit")
	WebElement submit;
	
	@FindBy(id="firstName")
	WebElement firstName;
	
	@FindBy(id="add-contact")
	WebElement addcontactbtn;
	
	@FindBy(id="lastName")
	WebElement lastName;
	
	@FindBy(id="error")
	WebElement errorm;
	
	@FindBy(id="signup")
	WebElement submit1;
	
	@FindBy(id="add-user")
	WebElement SignupMsg;
	
	@FindBy(id="firstName")
	WebElement FirstName1;
	
	@FindBy(id="lastName")
	WebElement lastName1;
	
	@FindBy(id="birthdate")
	WebElement Dob;
	
	@FindBy(id="email")
	WebElement Email1;
	
	@FindBy(id="phone")
	WebElement ph;
	
	@FindBy(id="street1")
	WebElement streets1;
	
	@FindBy(id="street2")
	WebElement streets2;
	
	@FindBy(id="city")
	WebElement city;
	
	@FindBy(id="state")
	WebElement state;
	
	@FindBy(id="postalCode")
	WebElement postal;
	
	@FindBy(id="country")
	WebElement country;
	
	@FindBy(id="submit")
	WebElement submit2;
	
	@FindBy(xpath="//*[@id=\"myTable\"]/tr[1]")
	WebElement clicktable;
	
	@FindBy(id="edit-contact")
	WebElement edit;
	
	@FindBy(id="return")
	WebElement clicktreturn;
	
	@FindBy(id="delete")
	WebElement clickdelete;
	
	
	@FindBy(id="logout")
	WebElement clicklogout;
	
	
	public void Email(String mailid) 
	{
		sendtext(Email,mailid);
		logger.log(Status.INFO,"Email is entered");
	}
	public void passWord(String pass) 
	{
		sendtext(passWord,pass);
		logger.log(Status.INFO,"password is entered");
	}
	public void firstName(String first) 
	{
		sendtext(firstName,first);
		logger.log(Status.INFO,"fname is entered");
	}
	public void lastName(String last) 
	{
		sendtext(lastName,last);
		logger.log(Status.INFO,"lname is entered");
	}
	public void submit() 
	{
		clickOn(submit);
		logger.log(Status.INFO,"submit is clicked");
	}
	 public String getURL()
	{
		String url=driver.getCurrentUrl();
		logger.log(Status.INFO,"url retrieved");
		return url;
	}
	 public String errorm()
	 {	
		 logger.log(Status.INFO,"Errormessage retrieved");
		return rettext(errorm);
		
	}
	public void submit1() 
	{	
		clickOn(submit1);
		logger.log(Status.INFO,"signup is clicked");
	}
	public String SignupMsg()
	{
		logger.log(Status.INFO,"signup message retrieved");
		return rettext(SignupMsg);
	}
	
	public void Firstname1(String fname1) {
		sendtext(FirstName1,fname1);
		logger.log(Status.INFO,"firstname is entered");
		
	}
	public void lastname1(String lname1) {
		sendtext(lastName1,lname1);
		logger.log(Status.INFO,"lastname is entered");
	}
	public void Dob(String dob) {
		sendtext(Dob,dob);
		logger.log(Status.INFO,"dob is entered");
	}
	public void Email1(String mailid1) {
	   sendtext(Email1,mailid1);
	   logger.log(Status.INFO,"email is entered");
	}
	public void ph(String phonenumber) {
	sendtext(ph,phonenumber);
	logger.log(Status.INFO,"phone is entered");
	}
	public void streets1(String address1) {
		sendtext(streets1,address1);
		logger.log(Status.INFO,"address1 is entered");
	}
	public void streets2(String address2) {
		sendtext(streets2,address2);
		logger.log(Status.INFO,"address2 is entered");
	}
	public void city(String city1) {
		sendtext(city,city1);
		logger.log(Status.INFO,"city is entered");
	}
	public void state(String State) {
		sendtext(state,State);
		logger.log(Status.INFO,"state is entered");
	}
	public void postal(String postalcode) {
		sendtext(postal,postalcode);
		logger.log(Status.INFO,"postalcode is entered");
	}
	public void country(String country1) {
		sendtext(country,country1);
		logger.log(Status.INFO,"country is entered");
	}
	public void submit2() {
	clickOn(submit1);
	logger.log(Status.INFO,"submit clicked");
	}
	public void addcontact() {
	 clickOn(addcontactbtn);
	 logger.log(Status.INFO,"addcontact clicked");
	}
	public void clicktable()
	{
		clickOn(clicktable);
		logger.log(Status.INFO,"contact list  row clicked");
	}
	public void clicktreturn()
	{
		clickOn(clicktreturn);
		logger.log(Status.INFO,"return to contact clicked");
	}
	public void clickdelete()
	{
		clickOn(clickdelete);
		logger.log(Status.INFO,"delete clicked");
	}
	public void clicklogout()
	{
		clickOn(clicklogout);
		logger.log(Status.INFO,"logout clicked");
	}
	

}