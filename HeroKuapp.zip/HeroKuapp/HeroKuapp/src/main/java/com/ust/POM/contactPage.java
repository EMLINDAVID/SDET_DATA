package com.ust.POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.Base.BaseUI6;

public class contactPage extends BaseUI6 {
	
	WebDriver driver;

	public contactPage(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}	  
	  @FindBy(id="email")
	  WebElement Email;
	  
	  @FindBy(id="password")
	  WebElement password;
	  
	  @FindBy(id="submit")
	  WebElement submit;
	  
	  public String getTitle() {
	  return driver.getTitle();
	  }
	  

	 
	  public void Email(String email) {
		  sendtext(Email,email);
		  }
	  public void password(String uname) {
		  sendtext(password,uname);
		  }
	  
	  public void submit() {
		  clickOn(submit);
		  }

	

}
