package stepDefinitionss;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import com.ust.Base.BrowserConfig6;
import com.ust.POM.contactPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Loginstepss {
	public static String title;
	public WebDriver driver1=BrowserConfig6.getBrowser();
	public contactPage c1=new contactPage(driver1);
	@Given("user is on login page")
	public void user_is_on_login_page() {
		driver1.get("https://thinking-tester-contact-list.herokuapp.com/");
	}

	@When("user gets the title of the page")
	public void user_gets_the_title_of_the_page() {
		title=c1.getTitle();
		System.out.println(title);
	
	}

	@Then("page title should be {string}")
	public void page_title_should_be(String string) {
		title=c1.getTitle();
		Assert.assertEquals(title,string);
	}

	@When("user enters email {string}")
	public void user_enters_email(String string) {
		contactPage c1=new contactPage(driver1);
		c1.Email(string);
	}

	@When("user enters username {string}")
		public void user_enters_username(String string) {
			c1.password(string);
	}

	@When("user clicks on submit button")
	public void user_clicks_on_submit_button() {
		c1.submit();
	}


}
