$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"35d881e9-999b-4fca-a087-e9fa8ab80ab2","feature":"Login page feature","scenario":"Login page title","start":1691610186839,"group":1,"content":"","tags":"","end":1691610194233,"className":"passed"},{"id":"83fa4c88-b09b-4ad3-b576-96dd476e82dd","feature":"Login page feature","scenario":"Login with correct credentials","start":1691610194252,"group":1,"content":"","tags":"","end":1691610198820,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});