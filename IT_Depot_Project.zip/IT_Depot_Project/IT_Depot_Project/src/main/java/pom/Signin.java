package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import base.baseUI;

public class Signin extends baseUI {

	WebDriver driver;
	public Signin(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
//	By login=getlocator("login_xpath");
//	By user=getlocator("username_xpath");
//	By pass=getlocator("password_xpath");
//	By signin=getlocator("signin_xpath");
//	By categories=getlocator("categories_xpath");
//	By gamingheadphone=getlocator("gamingheadphone_xpath");
//	By checkbox=getlocator("checkbox_xpath");
//	By drop=getlocator("drop_xpath");
//	By dropselect=getlocator("dropselect_xpath");
//	By product=getlocator("productselect_xpath");
//	By logout=getlocator("logout_linkText");
//	
//	login_xpath=//a[@class='btn btn-sm btn-info mb-2 px-2']
//			username_xpath=//input[@id='username']
//			password_xpath=//input[@id='password']
//			signin_xpath=//button[@class='btn btn-block btn-success']
//			categories_xpath=//a[@class='btn btn-outline-secondary1 dropdown-toggle pr-4']
//			gamingheadphone_xpath=//a[text()='Gaming Headphones']
//			checkbox_xpath=//*[@id="brand_filter2"]
//			drop_xpath=//select[@class='form-control border-left-0 bg-light2']
//			dropselect_xpath=//option[text()='Brand : A to Z']
//			productselect_xpath=(//img[@class='p-1 w100 img-gray'])[1]
//			logout_linkText=Logout
	
	
	@FindBy(xpath = "//a[@class='btn btn-sm btn-info mb-2 px-2']")
	WebElement login;
	
	@FindBy(xpath = "//input[@id='username']")
	WebElement user;
	
	@FindBy(xpath = "//input[@id='password']")
	WebElement pass;
	
	@FindBy(xpath = "//button[@class='btn btn-block btn-success']")
	WebElement signin;
	
	@FindBy(xpath = "/a[@class='btn btn-outline-secondary1 dropdown-toggle pr-4']")
	WebElement categories;
	
	@FindBy(xpath = "//a[text()='Gaming Headphones']")
	WebElement gamingheadphone;
	
	@FindBy(xpath = "//*[@id=\"brand_filter2\"]")
	WebElement checkbox;
	
	@FindBy(xpath = "//select[@class='form-control border-left-0 bg-light2']")
	WebElement drop;
	
	@FindBy(xpath = "///option[text()='Brand : A to Z']")
	WebElement dropselect;
	
	@FindBy(xpath = "(//img[@class='p-1 w100 img-gray'])[1]")
	WebElement product;
	
	@FindBy(linkText = "//input[@id='loginpassword']")
	WebElement logout;
	
	public void Login()
	{
		clickOn(login);
		
	}
	
	
	public void User(String user1)
	{
		sendtext(user,user1);
	}
	
	
	
	public void Password(String pass1)
	{
		sendtext(pass,pass1);
	}
	public void Signin()
	{
		clickOn(signin);
		
	}
	public void Categories()
	{
		clickOn(categories);
		
	}
	public void Gaming()
	{
		clickOn(gamingheadphone);
	}
	
	public void Check()
	{
		clickOn(checkbox);
	}
	
	public void Dropp()
	{
		clickOn(drop);
	}
	public void DropSelect()
	{
		clickOn(dropselect);
	}
	public void Product() {
		clickOn(product);
	}
	public void Logout() {
		clickOn(logout);
	}
	
}
