package StepDefinitionss;






import org.junit.Assert;
import org.openqa.selenium.WebDriver;




import base.BrowserConfig;
import base.baseUI;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.Loginpage;


public class Loginstepsz extends baseUI{
	private static String title;
	public WebDriver driver=BrowserConfig.getBrowser();
	public Loginpage login=new Loginpage(driver);
	
	
	@Given("user is on login page")
	public void user_is_on_login_page() {
		driver.get("https://www.theitdepot.com");
	}

	@When("user gets the title of page")
	public void user_gets_the_title_of_page() {
		title=login.getLoginPageTitle();
		System.out.println(title);
	}

	@Then("page title be {string}")
	public void page_title_be(String titlename) {
		title=login.getLoginPageTitle();
		Assert.assertEquals("THEITDEPOT",titlename);//title.contains(expectedtitlename)
	}
	
	@When("user gets category button")
	public void user_gets_category_button() {
	    login.CategoryClick();
	}

	@When("user clicks on category button")
	public void user_clicks_on_category_button() {
	    login.CategoryClick();
	}
}