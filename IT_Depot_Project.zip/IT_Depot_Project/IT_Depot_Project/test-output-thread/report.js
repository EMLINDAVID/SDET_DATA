$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"e9a2db69-f3eb-42d8-a8d7-f5d7274be52e","feature":"Login page feature","scenario":"Login page title","start":1691636372855,"group":1,"content":"","tags":"","end":1691636390267,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});