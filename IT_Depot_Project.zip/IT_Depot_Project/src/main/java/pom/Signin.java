package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;



import base.baseUI;

public class Signin extends baseUI {

	WebDriver driver;
	public Signin(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By login=getlocator("login_xpath");
	By user=getlocator("username_xpath");
	By pass=getlocator("password_xpath");
	By signin=getlocator("signin_xpath");
	By categories=getlocator("categories_xpath");
	By gamingheadphone=getlocator("gamingheadphone_xpath");
	By checkbox=getlocator("checkbox_xpath");
	By drop=getlocator("drop_xpath");
	By dropselect=getlocator("dropselect_xpath");
	By product=getlocator("productselect_xpath");
	
	public void Login()
	{
		clickOn(login);
		
	}
	
	
	public void User(String user1)
	{
		sendtext(user,user1);
	}
	
	
	
	public void Password(String pass1)
	{
		sendtext(pass,pass1);
	}
	public void Signin()
	{
		clickOn(signin);
		
	}
	public void Categories()
	{
		clickOn(categories);
		
	}
	public void Gaming()
	{
		clickOn(gamingheadphone);
	}
	
	public void Check()
	{
		clickOn(checkbox);
	}
	
	public void Dropp()
	{
		clickOn(drop);
	}
	public void DropSelect()
	{
		clickOn(dropselect);
	}
	public void Product() {
		clickOn(product);
	}

	


	
}
