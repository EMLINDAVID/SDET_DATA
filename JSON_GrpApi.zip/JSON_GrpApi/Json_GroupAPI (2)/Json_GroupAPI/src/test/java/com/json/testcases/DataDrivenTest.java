package com.json.testcases;

import org.junit.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.json.endpoints.UserEndPoints;
import com.json.payload.UserModel;
import com.json.utility.DataProviders;

import io.restassured.RestAssured;
import io.restassured.response.Response;
@Listeners(com.json.utility.ExtentReportManager.class)
public class DataDrivenTest {
	@Test(priority=1,dataProvider="data",dataProviderClass=DataProviders.class)
	public void testPostUser(String postID,String id,String name,String email,String body) {
	RestAssured.useRelaxedHTTPSValidation();
	UserModel user=new UserModel();
	user.setPostId(Integer.parseInt(postID));
	user.setId(Integer.parseInt(id));
	user.setName(name);
	user.setEmail(email);
	user.setBody(body);
	Response response=UserEndPoints.createUser(user);
	response.then().log().all();
	Assert.assertEquals(response.getStatusCode(),201);
	}
	@Test(priority=2,dataProvider="UserNames",dataProviderClass=DataProviders.class)
	public void testGetUserByName(String id)
    {
        Response response = UserEndPoints.getUser(id);
       response.then().log().all();
       Assert.assertEquals(response.getStatusCode(),200);
    }
	@Test(priority=3,dataProvider="UserNames",dataProviderClass=DataProviders.class)
	public void testUpdateByUserName(String id) {
	UserModel payload=new UserModel();
	RestAssured.useRelaxedHTTPSValidation();
	Response response=UserEndPoints.updateUser(id,payload);
	response.then().log().all();
	Assert.assertEquals(response.getStatusCode(),200);
	}
	@Test(priority=4,dataProvider="UserNames",dataProviderClass=DataProviders.class)
	public void testDeleteByUserName(String id) {
		RestAssured.useRelaxedHTTPSValidation();
		Response response=UserEndPoints.deleteUser(id);
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(),200);
	}
	
}
