package com.ust.POM;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.Base.BaseUI;

public class CreateLogin extends BaseUI{
	WebDriver driver;
	WebDriverWait wait ;
	public CreateLogin(WebDriver driver)//avoid nullpoint exception
	{
		this.driver=driver;
		wait=new WebDriverWait(driver, Duration.ofSeconds(10));
	}
	//locators
	By create=getlocator("create_xpath");
	By firstname=getlocator("firstname_id");
			By lastname=getlocator("lastname_id");
			By email=getlocator("email_id");
			By pass=getlocator("password_id");
			By confirm=getlocator("confirm_id");
			By submit=getlocator("submit_xpath");
			By confirmerror=getlocator("passwordconfirmerror_id");

	//elements as methods
	public void createA() {
		 wait.until(ExpectedConditions.elementToBeClickable(create));
		clickOn(create);
	}


	public void firstName(String first)
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(firstname));
		sendtext(firstname,first);
		
	}
	public void lastName(String last)
	{
		
		sendtext(lastname,last);
		
	}
	public void eMail(String mail)
	{
		
		sendtext(email,mail);
		
	}
	public void passWord(String pp)
	{
		
		sendtext(pass,pp);
		
	}
	public void confirmPass(String cp)
	{
		
		sendtext(confirm,cp);
		
	}
	public void SubmitCreate()
	{
		clickOn(submit);
	}
  public String Confirmerror() {
	  return rettext(confirmerror);
  }
  public void clearPas() {
	  clear(confirm);
  }
  

}
