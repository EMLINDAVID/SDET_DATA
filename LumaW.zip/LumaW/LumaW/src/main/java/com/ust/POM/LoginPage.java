package com.ust.POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
	private WebDriver driver;
	public LoginPage(WebDriver driver) {
	this.driver=driver;
	}
	
	By login=By.xpath("//li[@class='authorization-link']");
	By emailid=By.id("email");
	By pwd=By.id("pass");
	By signInButton = By.id("send2");
	
	
	public String getLoginPageTitle() {
		return driver.getTitle();
	}

	public void loginPage() {
		driver.findElement(login).click();
	}
	
	
	public void sendusername(String username) {
		driver.findElement(emailid).sendKeys(username);
	}
	
	public void sendPassword(String password) {
		driver.findElement(pwd).sendKeys(password);
	}
	
	public void clickSubmit() {
		driver.findElement(signInButton).click();
		
	}

}
