package com.ust.POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.ust.Base.BaseUI;

public class Luma extends BaseUI {
	WebDriver driver;
	public Luma(WebDriver driver) {
		this.driver=driver;
		
	}
	By menclick=getlocator("Men_linkText");
	By top=getlocator("Top_linkText");
	By jacket=getlocator("jacket_id");
	By selectjacket=getlocator("selectedjacket_xpath");
	By size=getlocator("size_xpath");
	By color=getlocator("color_xpath");
	By submit=getlocator("cart_xpath");
	By cart=getlocator("mycart_xpath");
	By home=getlocator("home_xpath");
	
	public void men() {
		getName(menclick);
	}
	public void top() {
		getName(top);
	}
	public void jack() {
		clickOn(jacket);
	}
	public void sjack() {
		clickOn(selectjacket);
	}
	public void Size() {
		clickOn(size);
	}
	public void Color() {
		clickOn(color);
	}
	public void Submit() {
		clickOn(submit);
	}
	public String carts() {
		String s=rettext(cart);
		return s;
		
		
	}
	public void homes() {
		clickOn(home);
	}
	}

