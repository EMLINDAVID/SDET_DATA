package com.ust.POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.ust.Base.BaseUI;

public class Order extends BaseUI {
	WebDriver driver;
	public Order(WebDriver driver) {
	this.driver=driver;
	}
	By searchbox=getlocator("Searchbox_name");
	By sortlist=getlocator("sort_id");
	By sweatshirt=getlocator("Sweatshirt_xpath");
	By size=getlocator("Size_xpath");
	By colour =getlocator("Colour_xpath");
	By quantity=getlocator("Quantity_name");
	By cart=getlocator("Cart_id");
	By home=getlocator("home_xpath");
	public void Search(String searchtext) {
	sendtext(searchbox,searchtext);
	}
	public void searchIcon() {
	Enter(searchbox);
	}
	public void shirtSelect() {
	clickOn(sweatshirt);
	}
	public void priceSort() {
	int num=1;
	sort(sortlist, num);
	}
	public void sizeSelect() {
	clickOn(size);
	}
	public void colourSelect() {
	clickOn(colour);
	}
	public void quantclear() {
	clear(quantity);
	}
	public void quantadd(String value) {
	sendtext(quantity,value);
	}
	public void cartAdd() {
	clickOn(cart);
	}
	public void homes() {
		clickOn(home);
	}
	}








