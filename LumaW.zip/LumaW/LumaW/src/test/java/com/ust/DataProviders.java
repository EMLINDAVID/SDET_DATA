package com.ust;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataProviders {

	@Test(dataProvider = "testData")
	public void testcase1(String username,String password) {
		System.out.println(username+" "+password);
	}
	
}

