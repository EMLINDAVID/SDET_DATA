package com.ust.testcases;

import static org.assertj.core.api.Assertions.byLessThan;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.Base.BaseUI;
import com.ust.POM.CreateLogin;
import com.ust.POM.Luma;
import com.ust.POM.Order;
import com.ust.Utilities.Excelutils;
@Listeners(com.ust.Utilities.SampleListener.class)
public class CreateloginTest  extends BaseUI {
	WebDriver driver;
	CreateLogin acc;
	String[][] data;
	By  create1=getlocator("create_xpath");
	By submit1=getlocator("submit_xpath");
	By thankumsg=getlocator("thankyou_xpath");
	By serachboxn=getlocator("Searchbox_name");
	By sizesearch=getlocator("Size_xpath");
	By colorsearch=getlocator("Colour_xpath");
	By cartButton=getlocator("Cart_id");
	By menclick=getlocator("Men_linkText");
	@BeforeTest
	public void setup(){
		driver=invokebrowser();
		
		openBrowser("applicationURL");

	}
	@DataProvider(name = "testData")
	public Object[][] testdata(){
		data= Excelutils.testdata();
		return data;
	}
	
	@SuppressWarnings("unlikely-arg-type")
	@Test(priority=0,dataProvider = "testData")
	public void loginTest(String fn,String ln,String em,String pass,String cpass) {
		CreateLogin acc=new CreateLogin(driver);
		
		SoftAssertions.assertSoftly(softAssertions -> {
		softAssertions.assertThat(driver.findElement(create1).isEnabled());});
		acc.createA();
		acc.firstName(fn);
		acc.lastName(ln);
		acc.eMail(em);
		acc.passWord(pass);
		acc.confirmPass(cpass);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(submit1).isDisplayed());});
			
		acc.SubmitCreate();
		
		if(!(pass.equals(cpass)))
		{
			String s=pass;
			acc.clearPas();
			acc.confirmPass(s);
			acc.SubmitCreate();
		}
	
		String msg="Thank you for registering with Main Website Store.";
		SoftAssertions.assertSoftly(softAssertions -> {
		softAssertions.assertThat(driver.findElement(thankumsg).equals(msg));});
		
	
			
	
}
	@Test(priority=1)
	public void searchTest() throws InterruptedException {
	Order o=new Order(driver);
	o.Search("sweatshirt for men");
	Thread.sleep(3000);
	SoftAssertions.assertSoftly(softAssertions -> {
	softAssertions.assertThat(driver.findElement(serachboxn).isDisplayed());
	});
	o.searchIcon();
	String str="https://magento.softwaretestingboard.com/catalogsearch/result/?q=sweatshirt+for+men";
	SoftAssertions.assertSoftly(softAssertions -> {
	softAssertions.assertThat(driver.getCurrentUrl().equals(str));
	});
	o.priceSort();
	o.shirtSelect();
	o.sizeSelect();
	SoftAssertions.assertSoftly(softAssertions -> {
	softAssertions.assertThat(driver.findElement(sizesearch).isSelected());
	});
	         o.colourSelect();
	SoftAssertions.assertSoftly(softAssertions -> {
	softAssertions.assertThat(driver.findElement(colorsearch).isSelected());
	});
	         o.quantclear();
	         o.quantadd("2");
	o.cartAdd();
	SoftAssertions.assertSoftly(softAssertions -> {
	softAssertions.assertThat(driver.findElement(cartButton).isDisplayed());
	});
	o.homes();
	}
	@Test(priority = 2)
	public void Mentest() throws InterruptedException {
		Luma l=new Luma(driver);
		SoftAssertions.assertSoftly(softAssertions -> {
			 softAssertions.assertThat(driver.findElement(menclick).isDisplayed());
		});
		
		l.men();
	
		SoftAssertions.assertSoftly(softAssertions -> {
			 softAssertions.assertThat(driver.findElement(By.linkText("Tops")).isDisplayed());
		});
	
		l.top();
		
	
		l.jack();
		String j="https://magento.softwaretestingboard.com/men/tops-men/jackets-men.html";
		SoftAssertions.assertSoftly(softAssertions -> {
			 softAssertions.assertThat(driver.getCurrentUrl().equals(j));
		});
		
	
		l.sjack();
		SoftAssertions.assertSoftly(softAssertions -> {
			 softAssertions.assertThat(driver.findElement(By.xpath("(//a[@class='product-item-link'])[1]")).isDisplayed());
		});
	
	
		l.Size();
		
		SoftAssertions.assertSoftly(softAssertions -> {
			 softAssertions.assertThat(driver.findElement(By.xpath("(//div[@class='swatch-option text'])[4]")).isDisplayed());
		});
	
	
		
		l.Color();
		SoftAssertions.assertSoftly(softAssertions -> {
			 softAssertions.assertThat(driver.findElement(By.xpath("(//div[@class='swatch-option color'])[2]")).isDisplayed());
		});
		l.Submit();
		int num=Integer.parseInt(l.carts());
		int value=3;
		SoftAssertions.assertSoftly(softAssertions -> {
			 softAssertions.assertThat(num==value	);
	});
	
	
		l.homes();
	
}}


