$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"35e9304c-1f7f-4814-be31-f253d4aedad4","feature":"Login page feature","scenario":"Login with correct credentials","start":1691505918630,"group":1,"content":"","tags":"","end":1691505931938,"className":"passed"},{"id":"dfcf7d1e-7cd2-45d7-ad97-17ff02c02b94","feature":"Login page feature","scenario":"Login page title","start":1691505907411,"group":1,"content":"","tags":"","end":1691505918610,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});