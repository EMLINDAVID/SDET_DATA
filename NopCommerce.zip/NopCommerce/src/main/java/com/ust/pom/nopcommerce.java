package com.ust.pom;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.base.BaseUI;


public class nopcommerce extends BaseUI {
	WebDriver driver;

	public nopcommerce(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}	  
		
	@FindBy(xpath="/html/body/div[6]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")
	  WebElement Login;
	
	  @FindBy(id="Email")
	  WebElement Email;
	  
	  @FindBy(id="Password")
	  WebElement Password;
	  
	  @FindBy(xpath="//button[@class='button-1 login-button']")
	  WebElement submit;
	  
//	  @FindBy(id="Email-error")
//	  WebElement errorm;
//	  
//	  @FindBy(id="FirstName")
//	  WebElement FirstName;
//	  
//	  @FindBy(id="LastName")
//	  WebElement LastName;
//	  
//	  @FindBy(id="Email")
//	  WebElement Email1;
//	  
//	  @FindBy(id="Password")
//	  WebElement Password1;
//	  
//	  @FindBy(id="ConfirmPassword")
//	  WebElement ConfirmPassword;
//	  
//	  @FindBy(id="register-button")
//	  WebElement register;
//	  
//	  @FindBy(xpath="//a[text()='Register']")
//	  WebElement reg1;
//	  
//	  @FindBy(xpath="//a[text()='Electronics ']")
//	  WebElement electronics;
//	  
//	  @FindBy(xpath="//a[text()='Cell phones ']")
//	  WebElement cellphone;
//	 
//	  
//	  @FindBy(xpath="//a[text()='HTC One Mini Blue']")
//	  WebElement phone1;
//	  
//	  @FindBy(id="add-to-cart-button-19")
//	  WebElement cart;
	  
	  public String getTitle() {
	  return driver.getTitle();
	  }
	  public void login() {
		  clickOn(Login);
		  }
	  public void Email(String email) {
		  sendtext(Email,email);
		  }
	  public void password(String uname) {
		  sendtext(Password,uname);
		  }
	  
	  public void submit() {
		  clickOn(submit);
		  }
//	  public String errorm()
//		 {	
//			
//			return rettext(errorm);
//		}
//	  public void FirstName(String fname) {
//		  sendtext(FirstName,fname);
//	  }
//	  public void Email1(String email) {
//		  sendtext(Email1,email);
//	  }
//	  public void Password1(String pwd) {
//		  sendtext(Password1,pwd);
//	  }
//	  public void LastName(String lname) {
//		  sendtext(LastName,lname);
//	  }
//	  public void confirmPas(String cpas) {
//		  sendtext(ConfirmPassword,cpas);
//	  }
//	  public void Register() {
//		  clickOn(register);
//	  }
//	  public void Register1() {
//		  clickOn(reg1);
//	  }
//	  public void Electronics() {
//		  clickOn(electronics);
//	  }
//	  public void cellPhoneClick() {
//		  clickOn(cellphone);
//	  }
//	  public void phoneClick() {
//		  clickOn(phone1);
//	  }
//	  public void cartClick() {
//		  clickOn(cart);
//	  }
}
