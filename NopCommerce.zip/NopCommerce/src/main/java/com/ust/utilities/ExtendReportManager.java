
package com.ust.utilities;

import com.aventstack.extentreports.ExtentReports;

import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.ust.base.BaseUI;



public class ExtendReportManager {

	public static ExtentReports extent;
	public static ExtentSparkReporter spark;
	public static ExtentReports getReportInstance() {
		
		
		/************** Getting report instance for extend report manager ***************/
		
		 extent= new ExtentReports();
		 String repName= "TestReport-" +BaseUI.timestamp+".html";
		 spark= new ExtentSparkReporter(System.getProperty("user.dir") + "/TestOutput/"+repName);
		 extent.attachReporter(spark);
		 extent.setSystemInfo("Host Name", "UST");
		 extent.setSystemInfo("Environment", "Production");
		 extent.setSystemInfo("User Name", "Emlin");
		 spark.config().setDocumentTitle("NopCommerce Demo Site");
		 spark.config().setReportName("NopCommerce Automation Report - Emlin");
		 spark.config().setTheme(Theme.DARK);
		 return extent;
			}
	
}
