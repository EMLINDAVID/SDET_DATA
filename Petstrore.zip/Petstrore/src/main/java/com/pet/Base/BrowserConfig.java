package com.pet.Base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;

public class BrowserConfig {
	static WebDriver driver;
	public static WebDriver getBrowser() {
//		ChromeOptions option=new ChromeOptions();
//		
//		option.addArguments("--disable-notifications");
//		option.addArguments("--remote-allow-origins=*");
		driver=new EdgeDriver();
		driver.manage().window().maximize();
		return driver;

}
}
