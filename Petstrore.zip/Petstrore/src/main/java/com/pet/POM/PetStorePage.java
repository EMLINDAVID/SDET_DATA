package com.pet.POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.pet.Base.UIbase;

public class PetStorePage extends UIbase {
	WebDriver driver;

	public PetStorePage(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}	  

	
	@FindBy(xpath="//a[text()='Sign In']")
	  WebElement Signin;
	
	@FindBy(xpath="//a[text()='Register Now!']")
	  WebElement register;
	
	@FindBy(name="username")
	  WebElement usname;
	@FindBy(name="password")
	  WebElement pass;
	
	@FindBy(name="repeatedPassword")
	  WebElement rpass;
	
	@FindBy(name="account.firstName")
	  WebElement fname;
	
	@FindBy(name="account.lastName")
	  WebElement lname;
	
	@FindBy(name="account.email")
	  WebElement mail;
	
	@FindBy(name="account.phone")
	  WebElement phn;
	
	@FindBy(name="account.address1")
	  WebElement add;
	
	@FindBy(name="account.address2")
	  WebElement add1;
	
	@FindBy(name="account.city")
	  WebElement city;
	
	@FindBy(name="account.state")
	  WebElement state;
	
	@FindBy(name="account.zip")
	  WebElement zip;
	
	@FindBy(name="account.country")
	  WebElement country;
	@FindBy(name="newAccount")
	WebElement newacnt;
	
	@FindBy(name="signon")
	WebElement login;
	
	@FindBy(xpath="//div[@id=\"Content\"]//ul//li")
	WebElement errorm;
	
	
	 public String getTitle() {
		  return driver.getTitle();
		  }
		  public void signIn() {
			  clickOn(Signin);
			  }
		  
		  public void reg() {
			  clickOn(register);
			  }
		  public void Username(String uname) {
			  sendtext(usname,uname);
			  }
		  public void Password(String pass1) {
			  sendtext(pass,pass1);
			  }
	public void RepPass(String pass2) {
			  sendtext(rpass,pass2);
			  }
	public void fName(String fName) {
		  sendtext(fname,fName);
		  }
	public void lastName(String lname1) {
		  sendtext(lname,lname1);
		  }
	public void mail(String mail1) {
		  sendtext(mail,mail1);
		  }
	public void phoNe(String phn2) {
		  sendtext(phn,phn2);
		  }
	public void add1(String add1) {
		  sendtext(add,add1);
		  }
	public void Add2(String add2) {
		  sendtext(add1,add2);
		  }
	public void Zip(String zip1) {
		  sendtext(zip,zip1);
		  }
	public void city(String cit) {
		  sendtext(city,cit);
		  }
	public void country(String count) {
		  sendtext(country,count);
		  }
	public void state(String stat) {
		  sendtext(state,stat);
		  }
	public void newAcnt() {
		clickOn(newacnt);
		
	}
	public void login() {
		clickOn(login);
	}
	public String errorm()
	 {	
		
		return rettext(errorm);
	}
}
