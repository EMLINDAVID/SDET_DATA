package com.pet.testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.pet.Base.UIbase;
import com.pet.POM.PetStorePage;
import com.pet.utility.Excelutilits;
import com.pet.utility.Excelutils2;


public class PetTest extends UIbase{
	WebDriver driver;
	PetStorePage p1;
	String[][] data;

	
	//Method for calling the broswer
	@BeforeMethod
	public void setup()
	{
		driver=invokebrowser();
		openBrowser("applicationURL");
	}
	//Method to get the value from excel
	@DataProvider(name = "testData")
	public Object[][] testdata()
	{
		data= Excelutilits.testdata();
		return data;

	}
	@DataProvider(name = "testdata1")
	public Object[][] testdata1()
	{
		data= Excelutils2.testdata();
		return data;

	}
	@Test(priority=1,dataProvider="testData")
	public void register(String uname,String pass,String con,String fname,String lname,String mail,String phone,String add1,String add2,String city,String state,String zip,String count) {
		PetStorePage p1=new PetStorePage(driver);
		p1.signIn();
		p1.reg();
		p1.Username(uname);
		p1.Password(pass);
		p1.RepPass(pass);
		p1.fName(fname);
		p1.lastName(lname);
		p1.mail(mail);
		p1.phoNe(phone);
		p1.add1(add1);
		p1.Add2(add2);
		p1.city(city);
		p1.Zip(zip);
		p1.state(state);
		p1.country(count);
		p1.newAcnt();
		
//		SoftAssertions.assertSoftly(softAssertions -> {
//            softAssertions.assertThat(driver.findElement(By.xpath("//a[text()='Sign In']")).isDisplayed());
//            // Verify SignIn  button is displayed
//});
	}
	@Test(priority=2,dataProvider="testdata1")
	public void siginTest(String uname,String pass) {
		PetStorePage p1=new PetStorePage(driver);
		p1.signIn();
		p1.Username(uname);
		p1.Password(pass);
		p1.login();
		String j=p1.errorm();
		if(uname.equals(null) || pass.equals(null)) {
			SoftAssertions.assertSoftly(softAssertions->{
				 softAssertions.assertThat(j.equalsIgnoreCase("Invalid username or password. Signon failed.")).isTrue();
				 });
				 }
				 else if(uname.equals("incorrectUsername") && pass.equals("akshai123")) {
				 SoftAssertions.assertSoftly(softAssertions->{
				 softAssertions.assertThat(j.equalsIgnoreCase("Invalid username or password. Signon failed."));
				 });
				 }
				 else if(pass.equals("incorrectPassword") && uname.equals("AkshaiB")) {
				 SoftAssertions.assertSoftly(softAssertions->{
				 softAssertions.assertThat(j.equalsIgnoreCase("Wrong password."));
				 });
				 }
				 else if(uname.equals("Anu801") && pass.equals("Admin15##")) {
				 SoftAssertions.assertSoftly(softAssertions->{
				 softAssertions.assertThat(driver.findElement(By.id("WelcomeContent")).isDisplayed());
				 });
				 }
	}
		
	}
