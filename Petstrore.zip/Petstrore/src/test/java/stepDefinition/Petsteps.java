package stepDefinition;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.pet.Base.BrowserConfig;
import com.pet.POM.PetStorePage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class Petsteps {
	public static String title;
	public WebDriver driver=BrowserConfig.getBrowser();
	public  PetStorePage g1=new PetStorePage(driver);
	@Given("user is on Home page")
	public void user_is_on_home_page() {
		driver.get("https://petstore.octoperf.com/actions/Catalog.action");
	}

	@When("user gets the title of the page")
	public void user_gets_the_title_of_the_page() {
		   title=g1.getTitle();
		   System.out.println(title);
	    
	}

	@Then("page title should be {string}")
	public void page_title_should_be(String string) {
		title=g1.getTitle();
	    Assert.assertEquals(title, string);
	}

	@When("user enters username {string}")
	public void user_enters_username(String string) {
		 g1.Username(string);
	}

	@When("user enters password {string}")
	public void user_enters_password(String string) {
	   g1.Password(string);
	}

	@When("user clicks on Login button")
	public void user_clicks_on_login_button() {
	    g1.login();
	}
	
}
