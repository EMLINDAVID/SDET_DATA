package com.ust.POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.ust.Base.BaseUI;

public class Login extends BaseUI{
	WebDriver driver;
	public Login(WebDriver driver) {
		this.driver=driver;
	}
	//locators
	By username1=getlocator("user_name");
	By password1=getlocator("password_name");
	By submit1=getlocator("submit_id");
	//elements as methods
	public void UserName(String username) {
		sendtext(username1, username);
	}
	public void PassWord(String password) {
		sendtext(password1, password);
	}
	public void Submit() {
		clickOn(submit1);
	}
			
}
