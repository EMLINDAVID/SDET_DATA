package com.ust.POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
	private WebDriver driver;
	public LoginPage(WebDriver driver) {
	this.driver=driver;
	}
	
	By Username=By.id("username");
	By pwd=By.id("password");
	By signInButton = By.id("submit");
	By forgotPwdLink =  By.xpath("//a[@title='Recover your forgotten password']");
	
	public String getLoginPageTitle() {
		return driver.getTitle();
	}

	
	public void sendusername(String username) {
		driver.findElement(Username).sendKeys(username);
	}
	
	public void sendPassword(String password) {
		driver.findElement(pwd).sendKeys(password);
	}
	
	public void clickSubmit() {
		driver.findElement(signInButton).click();
		
	}

}