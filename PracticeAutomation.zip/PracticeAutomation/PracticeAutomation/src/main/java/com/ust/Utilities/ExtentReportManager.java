package com.ust.Utilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.ust.Base.BaseUI;

public class ExtentReportManager extends BaseUI{
	public static ExtentReports extent;
	public static ExtentSparkReporter spark;
	
	public static ExtentReports getReportInstance() {
		extent=new ExtentReports();
		String repName="TestReport-"+BaseUI.timestamp+".html";
		spark=new ExtentSparkReporter(System.getProperty("user.dir")
				+"/TestOutput/"+repName);
		extent.attachReporter(spark);
		extent.setSystemInfo("Host Name", "UST");
		extent.setSystemInfo("Environment", "Production");
		extent.setSystemInfo("User Name", "Neethu");
		spark.config().setDocumentTitle("Title of the report comes here");
		//name of the project
		spark.config().setReportName("Name of the report comes here");
		//Dark Theme
		spark.config().setTheme(Theme.DARK);
		
		return extent;
		
	}
	

}
