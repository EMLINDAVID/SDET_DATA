import org.junit.Assert;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
public class ReportTest {
 ExtentSparkReporter htmlReporter;
 ExtentReports extent;
	ExtentTest test;
	
	@BeforeTest
	public void startReport( ) {
		htmlReporter = new ExtentSparkReporter(System.getProperty("user.dir")+"\\neethu.html");
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
		htmlReporter.config().setDocumentTitle("Simple Automation Report");
		htmlReporter.config().setReportName("Test Report");
		htmlReporter.config().setTheme(Theme.STANDARD);
	}
	
	@Test
	public void test_1() {
		test =extent.createTest("Test Case 1","The test case 1 passed");
		Assert.assertTrue(true);
		test.log(Status.INFO, "Username is entered");
	}
	@Test
	public void test2() {
		test=extent.createTest("Test Case 2","The test case 2 has failed");
		Assert.assertTrue(false);
	}
	@Test
	public void test3() {
		test=extent.createTest("Test Case 3","The test case 3 has been skipped");
		throw new SkipException("The test has been skipped");
	}
	@AfterMethod
	public void getResult(ITestResult result) {
		if(result.getStatus()==ITestResult.FAILURE) {
			test.log(Status.FAIL,result.getThrowable());
		}
		else if(result.getStatus()==ITestResult.SUCCESS) {
			test.log(Status.PASS, result.getTestName());
		}
		else {
			test.log(Status.SKIP, result.getTestName());
		}
	}
	@AfterTest
	public void tearDown() {
		extent.flush();
	}
 }




