package com.ust;

public class Locators {

}
