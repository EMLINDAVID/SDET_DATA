package com.ust.testcases;

import org.assertj.core.api.SoftAssertions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.Base.BaseUI;
import com.ust.POM.Login;
import com.ust.Utilities.ExcelUtils;

@Listeners(com.ust.Utilities.SampleListener.class)

public class LoginTestcase extends BaseUI{
	WebDriver driver;
	//Login login;
	String[][] data;
	@BeforeMethod
	public void setup(){
		driver=invokebrowser();
		openBrowser("applicationURL");
	}
	@DataProvider(name = "testData")
	public Object[][] testdata(){
		data= ExcelUtils.testdata();
		return data;
	}
	@Test(priority =1,dataProvider = "testData")
	public void loginTest(String username,String password,String expectedText) {
		Login login=new Login(driver);
		login.UserName(username);
		login.PassWord(password);
		login.Submit();
		if(username.equals("Incorrect Username")) {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.className("show")).isDisplayed());
				// Verify error message text is Your username is invalid!
			});
		}
		else if(password.equals("incorrectPassword")) {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.className("show")).isDisplayed());
				// Verify error message text is Your password is invalid!
			});
		}
		else {
			//// Verify new page URL contains practicetestautomation.com/logged-in-successfully/
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.getCurrentUrl().contains("practicetestautomation.com/logged-in-successfully/"));
				////// Verify new page contains expected text ('Congratulations' or 'successfully logged in')
				////softAssertions.assertThat(driver.findElement(By.xpath("//*[contains(text(), '" + text + "')]")).isDisplayed());
				//////// Verify button Log out is displayed on the new page
				softAssertions.assertThat(driver.findElement(By.xpath("//*[@id=\"loop-container\"]/div/article/div[2]/div/div/div/a")).isDisplayed());
			});
		}
	}
}



