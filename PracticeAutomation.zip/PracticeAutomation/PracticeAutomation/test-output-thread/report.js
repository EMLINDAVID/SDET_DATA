$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"298af8c0-7cc6-4f8f-a84d-31807d32a27d","feature":"Login page feature","scenario":"Login page title","start":1691595135944,"group":1,"content":"","tags":"","end":1691595143181,"className":"passed"},{"id":"2d60c48e-231f-4acd-9600-8cba348299eb","feature":"Login page feature","scenario":"Login with correct credentials","start":1691595143191,"group":1,"content":"","tags":"","end":1691595150722,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});