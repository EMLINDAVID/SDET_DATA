package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.BaseUI;

public class ContactUsFunction extends BaseUI{
	WebDriver driver;
	public ContactUsFunction(WebDriver driver) {
		// Pass WebDriver as an input to a the constructor 
		this.driver = driver;
		// Call initElements() method by using PageFactory reference and pass driver and this as parameters. 
		PageFactory.initElements(driver, this);
	}
	@FindBy(id = "id_contact")
	WebElement subjectHandling;
	
	@FindBy(id = "email")
	WebElement email;
	
	@FindBy(id = "id_order")
	WebElement orderReference;
	
	@FindBy(id = "message")
	WebElement message;
	
	public void subjectHandling(String subject) {
		dropDownHandling(subjectHandling, subject);
	}
	public void email(String emailAddress) {
		sendtext(email, emailAddress);
	}
	public void orderReference(String orderReferencevalue) {
		sendtext(orderReference, orderReferencevalue);
	}
	public void message(String messagevalue) {
		sendtext(message, messagevalue);
	}
	//or you can write like this
//	public void contactUs(String subject, String emailAddress, String orderReferencevalue, String messagevalue) {
//		sendtext(subjectHandling, subject);
//		sendtext(email, emailAddress);
//		sendtext(orderReference, orderReferencevalue);
//		sendtext(message, messagevalue);
//	}
		
	}

