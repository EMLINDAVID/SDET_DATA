package testcases;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import base.BaseUI;
import pom.ContactUsFunction;


public class ContactTest extends BaseUI{

	WebDriver driver;
	ContactUsFunction contact;
	@BeforeMethod
	public void setup(){
		driver=invokebrowser();
		openBrowser("applicationURL");
		
	}
	@Test
	public void subjecthandlingtest() {
		ContactUsFunction contact=new ContactUsFunction(driver);
		contact.subjectHandling("Webmaster");
	}
	@Test
	public void contactTest() {
		ContactUsFunction contact=new ContactUsFunction(driver);
		contact.email("Webmaster@zee.com");
	}
}
