package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.BaseUI;

public class Signup extends BaseUI{
	WebDriver driver;
	Signup s;
	public Signup(WebDriver driver) {
		// Pass WebDriver as an input to a the constructor 
		this.driver = driver;
		// Call initElements() method by using PageFactory reference and pass driver and this as parameters. 
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "//a[@id='signin2']")
	WebElement signupbutton;
	
	@FindBy(xpath = "//input[@id='sign-username']")
	WebElement email;
	
	@FindBy(xpath = "//input[@id='sign-password']")
	WebElement password;
	
	@FindBy(xpath = "//button[text()='Sign up']")
	WebElement signupp;
	
	@FindBy(xpath = "//div[@id='signInModal']//button[@class='close']")
	WebElement closebutton;
	
	@FindBy(xpath = "//a[@id='login2']")
	WebElement loginbutton;
	
	@FindBy(xpath = "[//input[@id='loginusername']")
	WebElement emailenter;
	
	@FindBy(xpath = "//input[@id='loginpassword']")
	WebElement passwordenter;
	
	public void signupbutton() {
		clickOn(signupbutton);
	}
	public void email(String emailAddress) {
		sendtext(email, emailAddress);
	}
	public void password(String pass) {
		sendtext(password, pass);
	}
	public void signupp() {
		clickOn(signupp);
	}
	public void alert()
	{
		getTextfromAlertandAccept();
	}
	public void closebutton() {
		clickOn(closebutton);
	}
	public void loginbutton() {
		clickOn(loginbutton);
	}
	public void emailenter(String emailenterAddress) {
		sendtext(emailenter, emailenterAddress);
	}
	public void passwordenter(String passwordenterAddress) {
		sendtext(passwordenter, passwordenterAddress);
	}
	
	//or you can write like this
//	public void contactUs(String subject, String emailAddress, String orderReferencevalue, String messagevalue) {
//		sendtext(subjectHandling, subject);
//		sendtext(email, emailAddress);
//		sendtext(orderReference, orderReferencevalue);
//		sendtext(message, messagevalue);
//	}
		
	}

