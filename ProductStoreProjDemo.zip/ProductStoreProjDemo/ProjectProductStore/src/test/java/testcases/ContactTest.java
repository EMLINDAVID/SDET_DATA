package testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.BaseUI;
import pom.Signup;
import utilities.Excelutils;

public class ContactTest extends BaseUI {

	WebDriver driver;
	Signup sign;
	String[][]data;
	
	@BeforeTest
	public void setup() {
		driver = invokebrowser();
		openBrowser("applicationURL");

	}
	
	@Test(priority=0)
	public void Signupclick() {
		Signup sign = new Signup(driver);
		sign.signupbutton();
		sign.email("emlindavidshajuias@gmail.com");
		sign.password("Abcde@123456");
		sign.signupp();
		String alertmsg=getTextfromAlertandAccept();
		sign.switchToAlertAccept();
		SoftAssertions.assertSoftly(softAssertion->{
		softAssertion.assertThat(alertmsg.equalsIgnoreCase("This user already exist."));
		});
		sign.closebutton();
	}	
}
