package testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.BaseUI;
import pom.Signup;
import utilities.Excelutils;

public class LoginCase extends BaseUI {
	
	WebDriver driver;
	Signup sign;
	String[][]data;
	
	@BeforeTest
	public void setup() {
		driver = invokebrowser();
		openBrowser("applicationURL");

	}
	
	@DataProvider(name = "testData")
	public Object[][] testdata(){
	data= Excelutils.testdata();
	return data;
	}
	
	@Test(priority=1,dataProvider = "testData")
	public void Loginclick(String fname,String pass) {
		Signup sign = new Signup(driver);
		sign.loginbutton();
		sign.emailenter(fname);
		sign.passwordenter(pass);
	}	

}
