package com.reqres.endpoints;

public class Routes {
	public static String baseuri="https://reqres.in";
	public static String post_basePath="/api/users";
	public static String get_basePath="/api/users/{id}";
	public static String delete_basePath="/api/users/{id}";
	public static String update_basePath="/api/users/{id}";
}
