package com.reqres.testcases;

import org.junit.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.reqres.endpoints.UserEndPoints;
import com.reqres.payload.UserModel;
import com.reqres.utility.DataProviders;

import io.restassured.RestAssured;
import io.restassured.response.Response;
@Listeners(com.reqres.utility.ExtentReportManager.class)
public class DataDrivenTest {
	@Test(priority=1,dataProvider="data",dataProviderClass=DataProviders.class)
	public void testPostUser(String id,String email,String firstname,String lastname,String avatar) {
	RestAssured.useRelaxedHTTPSValidation();
	UserModel user=new UserModel();
	user.setId(Integer.parseInt(id));
	user.setEmail(email);
	user.setFirstname(firstname);
	user.setLastname(lastname);
	user.setAvatar(avatar);
	Response response=UserEndPoints.createUser(user);
	response.then().log().all();
	Assert.assertEquals(response.getStatusCode(),201);
	}
	@Test(priority=2,dataProvider="UserNames",dataProviderClass=DataProviders.class)
	public void testGetUserByName(String id)
    {
        Response response = UserEndPoints.getUser(id);
       response.then().log().all();
       Assert.assertEquals(response.getStatusCode(),200);
    }
	
	@Test(priority=3,dataProvider="UserNames",dataProviderClass=DataProviders.class)
	public void testUpdateByUserName(String id) {
	UserModel payload=new UserModel();
	RestAssured.useRelaxedHTTPSValidation();
	Response response=UserEndPoints.updateUser(id,payload);
	response.then().log().all();
	Assert.assertEquals(response.getStatusCode(),200);
	}
	
	
	@Test(priority=4,dataProvider="UserNames",dataProviderClass=DataProviders.class)
	public void testDeleteByUserName(String id) {
		RestAssured.useRelaxedHTTPSValidation();
		Response response=UserEndPoints.deleteUser(id);
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(),204);
	}
	
}
