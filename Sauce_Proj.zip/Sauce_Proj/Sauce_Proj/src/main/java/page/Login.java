package page;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import Basic.BaseUI;

public class Login extends BaseUI {
	WebDriver driver;

	public Login(WebDriver driver) {
		this.driver = driver;
	}

	By uname = getlocator("username_name");
	By password = getlocator("password_name");
	By submit = getlocator("submit_name");
	By menu = getlocator("menu_xpath");
	By logout = getlocator("logout_linkText");
	public By errorMessage = getlocator("error_xpath");
	public By appLogo = getlocator("applogo_className");

	public void userName(String user) {
		sendtext(uname, user);
		String logMessage = "Entered username: " + user;
		logger.log(Status.INFO, logMessage);
	}

	public void passWord(String pass) {
		isElementPresent(password, Duration.ofSeconds(15));
		sendtext(password, pass);
		String logMessage = "Entered password";
		logger.log(Status.INFO, logMessage);
	}
	public void clickSubmitButton() {
		clickOn(submit);
		logger.log(Status.INFO, "Clicked on Submit button");
	}

	
}
