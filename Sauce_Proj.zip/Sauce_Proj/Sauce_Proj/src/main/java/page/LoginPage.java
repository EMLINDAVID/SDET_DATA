package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

	public WebDriver driver;

	// 1. By Locators: OR
//	 By emailId = By.id("email");
//	 By password = By.id("passwd");
//	 By signInButton = By.id("SubmitLogin");
//	 By forgotPwdLink = By.xpath("//a[@title='Recover your forgotten password']");
	By email=By.name("user-name");
	By password=By.name("password");
	By signin=By.name("login-button");
   // By acc=By.xpath("//a[@class='site-nav__link site-nav__link--icon small--hide']/span[@class='site-nav__icon-label small--hide']");
	// 2. Constructor of the page class:
	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

	// 3. page actions: features(behavior) of the page the form of methods:

	public String getLoginPageTitle() {
		return driver.getTitle();
	}

//	public boolean isForgotPwdLinkExist() {
//		return driver.findElement(forgotPwdLink).isDisplayed();
//	}
//	public void accclick() {
//		driver.findElement(acc).click();
//	}

	public void enterUserName(String username) {
		driver.findElement(email).sendKeys(username);
	}

	public void enterPassword(String pwd) {
		driver.findElement(password).sendKeys(pwd);
	}

	public void clickOnLogin() {
		driver.findElement(signin).click();
	}

	
}
