package page;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import Basic.BaseUI;

public class Sauce extends BaseUI {
	WebDriver driver;
	WebDriverWait wait;
	// Locators for various elements
	public By productSortContainer = getlocator("productSortContainer_className");
	public By sortNameAToZ = getlocator("sortNameAToZ_xpath");
	public By sortNameZToA = getlocator("sortNameZToA_xpath");
	public By sortNameLohi = getlocator("sortNameLohi_xpath");
	public By sortNameHilo = getlocator("sortNameHilo_xpath");
	By productNames = getlocator("inventoryItemName_className");
	By productPrices = getlocator("priceList_xpath");
	public By shoppingCart = getlocator("shoppingCartContainer_xpath");
	By allItemsBtnLocator = getlocator("allItems_id");
	public By aboutBtnLocator = getlocator("about_id");
	By logoutBtnLocator = getlocator("logout_id");
	public By menu = getlocator("menu_xpath");
	By logout = getlocator("logout_linkText");
	public By twitterLocator = getlocator("twitterIconLink_xpath");
	public By facebookLocator = getlocator("facebookIconLink_xpath");
	public By linkedInLocator = getlocator("linkedinIconLink_xpath");
	public By footer = getlocator("footerText_xpath");
	public By DropDown = getlocator("dropdown_xpath");
	By continueShoppingButton = getlocator("continueShoppingButton_xpath");
	By checkoutButton = getlocator("checkoutButton_xpath");
	public By menuCrossButton = getlocator("menucross_xpath");
	public By firstname = By.id("first-name");
	public By lastname = By.id("last-name");
	public By postalcode = By.id("postal-code");
	public By continueButton = By.id("continue");
	public By cancelButton = getlocator("cancel_xpath");
	public By finishButton = By.id("finish_xpath");
	By footerButton = By.className("footer_className");
	public By backtohome = getlocator("back_id");

	public Sauce(WebDriver driver) {
		super();
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(15)); // Initialize WebDriverWait
	}
	
	// Method to log in to the application with given username and password
	public void login(String username, String password) {
		By usernameLocator = By.name("user-name");
		By passwordLocator = By.name("password");
		By loginButtonLocator = By.name("login-button");

		// Enter the credentials into the input fields
		driver.findElement(usernameLocator).sendKeys(username);
		driver.findElement(passwordLocator).sendKeys(password);

		// Locate and click the login button
		driver.findElement(loginButtonLocator).click();
	}
	
	// Method to retrieve a list of product names
	public List<String> getProductNames() {
		List<String> productNames = new ArrayList<>();
		List<WebElement> productNameElements = driver.findElements(this.productNames);
		for (WebElement element : productNameElements) {
			productNames.add(element.getText());
		}
		logger.log(Status.INFO, "Retrieved product names");
		return productNames;
	}
	
	// Method to select the sorting option from the product container
	public void selectSortOption(By locator) {
		WebElement sortContainer = driver.findElement(productSortContainer);
		sortContainer.click();
		driver.findElement(locator).click();
		logger.log(Status.INFO, "Selected sort option");
	}
	
	// Methods to select different sorting options
	public void selectNameAToZSortOption() {
		selectSortOption(sortNameAToZ);
		logger.log(Status.INFO, "Selected Name A to Z sort option");
	}

	// Methods to select different sorting options
	public void selectNameZToASortOption() {
		selectSortOption(sortNameZToA);
		logger.log(Status.INFO, "Selected Name Z to A sort option");
	}

	// Methods to select different sorting options
	public void selectPriceHighToLowSortOption() {
		selectSortOption(sortNameHilo);
		logger.log(Status.INFO, "Selected Price High to Low sort option");
	}

	// Methods to get product names sorted in different orders
	public List<String> getProductNamesSortedAToZ() {
		List<String> productNames = getProductNames();
		productNames.sort(String::compareToIgnoreCase);
		logger.log(Status.INFO, "Retrieved product names sorted in A to Z order");
		return productNames;
	}

	// Methods to get product names sorted in different orders
	public List<String> getProductNamesSortedZToA() {
		List<String> productNames = getProductNames();
		productNames.sort(Collections.reverseOrder());
		logger.log(Status.INFO, "Retrieved product names sorted in Z to A order");
		return productNames;
	}

	// Methods to get product names sorted in different orders
	public List<String> getProductPrices() {
		List<String> productPrices = new ArrayList<>();
		List<WebElement> productPriceElements = driver.findElements(this.productPrices);
		for (WebElement element : productPriceElements) {
			productPrices.add(element.getText());
		}
		logger.log(Status.INFO, "Retrieved product prices");
		return productPrices;
	}

	// Methods to get product names sorted in different orders
	public List<String> getProductPricesSortedHighToLow() {
		List<String> productPrices = getProductPrices();
		productPrices.sort(Collections.reverseOrder(new PriceComparator()));
		logger.log(Status.INFO, "Retrieved product prices sorted in high to low order");
		return productPrices;
	}

	// PriceComparator class to compare product prices
	public static class PriceComparator implements Comparator<String> {
		@Override
		public int compare(String price1, String price2) {
			System.out.println("Price1: " + price1 + ", Numeric Price1: " + extractNumericPrice(price1));
			System.out.println("Price2: " + price2 + ", Numeric Price2: " + extractNumericPrice(price2));

			double numericPrice1 = extractNumericPrice(price1);
			double numericPrice2 = extractNumericPrice(price2);
			return Double.compare(numericPrice1, numericPrice2);
		}

		private double extractNumericPrice(String price) {
			// String numericValue = price.replace("$", "").replace(",", "").trim();
			String numericValue = price.replaceAll("[^\\d.]", "");
			return Double.parseDouble(numericValue);
		}
	}

	// Method to scroll to the footer of the page
	public void scrollToFooter() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);",
				driver.findElement(By.xpath("//*[@id=\"page_wrapper\"]/footer")));
		logger.log(Status.INFO, "Scrolled to the footer of the page");
	}

	public void clickOnMenuButton() {
		System.out.println("Waiting for the menu button to be visible...");
		wait.until(ExpectedConditions.visibilityOfElementLocated(menu));
		System.out.println("Menu button is now visible. Clicking on it...");
		clickOn(menu);
		logger.log(Status.INFO, "Clicked on the menu button");
	}

	// Click on All Items
	public void clickOnAllItems() {
		clickOn(allItemsBtnLocator);
		logger.log(Status.INFO, "Clicked on All Items");
	}

	// Click on About
	public void clickOnAbout() {
		clickOn(aboutBtnLocator);
		logger.log(Status.INFO, "Clicked on About");
	}

	// Click on Logout
	public void clickOnLogout() {
		clickOn(logoutBtnLocator);
		logger.log(Status.INFO, "Clicked on Logout");
	}

	// Click on Shopping Cart
	public void clickOnShoppingCart() {
		By shoppingCartContainerLocator = getlocator("shoppingCart");
		clickOn(shoppingCartContainerLocator);
		logger.log(Status.INFO, "Clicked on Shopping Cart");
	}

	// Method to check if the current URL is equal to the expected URL
	public boolean verifyCurrentUrl(String expectedUrl) {
		String actualUrl = driver.getCurrentUrl();
		boolean isUrlMatched = actualUrl.equals(expectedUrl);
		String logMessage = "Current URL: " + actualUrl + ", Expected URL: " + expectedUrl + ", URL Matched: "
				+ isUrlMatched;
		logger.log(Status.INFO, logMessage);
		return isUrlMatched;
	}

	// Method to check if the shopping cart badge is displayed
	public boolean isShoppingCartBadgeDisplayed() {
		boolean isDisplayed = isElementPresent(By.className("shopping_cart_badge"), Duration.ofSeconds(15));
		String logMessage = "Shopping Cart Badge Displayed: " + isDisplayed;
		logger.log(Status.INFO, logMessage);
		return isDisplayed;
	}

	// Method to click on the twitter
	public void clickOnTwitter() {
		clickOn(twitterLocator);
		logger.log(Status.INFO, "Clicked on Twitter");
	}

	// Method to click on the facebook
	public void clickOnFaceBook() {
		clickOn(facebookLocator);
		logger.log(Status.INFO, "Clicked on Facebook");
	}

	// Method to click on linkedin
	public void clickOnLinkedin() {
		clickOn(linkedInLocator);
		logger.log(Status.INFO, "Clicked on LinkedIn");
	}

	public void openDropdown() {
		clickOn(DropDown);
		logger.log(Status.INFO, "Opened Dropdown");
	}

	public void click_A_to_Z() {
		clickOn(sortNameAToZ);
		logger.log(Status.INFO, "Clicked on A to Z Sort Option");
	}

	public void click_Z_to_A() {
		clickOn(sortNameZToA);
		logger.log(Status.INFO, "Clicked on Z to A Sort Option");
	}

	public void click_low_to_high() {
		clickOn(sortNameLohi);
		logger.log(Status.INFO, "Clicked on Low to High Sort Option");
	}

	public void click_high_to_low() {
		clickOn(sortNameHilo);
		logger.log(Status.INFO, "Clicked on High to Low Sort Option");
	}

	public void waitAndClick(By locator) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(locator));
		element.click();
		String logMessage = "Clicked on element with locator: " + locator;
		logger.log(Status.INFO, logMessage);
	}

	public void clickContinueShoppingButton() {
		waitAndClick(continueShoppingButton);
		logger.log(Status.INFO, "Clicked on Continue Shopping Button");
	}

	public void clickCheckoutButton() {
		waitAndClick(checkoutButton);
		logger.log(Status.INFO, "Clicked on Checkout Button");
	}

	public void firstName(String firstName) {
		driver.findElement(firstname).sendKeys(firstName);
		String logMessage = "Entered first name: " + firstName;
		logger.log(Status.INFO, logMessage);
	}

	// Fill in Last Name
	public void lastName(String lastName) {
		driver.findElement(lastname).sendKeys(lastName);
		String logMessage = "Entered last name: " + lastName;
		logger.log(Status.INFO, logMessage);
	}

	// Fill in Postal Code
	public void postalName(String postalCode) {
		driver.findElement(postalcode).sendKeys(postalCode);
		String logMessage = "Entered postal code: " + postalCode;
		logger.log(Status.INFO, logMessage);
	}

	public void clickContinue() {
		clickOn(continueButton);
		logger.log(Status.INFO, "Clicked on Continue Button");
	}

	public void clickCancel() {
		clickOn(cancelButton);
		logger.log(Status.INFO, "Clicked on Cancel Button");
	}

	public void clickFinish() {
		clickOn(finishButton);
		logger.log(Status.INFO, "Clicked on Finish Button");
	}

	public void clickHome() {
		clickOn(backtohome);
		logger.log(Status.INFO, "Clicked on Home Button");
	}

	public void clickOnMenuCross() {
		clickOn(menuCrossButton);
		logger.log(Status.INFO, "Clicked on Menu Cross Button");
	}

	public void clickCheckout() {
		clickOn(checkoutButton);
		logger.log(Status.INFO, "Clicked on Checkout Button");
	}
}