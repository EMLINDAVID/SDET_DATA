package TestCases;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;

import Basic.BaseUI;
import Basic.ChromeConfig;
import page.Sauce;
@Listeners(utils.Listener.class)
public class SauceTestCases extends BaseUI {
	WebDriver driver;
	Sauce sauceDemoPage;

	@BeforeTest
	public void setup() {
		driver = ChromeConfig.getBrowser();
		sauceDemoPage = new Sauce(driver);
		driver.get("https://www.saucedemo.com/");
		// Log in with the specified credentials
		sauceDemoPage.login("standard_user", "secret_sauce");
	}

	
	// Test case to verify clicking of product names from A to Z.
	@Test(priority = 0)
	public void testclick_A_to_Z() {
		// Click on A to Z option
		sauceDemoPage.openDropdown();
		sauceDemoPage.click_A_to_Z();

		SoftAssertions.assertSoftly(softAssertions -> {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

			// Check whether the dropdown with A to Z option is displayed
			boolean isDropdownDisplayed = wait
					.until(ExpectedConditions.presenceOfElementLocated(sauceDemoPage.sortNameAToZ)).isDisplayed();
			softAssertions.assertThat(isDropdownDisplayed).as("Dropdown with A to Z option is displayed").isTrue();
		});
	}

	// Test case to verify sorting of product names from A to Z.
	@Test(priority = 1)
	public void testSortByNameAToZ() {
		// Get the unsorted product names
		List<String> unsortedProductNames = sauceDemoPage.getProductNames();

		// Sort the product names in Name (A to Z) order
		List<String> sortedProductNames = sauceDemoPage.getProductNamesSortedAToZ();

		// Verify that the product names are sorted in ascending order (A to Z)
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(sortedProductNames).isSorted();
			softAssertions.assertThat(sortedProductNames).isEqualTo(unsortedProductNames);
		});
	}

	// Test case to verify clicking on the Z to A sorting option.
	@Test(priority = 2)
	public void testclick_Z_to_A() {
		// Click on Z to A option
		sauceDemoPage.openDropdown();
		sauceDemoPage.click_Z_to_A();

		SoftAssertions.assertSoftly(softAssertions -> {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

			// Check whether the dropdown with Z to A option is displayed
			boolean isDropdownDisplayed = wait
					.until(ExpectedConditions.presenceOfElementLocated(sauceDemoPage.sortNameZToA)).isDisplayed();
			softAssertions.assertThat(isDropdownDisplayed).as("Dropdown with Z to A option is displayed").isTrue();
		});
	}

	// Test case to verify sorting of product prices from high to low.
	@Test(priority = 3)
	public void testSortByPriceHighToLow() {
		// Get the unsorted product prices
		List<String> unsortedProductPrices = sauceDemoPage.getProductPrices();

		// Sort the product prices in Price (high to low) order
		List<String> sortedProductPrices = sauceDemoPage.getProductPricesSortedHighToLow();

		// Update the expected sorted product prices
		List<String> expectedSortedProductPrices = new ArrayList<>(unsortedProductPrices);
		expectedSortedProductPrices.sort(Collections.reverseOrder(new Sauce.PriceComparator()));

		// Verify that the product prices are sorted correctly (high to low)
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(sortedProductPrices)
					.isSortedAccordingTo(Collections.reverseOrder(new Sauce.PriceComparator()));
			softAssertions.assertThat(sortedProductPrices).isEqualTo(expectedSortedProductPrices);
		});
	}

	// Test case to verify clicking on the low to high sorting option.
	@Test(priority = 4)
	public void testclick_low_to_high() {
		// Click on low to high option
		sauceDemoPage.openDropdown();
		sauceDemoPage.click_low_to_high();

		SoftAssertions.assertSoftly(softAssertions -> {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

			boolean isDropdownDisplayed = wait
					.until(ExpectedConditions.presenceOfElementLocated(sauceDemoPage.sortNameLohi)).isDisplayed();
			softAssertions.assertThat(isDropdownDisplayed).as("Dropdown with low to high option is displayed").isTrue();
		});
	}

	// Test case to verify clicking on the high to low sorting option.
	@Test(priority = 5)
	public void testclick_high_to_low() {
		// Click on high to low option
		sauceDemoPage.openDropdown();
		sauceDemoPage.click_high_to_low();
		SoftAssertions.assertSoftly(softAssertions -> {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

			boolean isDropdownDisplayed = wait
					.until(ExpectedConditions.presenceOfElementLocated(sauceDemoPage.sortNameHilo)).isDisplayed();
			softAssertions.assertThat(isDropdownDisplayed).as("Dropdown with high to low option is displayed").isTrue();
		});
	}

	
	// Test case to verify the closing of the menu after clicking on the cross button.
	@Test(priority = 6)
	public void testMenuCross() {
		// Instead of using the clickOnMenuButton() method, use actions directly
		WebElement menuButton = driver.findElement(sauceDemoPage.menu);
		Actions actions = new Actions(driver);
		actions.moveToElement(menuButton).click().build().perform();

		// Wait for the Logout button to be clickable before performing the action
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		System.out.println("Wait for the menu cross button element to be clickable");
		WebElement menuButton1 = wait.until(ExpectedConditions.elementToBeClickable(sauceDemoPage.menuCrossButton));
		System.out.println("Using actions");
		//actions.moveByOffset(-10, -10).click(menuButton).perform();
		actions.moveToElement(menuButton1).click().build().perform();
		// Check if the menu is closed by waiting for the "about" element to be invisible

		 // Check if the menu is closed by waiting for the "about" element to be invisible
	    SoftAssertions.assertSoftly(softAssertions -> {
	        try {
	            wait.until(ExpectedConditions.invisibilityOfElementLocated(sauceDemoPage.aboutBtnLocator));
	            // If the element is not found, it means the menu is closed
	            // Asserting the condition here is not necessary as the absence of the element indicates the menu is closed.
	        } catch (TimeoutException e) {
	            // If a TimeoutException is caught, it means the element is still visible after the timeout
	            // This indicates the menu is not closed, so we can fail the test with an assertion.
	            softAssertions.fail("Menu option is not closed");
	        }
	    });
	}

	// Test case to verify redirection to the shopping cart page.
	@Test(priority = 7)
	public void testShoppingCart() {
		// Wait for the cart page to load
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		WebElement shoppingCartBtn = wait.until(ExpectedConditions.elementToBeClickable(sauceDemoPage.shoppingCart));

		Actions actions = new Actions(driver);
		actions.moveToElement(shoppingCartBtn).click().build().perform();

		// Click on the shopping cart
		System.out.println("Clicking on the shopping cart button...");
		sauceDemoPage.clickOnShoppingCart();

		// Wait for the cart page to load
		wait.until(ExpectedConditions.urlToBe("https://www.saucedemo.com/cart.html"));

		// Verify that the user is redirected to the cart page
		String expectedCartUrl = "https://www.saucedemo.com/cart.html";
		String actualCartUrl = driver.getCurrentUrl();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(actualCartUrl).isEqualTo(expectedCartUrl);
		});
	}

	// Test case to verify redirection to the inventory page after clicking the "Continue" button in the shopping cart.
	@Test(priority = 8)
	public void testContinueButtonRedirection() {
		// Wait for the cart page to load
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		WebElement shoppingCartBtn = wait.until(ExpectedConditions.elementToBeClickable(sauceDemoPage.shoppingCart));

		Actions actions = new Actions(driver);
		actions.moveToElement(shoppingCartBtn).click().build().perform();

		// Click on the shopping cart
		System.out.println("Clicking on the shopping cart button...");
		sauceDemoPage.clickOnShoppingCart();

		sauceDemoPage.clickContinueShoppingButton();

		// Verify the redirection URL after clicking "Continue" button
		Assertions.assertThat(driver.getCurrentUrl()).isEqualTo("https://www.saucedemo.com/inventory.html");
	}

	// Test case to verify redirection to the checkout page after clicking the "Checkout" button in the shopping cart.
	@Test(priority = 9)
	public void testCheckoutButtonRedirection() {
		// Wait for the cart page to load
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		WebElement shoppingCartBtn = wait.until(ExpectedConditions.elementToBeClickable(sauceDemoPage.shoppingCart));

		Actions actions = new Actions(driver);
		actions.moveToElement(shoppingCartBtn).click().build().perform();

		// Click on the shopping cart
		System.out.println("Clicking on the shopping cart button...");
		sauceDemoPage.clickOnShoppingCart();

		sauceDemoPage.clickCheckoutButton();

		// Verify the redirection URL after clicking "Checkout" button
		Assertions.assertThat(driver.getCurrentUrl()).isEqualTo("https://www.saucedemo.com/checkout-step-one.html");
	}

	// Test to verify that clicking the "Cancel" button redirects to the cart page.
	@Test(priority = 10)
	public void testCancelDetails() {
	    // Click on the "Cancel" button
	    sauceDemoPage.clickCancel();
	    String expectedURL = "https://www.saucedemo.com/cart.html";
	    String actualURL = driver.getCurrentUrl();
	    SoftAssertions softAssertions = new SoftAssertions();
	    softAssertions.assertThat(actualURL.equals(expectedURL));
	    //softAssertions.assertAll();
	}

	// Test to verify that clicking the "Checkout" button redirects to the checkout-step-one page.
	@Test(priority = 11)
	public void testCheckout() {
	    // Click on the "Checkout" button
	    sauceDemoPage.clickCheckout();
	    String expectedURL = "https://www.saucedemo.com/checkout-step-one.html";
	    String actualURL = driver.getCurrentUrl();
	    SoftAssertions softAssertions = new SoftAssertions();
	    softAssertions.assertThat(actualURL.equals(expectedURL));
	    softAssertions.assertAll();
	}

	// Test to verify that the first name is correctly filled in and displayed on the next step.
	@Test(priority = 12)
	public void testFirstName() {
	    // Test data
	    String firstName = "John";
	    // Fill in the first name
	    sauceDemoPage.firstName(firstName);
	    // Click on the "Continue" button
	    sauceDemoPage.clickContinue();
	    // Add wait before retrieving the data or else there will be an error
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
	    WebElement FirstNameElement = wait.until(ExpectedConditions.visibilityOfElementLocated(sauceDemoPage.firstname));

	    // Verify First Name
	    String actualFirstName = FirstNameElement.getAttribute("value");
	    System.out.println("Actual First Name: " + actualFirstName);
	    SoftAssertions softAssertions = new SoftAssertions();
	    softAssertions.assertThat(actualFirstName).isEqualTo(firstName).as("First name is incorrect");
	    softAssertions.assertAll();
	}

	// Test to verify that the last name is correctly filled in and displayed on the next step.
	@Test(priority = 13)
	public void testLastName() {
	    // Test data
	    String lastName = "Doe";
	    // Fill in the last name
	    sauceDemoPage.lastName(lastName);
	    // Click on the "Continue" button
	    sauceDemoPage.clickContinue();

	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
	    WebElement lastNameElement = wait.until(ExpectedConditions.visibilityOfElementLocated(sauceDemoPage.lastname));

	    // Verify Last Name
	    String actualLastName = lastNameElement.getAttribute("value");
	    System.out.println("Actual Last Name: " + actualLastName);
	    SoftAssertions softAssertions = new SoftAssertions();
	    softAssertions.assertThat(actualLastName).isEqualTo(lastName).as("Last name is incorrect");
	    softAssertions.assertAll();
	}

	// Test to verify that the postal code is correctly filled in and displayed on the next step.
	@Test(priority = 14)
	public void testPostalCode() {
	    // Test data
	    String postalCode = "123456";
	    // Fill in the postal code
	    sauceDemoPage.postalName(postalCode);
	    // Click on the "Continue" button
	    sauceDemoPage.clickContinue();

	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
	    WebElement PostalNameElement = wait.until(ExpectedConditions.visibilityOfElementLocated(sauceDemoPage.postalcode));

	    // Verify Postal Code
	    String actualPostalCode = PostalNameElement.getAttribute("value");
	    System.out.println("Actual Postal Code: " + actualPostalCode);
	    SoftAssertions softAssertions = new SoftAssertions();
	    softAssertions.assertThat(actualPostalCode).isEqualTo(postalCode).as("Postal code is incorrect");
	    softAssertions.assertAll();
	    sauceDemoPage.clickContinue();
	}


	// Test to verify that clicking the "Continue" button on the cart page redirects to checkout-step-two page.
	@Test(priority = 15)
	public void testContinueButtonRedirection1() {
	    // Wait for the cart page to load
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
	    WebElement ContinuetBtn = wait.until(ExpectedConditions.elementToBeClickable(sauceDemoPage.continueButton));

	    Actions actions = new Actions(driver);
	    actions.moveToElement(ContinuetBtn).click().build().perform();
	    // Verify redirection to the checkout-step-two page
	    String expectedURL = "https://www.saucedemo.com/checkout-step-two.html";
	    String actualURL = driver.getCurrentUrl();
	    System.out.println("Actual URL after clicking Continue: " + actualURL);
	    SoftAssertions softAssertions = new SoftAssertions();
	    softAssertions.assertThat(actualURL).isEqualTo(expectedURL).as("Redirection to Checkout Step Two page failed");
	    softAssertions.assertAll();
	}

	
	// Test to verify that clicking the "Finish" button redirects to the checkout-complete page.
	@Test(priority = 16)
	public void testFinishButtonRedirection() {
	    String expectedURL = "https://www.saucedemo.com/checkout-complete.html";
	    String actualURL = driver.getCurrentUrl();
	    SoftAssertions softAssertions = new SoftAssertions();
	    softAssertions.assertThat(actualURL.equals(expectedURL));
	    softAssertions.assertAll();
	}


	// Test to verify that clicking the "Home" button redirects to the home page.
	@Test(priority = 17)
	public void testHomeButtonRedirection() {
	    String expectedURL = "https://www.saucedemo.com/";
	    String actualURL = driver.getCurrentUrl();
	    SoftAssertions softAssertions = new SoftAssertions();
	    softAssertions.assertThat(actualURL.equals(expectedURL));
	    softAssertions.assertAll();
	}

	@AfterTest
	public void tearDown() {
		// Close the browser
		driver.quit();
	}
}
