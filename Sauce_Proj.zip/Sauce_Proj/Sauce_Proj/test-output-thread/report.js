$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"a4bb6da5-9bf1-4cda-b005-1c0d62be2b84","feature":"Login page feature","scenario":"Login page title","start":1691593909736,"group":1,"content":"","tags":"","end":1691593914167,"className":"passed"},{"id":"20fb4d7d-4ca1-462e-aaa1-e8ad56374e3c","feature":"Login page feature","scenario":"Login with correct credentials","start":1691593914181,"group":1,"content":"","tags":"","end":1691593918063,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});