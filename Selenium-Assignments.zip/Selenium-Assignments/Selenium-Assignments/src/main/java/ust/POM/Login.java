package ust.POM;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import ust.Base.BaseUI;

public class Login extends BaseUI {
	WebDriver driver;
	public Login(WebDriver driver) {
		this.driver=driver;
	}
	By username=getlocator("username_name");
	By password=getlocator("pass_name");
	By submit=getlocator("submit_id");
	//elements as methods
	public void userName(String user) {
		sendtext(username, user);
	}
	public void passWord(String pass) {
		isElementPresent(password,Duration.ofSeconds(15));
		sendtext(password, pass);
	}
	public void submit() {
		clickOn(submit);
	}

}
