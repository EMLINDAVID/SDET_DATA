package ust.Selenium_Assignments;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import ust.Base.BrowserConfig;

public class Newsite {
	@Test
	public void test1() {
		WebDriver driver;
		driver=BrowserConfig.getBrowser();
		driver.get("http://wwww.automationpractice.pl/index.php?controller=authentication&back=my-account");
		System.out.println(driver.getTitle());
	}

}
