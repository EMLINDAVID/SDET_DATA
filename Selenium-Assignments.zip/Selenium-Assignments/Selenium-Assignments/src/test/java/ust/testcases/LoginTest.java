package ust.testcases;

import static org.junit.Assert.*;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import ust.Utilities.Excelutils;

import ust.Base.BaseUI;
import ust.POM.Login;

public class LoginTest extends BaseUI{
	WebDriver driver;
	//Login login;
	String[][] data;
	@BeforeMethod
	public void setup(){
		driver=invokebrowser();
		openBrowser("applicationURL");

	}
	@DataProvider(name = "testData")
	public Object[][] testdata(){
		data= Excelutils.testdata();
		return data;
	}
	@Test(priority =1,dataProvider = "testData")
	public void loginTest(String username,String password,String text) {
		Login login=new Login(driver);
		login.userName(username);
		login.passWord(password);
		login.submit();
		if(username.equals("Incorrect Username")) {
			SoftAssertions.assertSoftly(softAssertions -> {
	            softAssertions.assertThat(driver.findElement(By.className("show")).isDisplayed());
	            // Verify Deposit Successful msg is displayed
	     
	        });
		}
		else if(password.equals("Incorrect Password")) {
			SoftAssertions.assertSoftly(softAssertions -> {
	            softAssertions.assertThat(driver.findElement(By.className("show")).isDisplayed());
	            // Verify error message text is Your password is invalid!
	     
	        });
		}
		else {
			 // Verify new page URL contains practicetestautomation.com/logged-in-successfully/
			 SoftAssertions.assertSoftly(softAssertions -> {
			 softAssertions.assertThat(driver.getCurrentUrl().contains("practicetestautomation.com/logged-in-successfully/"));
			 softAssertions.assertThat(driver.findElement(By.xpath("//*[contains(text(), '" + text + "')]")).isDisplayed());
			 // Verify logout is displayed
			 softAssertions.assertThat(driver.findElement(By.xpath("//*[@id=\"loop-container\"]/div/article/div[2]/div/div/div/a")).isDisplayed());
				});

	}
}
}
