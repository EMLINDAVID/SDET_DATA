package com.ust.POM;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.Base.BaseUI;

public class CatPage extends BaseUI {

	WebDriver driver;

	public CatPage(WebDriver driver) {

		this.driver = driver;

	}

	By clickCat = getlocator("dropcat_id");

	By groomClick = getlocator("groomclick_xpath");

	By brandClick = getlocator("brand_xpath");

	By biogroomClick = getlocator("biogroom_xpath");

	By productClick = getlocator("product_xpath");

	By productQuantityClick = getlocator("productQuantity_xpath");

	By addToCartClick = getlocator("addToCart_xpath");

	By cartViewclick = getlocator("ViewCart_xpath");
	By homepage=getlocator("homepage_xpath");

	public void performMouseOver() {

		mouseOver(clickCat);

	}

	public Boolean dropDown() {

		mouseOver(clickCat);

		return true;

	}

	public Boolean linkText() {

		mouseOver(clickCat);

		return true;

	}

	public void performClick() {

		clickOn(groomClick);

	}

	public void performBrandClick() {

		clickOn(brandClick);

	}

	public void PerformBioClick() {

		clickOn(biogroomClick);

	}

	public void PerformProductClick() {

		clickOn(productClick);

	}

	public void performQuantityClick() {

		clickOn(productQuantityClick);

	}

	public void performAddToCartClick() {

		clickOn(addToCartClick);

	}

	public void performCartView() {

		clickOn(cartViewclick);

	}
	public void homePage() {
		clickOn(homepage);
	}

	public String getTile() {
		return driver.getTitle();
	}

	public void mouseover2() {
	driver.findElement(By.xpath("//input[@id='mainfrm']")).sendKeys("Cat");
	driver.findElement(By.xpath("//div[@class='header-item header-item--search show_on_compres']//button[@class='text-link site-header__search-btn site-header__search-btn--submit active']")).click();
	}
}
