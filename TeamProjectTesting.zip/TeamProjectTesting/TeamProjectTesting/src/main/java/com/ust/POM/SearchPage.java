package com.ust.POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ust.Base.BaseUI;

public class SearchPage extends BaseUI {
	WebDriver driver;

	public SearchPage() {
		this.driver = driver;
	}

	// locators
	By searchinput = getlocator("searchinput_xpath");
	By searchclick = getlocator("searchbutton_xpath");
	By clickprice = getlocator("clickprice_xpath");
	By clickpricerange = getlocator("clickpricerange_xpath");
	By clickpopularity = getlocator("clickdropdown_xpath");
	By clickhightolow = getlocator("clickhightolow_xpath");
	By clickproduct = getlocator("clickproduct_xpath");
	By quantityadd = getlocator("quantityadd_xpath");
	By addtocart = getlocator("addtocart_xpath");
	By cartview = getlocator("cartview_xpath");
	By homepage = getlocator("homepage_xpath");

	// elements as method
	public void searchInput(String text) {
		sendtext(searchinput, text);
	}

	public void searchClick() {
		clickOn(searchclick);
	}

	public void clickPrice() {
		clickOn(clickprice);
	}

	public void clickPricerange() {
		clickOn(clickpricerange);
	}

	public void clickPopularity() {
		clickOn(clickpopularity);
	}

	public void clickHighToLow() {
		clickOn(clickhightolow);
	}

	public void clickProduct() {
		clickOn(clickproduct);
	}

	public void quantityAdd() {
		clickOn(quantityadd);
	}

	public void addToCart() {
		clickOn(addtocart);
	}

	public void cartView() {
		clickOn(cartview);
	}

	public void homePage() {
		clickOn(homepage);
	}

	public String productText() {
		return gettext(clickproduct);
	}
}
