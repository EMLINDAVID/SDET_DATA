package stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import com.ust.Base.BrowserConfig;
import com.ust.POM.CatPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class LoginSteps {
	public static String title;
	public WebDriver driver=BrowserConfig.getchromeBrowser();
	public CatPage login=new CatPage(driver);
	@Given("user is on login page")
	public void user_is_on_login_page() {
		driver.get("https://supertails.com");
	    
	}

	@When("user gets the title of page")
	public void user_gets_the_title_of_page() {
		title=login.getTile();
	    
	}

	@Then("page title be {string}")
	public void page_title_be(String string) {
		title=login.getTile();
		Assert.assertEquals(title,string);
	    
	}
	@When("user moves mouse over cat")
	public void user_moves_mouse_over_cat() {
		login.mouseover2();
	}
	@Then("goto new page {string}")
	public void goto_new_page(String string) {
		String page=driver.getCurrentUrl();
		   System.out.println(page);
		   Assert.assertEquals(page,string);
	    
	}
}
