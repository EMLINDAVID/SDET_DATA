package testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.Base.BaseUI;
import com.ust.POM.CatPage;
import com.ust.POM.Dog1;
import com.ust.POM.SearchPage;

@Listeners(com.ust.utilities.SampleListener.class)
public class SearchTest extends BaseUI {
	@BeforeTest
	public void setup() {
		driver = invokebrowser();
		openBrowser("applicationURL");
	}

	/***************** search scenario Test *****************/

	@Test(priority = 1)
	public void searchboxTest() {
		SearchPage sp = new SearchPage();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//input[@id='mainfrm']")).isDisplayed());
		});
	}

	@Test(priority = 2)
	public void checkUrlTest() throws InterruptedException {
		SearchPage sp = new SearchPage();
		sp.searchInput("cat dry food");
		sp.searchClick();
		String expectedUrl = "https://supertails.com/pages/search-results-1?q=cat%20dry%20food";
		driver.get(expectedUrl);
		String actualUrl = driver.getCurrentUrl();
		Assert.assertEquals(actualUrl, expectedUrl);
		if (actualUrl.equals(actualUrl)) {
			sp.clickPrice();
			sp.clickPricerange();
			Thread.sleep(1000);
		}
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//*[@id=\"facet-price\"]/button[5]")).isEnabled());
		});
		sp.clickPopularity();
		Thread.sleep(1000);
		sp.clickHighToLow();
		 Thread.sleep(1000);
	}

	@Test(priority = 3)
	public void checkProductNameTest() throws InterruptedException {
		SearchPage sp = new SearchPage();
		String txt=sp.productText();
		SoftAssertions.assertSoftly(softAssertions -> {
		softAssertions.assertThat(txt.contains("cat dry food"));
		});
		
	}

	@Test(priority = 4)
	public void popupTest() throws InterruptedException {
		SearchPage sp = new SearchPage();
		sp.clickProduct();
		sp.quantityAdd();
		sp.addToCart();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@class='cart__scrollable']")).isDisplayed());
		});
	}

	@Test(priority = 5)
	public void quantityAndRemovebuttonTest() throws InterruptedException {
		SearchPage sp = new SearchPage();
		
		sp.cartView();
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath(
					"//input[@class='MuiInputBase-input MuiOutlinedInput-input MuiInputBase-inputAdornedStart MuiInputBase-inputAdornedEnd css-1gnht4k']"))
					.getText().equals(2));
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath(
					"//*[contains(@src,'https://cdn.shopify.com/s/files/1/0565/8021/0861/files/trash.svg?v=1688468818')]"))
					.isDisplayed());
		});
		sp.homePage();
		
	}

	/***************** cat scenario Test *****************/

	@Test(priority = 6)

	public void checkCat() {

		CatPage c = new CatPage(driver);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("nav--Cats")).getText().contains("cat"));
		});
		c.performMouseOver();
	}

	@Test(priority = 7)

	public void DropdownTest() throws InterruptedException {
		CatPage c = new CatPage(driver);
		c.dropDown();
		Boolean drop = c.dropDown();
		Assert.assertTrue(drop);
		
		c.performClick();
	}

	@Test(priority = 8)

	public void checkEntry() throws InterruptedException {

		CatPage c = new CatPage(driver);
		String expectedURL = "https://supertails.com/collections/cat-grooming-products";
		driver.get(expectedURL);
		String actualURL = driver.getCurrentUrl();
		Assert.assertEquals(actualURL, expectedURL, "URLs do match");
		if (actualURL.equals(expectedURL)) {
			
			c.performBrandClick();
			c.PerformBioClick();
			System.out.println("Test Passed: The URL is as expected");
		}
	}

	@Test(priority = 9)

	public void checkBox() throws InterruptedException {
		CatPage c = new CatPage(driver);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath(
					"//button[@class='findify-components--button findify-components-common--checkbox__item'][4]"))
					.isEnabled());
		});
		c.PerformProductClick();
		c.performQuantityClick();
		c.performAddToCartClick();
		c.performCartView();
		//System.out.println("");

	}

	@Test(priority = 10)

	public void addToCart() throws InterruptedException {
		CatPage c = new CatPage(driver);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@class='cart__scrollable']")).isDisplayed());
		});
		c.performAddToCartClick();

	}

	@Test(priority = 11)

	public void checkQuantity() throws InterruptedException {
		CatPage c = new CatPage(driver);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver
					.findElements(By.xpath("//button[@class='js-qty__adjust js-qty__adjust--plus'][1]")).equals(2));

		});
		c.homePage();

	}

	/*****************************
	 * Dog scenario Test
	 *********************************/
	@Test(priority = 12)

	public void checkdog() {

		Dog1 dog = new Dog1(driver);

		SoftAssertions.assertSoftly(softAssertions -> {

			softAssertions.assertThat(driver.findElement(By.id("nav--Dogs")).getText().contains("dog"));

		});

		dog.performMouseOver();

	}

	@Test(priority = 13)

	public void dropDown() throws InterruptedException {

		Dog1 dog = new Dog1(driver);

		dog.dropDown();

		Boolean drop = dog.dropDown();

		Assert.assertTrue(drop);


		dog.dogclothing();

	}

	@Test(priority = 14)

	public void entryTest() throws InterruptedException {

		Dog1 dog = new Dog1(driver);
		String expURL = "https://supertails.com/collections/dog-clothes";
		driver.get(expURL);
		String actualURL = driver.getCurrentUrl();
		Assert.assertEquals(actualURL, expURL);
		if (actualURL.equals(expURL)) {
			dog.performBrandClick();
			dog.brandvalueClick();

		}

	}

	@Test(priority = 15)

	public void checkbox() throws InterruptedException {
		Dog1 dog = new Dog1(driver);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(
					driver.findElement(By.xpath("//*[@id=\"facet-custom_fields.custom_brand\"]/section/button[1]"))
							.isEnabled());
		});

		dog.productClick();
		dog.productsizeClick();
		dog.productqtyClick();
		dog.addcartClick();
	}

	@Test(priority = 16)

	public void checkpopup() throws InterruptedException {

		Dog1 dog = new Dog1(driver);

		SoftAssertions.assertSoftly(softAssertions -> {

			softAssertions.assertThat(driver.findElement(By.xpath("//div[@class='cart__scrollable']")).isDisplayed());

		});

		dog.cartClick();
	}
}
