package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Base.BaseUI;
import Utilities.Excelutility2;

public class BankLogin extends BaseUI {
WebDriver driver;
	
	public BankLogin(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
//	By managerLogin=getlocator("managerbanklogin_xpath");
////	By customerlog=getlocator("coustomerlogin_xpath");
//	By addcus=getlocator("addcustomer_xpath");
//	By firstName=getlocator("firstname_xpath");
//	By lastName=getlocator("lastname_xpath");
//	By post=getlocator("post_xpath");
//	By submit=getlocator("submit_xpath");
//	By OpenAccount=getlocator("openaccount_xpath");
//	By CustomerNamedropdown=getlocator("customernamedropdown_id");
//	By CurrencyDropDown=getlocator("currencydropdown_id");
//	By ProcessOpenAccount=getlocator("processopenaccount_xpath");
//	By CustomerLast=getlocator("customerlast_xpath");
//	By CustomerSearch=getlocator("customersearch_xpath");
//	By CustomerDelete=getlocator("customerdelete_xpath");
//	By Homebtn2=getlocator("Homebtn2_xpath");
	
	
//	managerbanklogin_xpath=//button[text()='Bank Manager Login']
//			addcustomer_xpath=//button[contains(@ng-class,'btnClass1')]
//			firstname_xpath=//input[contains(@ng-model,'fName')]
//			lastname_xpath=//input[contains(@ng-model,'lName')]
//			post_xpath=//input[contains(@ng-model,'postCd')]
//			submit_xpath=//button[text()='Add Customer']
//			openaccount_xpath=//button[contains(@ng-click,'openAccount()')]
//			customernamedropdown_id=userSelect
//			currencydropdown_id=currency
//			processopenaccount_xpath=//button[text()='Process']
//			customerlast_xpath=//button[@ng-click='showCust()']
//			customersearch_xpath=//input[@ng-model='searchCustomer']
//			customerdelete_xpath=//button[text()='Delete']
//			Homebtn2_xpath=//button[@class='btn home']

	
			@FindBy(xpath = "//button[text()='Bank Manager Login']")
			WebElement managerLogin;
			
			@FindBy(xpath = "//button[contains(@ng-class,'btnClass1')]")
			WebElement addcus;
			
			@FindBy(xpath = "///input[contains(@ng-model,'fName')]")
			WebElement firstName;
			
			@FindBy(xpath = "//input[contains(@ng-model,'lName')]")
			WebElement lastName;
			
			@FindBy(xpath = "//input[contains(@ng-model,'postCd')]]")
			WebElement post;
			
			@FindBy(xpath = "//button[text()='Add Customer']")
			WebElement submit;
			
			@FindBy(xpath = "///button[contains(@ng-click,'openAccount()')]")
			WebElement OpenAccount;
			
			@FindBy(id = "userSelect")
			WebElement CustomerNamedropdown;
			
			@FindBy(id = "currency")
			WebElement CurrencyDropDown;
			
			@FindBy(xpath = "//button[text()='Process']")
			WebElement ProcessOpenAccount;
			
			@FindBy(xpath = "//button[@ng-click='showCust()']")
			WebElement CustomerLast;
			
			@FindBy(xpath = "//input[@ng-model='searchCustomer']")
			WebElement CustomerSearch;
			
			@FindBy(xpath = "//button[@ng-click='showCust()']")
			WebElement CustomerDelete;
			
			@FindBy(xpath = "//button[@class='btn home']")
			WebElement Homebtn2;
	
	
	
	
	
	
	
	
	
	
	String name="anu";
	public void manager() {
 clickOn(managerLogin);
	}
//	public void customer() {
// clickon(customerlog);
//	}
//	
	public void addcustomer() {
 clickOn(addcus);
	}
	public void firstName(String firstname) {
 sendtext(firstName, firstname);
	}
	public void lastname(String lastname) {
 sendtext(lastName, lastname);
	}
	
	public void postcode(String postcode) {
 sendtext(post, postcode);
	}
	public void submit() {
 clickOn(submit);
	}
	public void openaccount() {
		 clickOn(OpenAccount);
			}
			
			public void customernamedropdown(String name) {
				dropDownHandling(CustomerNamedropdown, name);
			}
			
			public void currencydropdown() {
				getText(CurrencyDropDown);
			}
			
			public void processopenaccount() {
		 clickOn(ProcessOpenAccount);
			}
			
			public void customerlast() {
		 clickOn(CustomerLast);
			}
			
			public void customersearch() {
		 sendtext(CustomerSearch, name);
			}
			
			public void customerdelete() {
		 clickOn(CustomerDelete);
			}
			public void  Home2() {
				clickOn(Homebtn2);
			}
			
			public void alert()
			{
				getTextfromAlertandAccept();
			}
			
}


