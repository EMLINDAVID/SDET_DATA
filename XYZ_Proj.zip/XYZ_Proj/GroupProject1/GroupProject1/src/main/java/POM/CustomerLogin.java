package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import Base.BaseUI;

public class CustomerLogin extends BaseUI{

	WebDriver driver;
	public CustomerLogin(WebDriver driver) {
		this.driver=driver;
	}
//	By Custlog=getlocator("custlog_xpath");
//	By yourname=getlocator("yourname_name");
//	By yournamelogin=getlocator("Login_xpath");
//	By number=getlocator("Number_name");
//	By transac=getlocator("Trans_xpath");
//	By back=getlocator("back_xpath");
//	By depo=getlocator("Deposit_xpath");
//	By amount=getlocator("Depositamnt_xpath");
//	By depobtn=getlocator("Depositbtn_xpath");
//	//By withdraw=getlocator("Wthrawal_xpath");
//	By withamount=getlocator("Withamnt_xpath");
//	//By withbtn=getlocator("Withbtn_xpath");
//	By Homebtn=getlocator("Homebtn_xpath");
//	By logout=getlocator("logout_xpath");
	
//			custlog_xpath=//button[text()='Customer Login']
//			yourname_name=userSelect
//			Login_xpath=//button[@class='btn btn-default']
//			Number_name=accountSelect
			//Trans_xpath=//button[@class='btn btn-lg tab'][@ng-class='btnClass1']
			//back_xpath=//button[@class='btn']
			//Deposit_xpath=//button[@class='btn btn-lg tab'][@ng-click='deposit()']
			//Depositamnt_xpath=//input[@type='number']
			//Depositbtn_xpath=//button[@class='btn btn-default']
			//Wthrawal_xpath=//button[@class='btn btn-lg tab'][@ng-click='withdrawl()']
			//Withamnt_xpath=//input[@type='number']
			//Withbtn_xpath=//button[@class='btn btn-default']
			//Homebtn_xpath=//button[@class='btn home']
			//logout_xpath=//button[contains(@ng-show,'logout')]
	//Welcome_xpath=//span[text()='Harry Potter']
	//DepoMsg_xpath=//span[contains(@ng-show,'message')]
	//Blance_xpath=//strong[contains(@class,'ng-binding')]
	
	
	
			@FindBy(xpath = "//button[text()='Customer Login']")
			WebElement Custlog;
			
			@FindBy(name = "userSelect")
			WebElement yourname;
			
			@FindBy(xpath = "//button[@class='btn btn-default']")
			WebElement yournamelogin;
			
			@FindBy(xpath = "accountSelect")
			WebElement number;
			
			@FindBy(xpath = "//button[@class='btn btn-lg tab'][@ng-class='btnClass1']")
			WebElement transac;
			
			@FindBy(xpath = "//button[@class='btn']")
			WebElement back;
			
			@FindBy(xpath = "//button[@class='btn btn-lg tab'][@ng-click='deposit()']")
			WebElement depo;
			
			@FindBy(xpath = "//input[@type='number']")
			WebElement amount;
			
			@FindBy(xpath = "//button[@class='btn btn-default']")
			WebElement depobtn;
			
			@FindBy(xpath = "//button[@class='btn btn-lg tab'][@ng-click='withdrawl()']")
			WebElement withdraw;
			
			@FindBy(xpath = "//input[@type='number']")
			WebElement withamount;
			
			@FindBy(xpath= "//button[@class='btn btn-default']")
			WebElement withbtn;
			
			@FindBy(xpath = "//button[@class='btn home']")
			WebElement Homebtn;
			
			@FindBy(xpath= "//button[contains(@ng-show,'logout')]")
			WebElement logout;
	
	
	
	
	
	
	public void YourName() {
		getText(yourname);
	}
	public void getnum() {
		getText(number);
	}
	public void Custlog() {
		clickOn(Custlog);
	}
	public void YourNameLogin() {
		clickOn(yournamelogin);
	}
	public void Trans() {
		clickOn(transac);
	}
	public void Back() {
		clickOn(back);
	}
	public void Deposit() {
		clickOn(depo);
	}
	public void Amount() {
		getText(amount);
	}
	public void DepoBtn() {
		clickOn(depobtn);
	}
	public void Withdraw() {
		clickOn(withdraw);
	}
	public void WithAmount() {
		getText(withamount);
	}
	public void WithBtn() {
		clickOn(withbtn);
	}
	
	public void  Home() {
		clickOn(Homebtn);
	}
	public void logout() {
		clickOn(logout);
	}
	public void custloginButn() {
		driver.findElement(By.xpath("//button[text()='Customer Login']")).click();
	}
	public void loginbtnclick() {
		try {
		WebElement dd=driver.findElement(By.xpath("userSelect"));
		   Select s=new Select(dd);
		   s.selectByIndex(2);
		driver.findElement(By.xpath("//button[@class='btn btn-default']")).click();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}