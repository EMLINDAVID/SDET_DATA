package TestCase;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import Base.BaseUI;
import POM.BankLogin;
import POM.CustomerLogin;
import Utilities.Excelutility2;
@Listeners(Utilities.SampleListener.class)
public class BankTest extends BaseUI {
	public static WebDriver driver;
	BankLogin login;
	
	String[][] data;
	
	By Homebtn=getlocator("Homebtn2_xpath");
	By Homebtn2=getlocator("Homebtn_xpath");
	By logoutbtn=getlocator("logout_xpath");
	By Welcomebtn=getlocator("Welcome_xpath");
	By depomsg=getlocator("DepoMsg_xpath");
	By balancemsg=getlocator("Blance_xpath");
	
	@BeforeTest
	public void setup(){
 driver=invokebrowser();
 openBrowser("applicationURL");
 driver.manage().window().maximize();
 }
	@DataProvider(name = "testData")
	public Object[][] testdata(){
 data= Excelutility2.testdata();
 return data;
	}
	
	@Test(priority=0)
	public void ManagerloginTest() {
		BankLogin login=new BankLogin(driver);
		String expectedURL = "https://www.globalsqa.com/angularJs-protractor/BankingProject/#/login";
		 driver.get(expectedURL);
		 String actualURL = driver.getCurrentUrl();
		 Assert.assertEquals(actualURL, expectedURL, "URLs do match!");
		 login.manager();
		 	}
	@Test(priority=1,dataProvider="testData")
	public void managerlog(String firstname,String lastname,String pcode) {
 BankLogin login=new BankLogin(driver);
 SoftAssertions.assertSoftly(softAssertions -> {
     softAssertions.assertThat(driver.findElement(Homebtn).isDisplayed());
     // Verify home button is displayed
}); 

 login.addcustomer();
 login.firstName(firstname);
 login.lastname(lastname);
 login.postcode(pcode);
 login.submit();
 login.alert();
	String alertmsg=getTextfromAlertandAccept();
	 login.switchToAlertAccept();
	 SoftAssertions.assertSoftly(softAssertion->{
	 softAssertion.assertThat(alertmsg.equalsIgnoreCase("This user already exist."));
	 });
	logger.log(Status.INFO, "customer name selected successfully");

 
	}
 
	@Test(priority=2)
 public void OpenAccount() {
	 BankLogin login=new BankLogin(driver);
       login.openaccount();
       login.customernamedropdown(browserChoice);
		login.currencydropdown();
		login.processopenaccount();
		login.alert();
		String alertmsg=getTextfromAlertandAccept();
		 login.switchToAlertAccept();
		 SoftAssertions.assertSoftly(softAssertion->{
		 softAssertion.assertThat(alertmsg.equalsIgnoreCase("This user already exist."));
		 });
		logger.log(Status.INFO, "customer name selected successfully");
 }
	
	@Test(priority=3)
 public void CustomerTest() {
    BankLogin login=new BankLogin(driver);
	login.customerlast();
	login.customersearch();
	login.customerdelete();
	login.Home2();
	}
	
}