package TestCase;

import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import org.testng.annotations.Test;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Base.BaseUI;
import Base.BrowserConfig;
import POM.CustomerLogin;

@Listeners(Utilities.SampleListener.class)
public class CustomerLoginTest extends BaseUI {

	public static WebDriver driver;
	CustomerLogin login;
	String[][] data;
	
	By Homebtn=getlocator("Homebtn_xpath");
	By logoutbtn=getlocator("logout_xpath");
	By welcomebtn=getlocator("Welcome_xpath");
	By depomsg=getlocator("DepoMsg_xpath");
	By balancemsg=getlocator("Blance_xpath");
	
	@BeforeTest
	
	public static WebDriver invokebrowser() {
		 browserChoice=prop.getProperty("browserName");
		 if(browserChoice.equalsIgnoreCase("chrome")) {
		 driver=BrowserConfig.getBrowser();
		 }
		 return driver;
			}
	@Test(priority=0)
	public void CustomerloginTest()  {
		CustomerLogin login=new CustomerLogin(driver);
		String expectedURL = "https://www.globalsqa.com/angularJs-protractor/BankingProject/#/login";
		 driver.get(expectedURL);
		 String actualURL = driver.getCurrentUrl();
		 Assert.assertEquals(actualURL, expectedURL, "URLs do match!");
		 if(actualURL.equals(expectedURL)) {

		System.out.println("Test Passed: The URL is as expected.");
		 } else {
		 System.out.println("Test Failed: The URL is not as expected.");
		 }
		login.Custlog();
		logger.log(Status.INFO, "Login successfully");
		
}
	@Test(priority=1)
public void YourNameTest() {
	CustomerLogin login=new CustomerLogin(driver);
	login.YourName();
}
	
	
	@Test(priority=2)
	public void YourNameLoginTest() throws InterruptedException {
		CustomerLogin login=new CustomerLogin(driver);
		login.YourNameLogin();
		SoftAssertions.assertSoftly(softAssertions -> {
            softAssertions.assertThat(driver.findElement(Homebtn).isDisplayed());
            // Verify home button is displayed
});
SoftAssertions.assertSoftly(softAssertions -> {
            softAssertions.assertThat(driver.findElement(logoutbtn).isDisplayed());
            // Verify logout button is displayed
});

SoftAssertions.assertSoftly(softAssertions -> {
    softAssertions.assertThat(driver.findElement(welcomebtn).isDisplayed());
    // Verify Name is displayed
});



		
	}
	
	@Test(priority=3)
	public void getNumberTest()  {
		CustomerLogin login=new CustomerLogin(driver);
		login.getnum();
		
	}
	@Test(priority=4)
	public void TransTest() throws InterruptedException {
		CustomerLogin login=new CustomerLogin(driver);
		login.Trans();
	    login.Back();
	    login.Deposit();
	   login.Amount();
	   login.DepoBtn();
	   SoftAssertions.assertSoftly(softAssertions -> {
           softAssertions.assertThat(driver.findElement(depomsg).isDisplayed());
           // Verify Deposit Successful msg is displayed
});
	   SoftAssertions.assertSoftly(softAssertions -> {
           softAssertions.assertThat(driver.findElement(balancemsg).isDisplayed());
           // Verify Correct  Balance is displayed
});
	   
	   
	   
	}
	@Test(priority=5)
	public void WithdrawTest()  {
		CustomerLogin login=new CustomerLogin(driver);
		login.Withdraw();
		login.WithAmount();
		login.WithBtn();
		
		
//		login.Back();
		

		}
	@Test(priority=6)
	public void TransTest1() {
		CustomerLogin login=new CustomerLogin(driver);
		login.Trans();
	
}
	@Test(priority=7)
	public void logoutTest1() {
		CustomerLogin login=new CustomerLogin(driver);
		login.logout();
		String expectedURL = "https://www.globalsqa.com/angularJs-protractor/BankingProject/#/customer";
		 driver.get(expectedURL);
		 String actualURL = driver.getCurrentUrl();
		 Assert.assertEquals(actualURL, expectedURL, "URLs do match!");
     	
}
	@Test(priority=8)
	public void HomeTest() {
		CustomerLogin login=new CustomerLogin(driver);
		login.Home();
     	String expectedURL = "https://www.globalsqa.com/angularJs-protractor/BankingProject/#/login";
		 driver.get(expectedURL);
		 String actualURL = driver.getCurrentUrl();
		 Assert.assertEquals(actualURL, expectedURL, "URLs do match!");
	}
}
