package stepDefinition;


import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import Base.BaseUI;
import Base.BrowserConfig;
import POM.CustomerLogin;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps {
	public static String title;
	public WebDriver driver=BrowserConfig.getBrowser();
	public CustomerLogin l1=new CustomerLogin(driver);
	
	
	@Given("user is on login page")
	public void user_is_on_login_page() {
		driver.get("https://www.globalsqa.com/angularJs-protractor/BankingProject/#/login");
	    
	}

	@When("user gets the title of page")
	public void user_gets_the_title_of_page() {
	    title=driver.getTitle();
	    
	}

	@Then("page title be {string}")
	public void page_title_be(String string) {
		title=driver.getTitle();
		Assert.assertEquals(title,string);
	   
	}
	@When("user clicks login button")
	public void user_clicks_login_button() {
		l1.Custlog();
	   
	}

	@When("click name")
	public void click_name() {
		l1.loginbtnclick();
	  
	}

	@Then("goto page {string}")
	public void goto_page(String string) {
		String page=driver.getCurrentUrl();
		Assert.assertEquals(page,string);
	    
	}
}
