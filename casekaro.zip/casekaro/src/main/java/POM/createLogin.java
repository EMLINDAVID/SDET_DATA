package POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import Base.BaseUI;



public class createLogin extends BaseUI{
	WebDriver driver;
	createLogin createlogin;
	public createLogin(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath ="//a[@class='site-header__icon site-header__account']")
	WebElement Login;
	
	@FindBy(id ="customer_register_link")
	WebElement CreateAcc;
	
	@FindBy(id ="FirstName")
	WebElement firstname;
	
	@FindBy(id ="LastName")
	WebElement lastname;
	
	@FindBy(id ="Email")
	WebElement email;
	
	@FindBy(id ="CreatePassword")
	WebElement password;
	
	@FindBy(xpath ="//input[@value='Create']")
	WebElement createButton;
	
	@FindBy(xpath ="//div[@class='recaptcha-checkbox-border']")
	WebElement checkBox;
	
	@FindBy(xpath ="//a[@class='site-header__icon site-header__account']")
	WebElement checkBoxSubmit;
	
	@FindBy(xpath ="//a[@class='site-header__icon site-header__account']")
	WebElement LoginNext;
	
	@FindBy(id ="CustomerEmail")
	WebElement loginemail;
	
	@FindBy(id ="CustomerPassword")
	WebElement loginpassword;
	
	@FindBy(xpath ="//input[@value='Sign In']")
	WebElement loginsubmit;
	
	public void  loginacc() {
		clickOn(Login);	
	}
	
	public void  createacc() {
		clickOn(CreateAcc);	
	}
	
	public void  FirstName(String first) {
		sendtext(firstname, first);	
	}
	
	public void  LastName(String last) {
		sendtext(lastname, last);	
	}
	
	public void  Email(String email1) {
		sendtext(email, email1);	
	}
	
	public void  Password(String pass) {
		sendtext(password, pass);	
	}
	
	public void  createbutton() {
		clickOn(createButton);	
	}

	public void  checkbox() {
		clickOn(checkBox);	
	}

	public void  checkSubmit() {
		clickOn(checkBoxSubmit);	
	}
	
	public void  loginnext() {
		clickOn(LoginNext);	
	}
	
	public void  loginemail(String email) {
		sendtext(loginemail, email);	
	}
	
	public void  loginpassword(String pass) {
		sendtext(loginpassword, pass);	
	}
	
	public void  loginSubmit() {
		clickOn(loginsubmit);	
	}
}
