$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"dabcac91-f00c-4e68-9620-e46bef4d3f22","feature":"Login page feature","scenario":"Login with correct credentials","start":1692876857683,"group":1,"content":"","tags":"","end":1692876874646,"className":"passed"},{"id":"0cc17906-6fce-4577-b31d-94323ebb3596","feature":"Login page feature","scenario":"Login page title","start":1692876846497,"group":1,"content":"","tags":"","end":1692876857666,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});