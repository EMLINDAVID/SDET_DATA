package endpoints;

import UserModel.Model;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class endpoints {
	
	public static Response createUser(Model payload)
	{
		RestAssured.useRelaxedHTTPSValidation();
		Response response=RestAssured.given()
				.baseUri(Route_commerce .baseuri)
				.basePath(Route_commerce .post_basePath)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.post();
		return response;
	}
	 public static Response  getUser(int ide)
	 {
		 RestAssured.useRelaxedHTTPSValidation();
		 Response response=RestAssured.given()
					.baseUri(Route_commerce .baseuri)
					.basePath(Route_commerce .get_basePath)
					.pathParam("id",ide)
					.contentType("application/json")
					.accept(ContentType.JSON)
					.when()
					.get();
		 return response;
	 }
	 public static Response deleteUser(int ide)
		{
		 RestAssured.useRelaxedHTTPSValidation();
			Response response=RestAssured.given()
					.baseUri(Route_commerce .baseuri)
					.basePath(Route_commerce .delete_basePath)
					.pathParam("id",ide)
					.contentType("application/json")
					.accept(ContentType.JSON)
					.when()
					.delete();
			return response;
		}
	 public static Response updateUser(int  ide,Model payload)
		{
		 RestAssured.useRelaxedHTTPSValidation();
			Response response=RestAssured.given()
					.baseUri(Route_commerce .baseuri)
					.basePath(Route_commerce .update_basePath)
					.pathParam("id",ide)
					.contentType("application/json")
					.accept(ContentType.JSON)
					.body(payload)
					.when()
					.put();
			return response;
		}

}
