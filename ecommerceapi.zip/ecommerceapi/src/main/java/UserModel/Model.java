package UserModel;


public class Model {
	private String placeid;
	private String address;
	private String key;
	public String getPlaceid() {
	return placeid;
	}
	public void setPlaceid(String placeid) {
	this.placeid = placeid;
	}
	public String getAddress() {
	return address;
	}
	public void setAddress(String address) {
	this.address = address;
	}
	public String getKey() {
	return key;
	}
	public void setKey(String key) {
	this.key = key;
	}
}
