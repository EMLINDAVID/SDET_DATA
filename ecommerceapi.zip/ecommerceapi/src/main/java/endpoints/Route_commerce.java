package endpoints;

public class Route_commerce {

	public static String baseuri="https://rahulshettyacademy.com";
//	public static String post_basePath="/api/v1/create";
//	public static String get_basePath="/products/{id}";
//	public static String delete_basePath="/products/{id}";
	public static String update_basePath="/maps/api/place/update/json";
}