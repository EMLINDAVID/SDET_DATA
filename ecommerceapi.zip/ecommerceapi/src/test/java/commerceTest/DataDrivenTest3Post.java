//package commerceTest;
//
//
//import org.testng.Assert;
//import org.testng.annotations.Listeners;
//import org.testng.annotations.Test;
//
//import UserModel.Model;
//import Utilities.DataProviders;
//import endpoints.endpoints;
////import endpoints.endpoints2;
////import endpoints.endpoints;
//import io.restassured.RestAssured;
//import io.restassured.response.Response;
//
//@Listeners(Utilities.ExtentReportManager.class)
//
//public class DataDrivenTest3Post {
//
//	@Test()
//	public void testPostUser() {
//		RestAssured.useRelaxedHTTPSValidation();
//		Model user = new Model();
//
//		user.setName("test");
//		user.setSalary("salary");
//		user.setAge("23");
//
//		Response response = endpoints.createUser(user);
//		response.then().log().all();
//		Assert.assertEquals(response.getStatusCode(), 200);
//	}
//}
//
//	