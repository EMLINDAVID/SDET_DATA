
package commerceTest;


import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import UserModel.Model;
import Utilities.DataProviders;
import endpoints.endpoints;
//import endpoints.endpoints2;
//import endpoints.endpoints;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

@Listeners(Utilities.ExtentReportManager.class)

public class DataDrivenTest4Put {

//	
//	 @Test()
//	    public void testUpdateuserById()
//	   {
//		   //RestAssured.useRelaxedHTTPSValidation();
//		   Model  user=new Model ();
//		   
//			user.place_id("ec829b9361c80a59dba195279c00cd30");
//			user.address("70 Summer walk, USA");
//			user.key("qaclick123");
////			{
////
////				"place_id":"ec829b9361c80a59dba195279c00cd30",
////
////				"address":"70 Summer walk, USA",
////
////				"key":"qaclick123"
////
////				}
//
//				 
//			
//			
//		   Response response = endpoints.updateUser(user);
//	        response.then().log().all();
//	        Assert.assertEquals(response.getStatusCode(),200);
//	   }
//	putTest
	
	@Test()
	public void testUpdateuserById(){
	    String baseUrl = "https://rahulshettyacademy.com/maps/api/place/update/json";

	   
	    String requestBody = "{\n" +
	            "\"place_id\":\"ec829b9361c80a59dba195279c00cd30\",\n" +
	            "\"address\":\"70 Summer walk, USA\",\n" +
	            
	            "}";

	    RestAssured.given().relaxedHTTPSValidation()
	            .contentType(ContentType.JSON)
	            .queryParam("key", "qaclick123")
	            .body(requestBody)
	            .when()
	            .put(baseUrl)
	            .then()
	            .statusCode(200); // You can adjust the expected status code

	    System.out.println("Place updated successfully!");
	}
}
