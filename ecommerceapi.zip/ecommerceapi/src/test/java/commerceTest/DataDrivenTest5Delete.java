
//package commerceTest;
//
//
//import org.testng.Assert;
//import org.testng.annotations.Listeners;
//import org.testng.annotations.Test;
//
//import UserModel.Model;
//import Utilities.DataProviders;
//import endpoints.endpoints;
////import endpoints.endpoints2;
////import endpoints.endpoints;
//import io.restassured.RestAssured;
//import io.restassured.response.Response;
//
//@Listeners(Utilities.ExtentReportManager.class)
//
//public class DataDrivenTest5Delete {
//
//	
//	@Test()
//	public void testDeleteById() {
//		Response response = endpoints.deleteUser();
//		response.then().log().all();
//		Assert.assertEquals(response.getStatusCode(), 200);
//	}
//
//}
