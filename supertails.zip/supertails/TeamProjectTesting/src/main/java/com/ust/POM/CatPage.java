package com.ust.POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.ust.Base.BaseUI;

public class CatPage extends BaseUI {

	WebDriver driver;

	public CatPage(WebDriver driver) {

		this.driver = driver;

	}

	By clickCat = getlocator("dropcat_id");

	By groomClick = getlocator("groomclick_xpath");

	By brandClick = getlocator("brand_xpath");

	By biogroomClick = getlocator("biogroom_xpath");

	By productClick = getlocator("product_xpath");

	By productQuantityClick = getlocator("productQuantity_xpath");

	By addToCartClick = getlocator("addToCart_xpath");

	By cartViewclick = getlocator("ViewCart_xpath");
	By homepage=getlocator("homepage_xpath");

	public void performMouseOver() {

		mouseOver(clickCat);

	}

	public Boolean dropDown() {

		mouseOver(clickCat);

		return true;

	}

	public Boolean linkText() {

		mouseOver(clickCat);

		return true;

	}

	public void performClick() {

		clickOn(groomClick);

	}

	public void performBrandClick() {

		clickOn(brandClick);

	}

	public void PerformBioClick() {

		clickOn(biogroomClick);

	}

	public void PerformProductClick() {

		clickOn(productClick);

	}

	public void performQuantityClick() {

		clickOn(productQuantityClick);

	}

	public void performAddToCartClick() {

		clickOn(addToCartClick);

	}

	public void performCartView() {

		clickOn(cartViewclick);

	}
	public void homePage() {
		clickOn(homepage);
	}

}
