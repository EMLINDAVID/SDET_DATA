package com.ust.POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.ust.Base.BaseUI;

public class Dog1 extends BaseUI {

	WebDriver driver;

	public Dog1(WebDriver driver) {

		this.driver = driver;

	}

	By clickDog = getlocator("dropdog_id");
	By dogclothing = getlocator("dogclothing_xpath");
	By brandClick = getlocator("brand1_xpath");
	By brandvalueClick = getlocator("brandvalue_xpath");
	By productClick = getlocator("product1_xpath");
	By productsizeClick = getlocator("productsize_xpath");
	By productqtyClick = getlocator("productqty_xpath");
	By addcartClick = getlocator("addcart_xpath");
	By cartClick = getlocator("cart_id");
	By homepage=getlocator("homepage_xpath");

	public void performMouseOver() {
		mouseOver(clickDog);
	}

	public Boolean dropDown()

	{
		mouseOver(clickDog);
		return true;
	}

	public Boolean linkText() {
		mouseOver(clickDog);
		return true;
	}

	public void dogclothing() {
		clickOn(dogclothing);
	}

	public void performBrandClick() {
		clickOn(brandClick);
	}

	public void brandvalueClick() {
		clickOn(brandvalueClick);
	}

	public void productClick() {
		clickOn(productClick);
	}

	public void productsizeClick() {
		clickOn(productsizeClick);
	}

	public void productqtyClick() {
		clickOn(productqtyClick);
	}

	public void addcartClick() {
		clickOn(addcartClick);
	}

	public void cartClick() {
		clickOn(cartClick);
	}
	public void homePage() {
		clickOn(homepage);
	}

}
