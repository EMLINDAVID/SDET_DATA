package testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.ust.Base.BaseUI;
import com.ust.POM.Dog1;

public class Dog1test extends BaseUI {

	WebDriver driver;

	@BeforeTest

	public void setup() {

		driver = invokebrowser();

		openBrowser("applicationURL");

	}

	@Test(priority = 1)

	public void checkdog() {

		Dog1 dog = new Dog1(driver);

		SoftAssertions.assertSoftly(softAssertions -> {

			softAssertions.assertThat(driver.findElement(By.id("nav--Dogs")).getText().contains("dog"));

		});

		dog.performMouseOver();

	}

	@Test(priority = 2)

	public void dropDown() throws InterruptedException {

		Dog1 dog = new Dog1(driver);

		dog.dropDown();

		Boolean drop = dog.dropDown();

		Assert.assertTrue(drop);

		Thread.sleep(2000);

		dog.dogclothing();

	}

	@Test(priority = 3)

	public void entryTest() throws InterruptedException {

		Dog1 dog = new Dog1(driver);
		String expURL = "https://supertails.com/collections/dog-clothes";
		driver.get(expURL);
		String actualURL = driver.getCurrentUrl();
		Assert.assertEquals(actualURL, expURL);
		if (actualURL.equals(expURL)) {
			Thread.sleep(3000);
			dog.performBrandClick();
			Thread.sleep(3000);
			dog.brandvalueClick();
			Thread.sleep(2000);

		}

	}

	@Test(priority = 4)

	public void checkbox() throws InterruptedException {
		Dog1 dog = new Dog1(driver);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(
					driver.findElement(By.xpath("//*[@id=\"facet-custom_fields.custom_brand\"]/section/button[1]"))
							.isEnabled());
		});

		dog.productClick();
		Thread.sleep(3000);
		dog.productsizeClick();
		Thread.sleep(3000);
		dog.productqtyClick();
		Thread.sleep(3000);
		dog.addcartClick();

	}

	@Test(priority = 5)

	public void checkpopup() throws InterruptedException {

		Dog1 dog = new Dog1(driver);

		SoftAssertions.assertSoftly(softAssertions -> {

			softAssertions.assertThat(driver.findElement(By.xpath("//div[@class='cart__scrollable']")).isDisplayed());

		});

		Thread.sleep(5000);

		dog.cartClick();

	}

	@Test(priority = 6)

	public void checkqty() throws InterruptedException {

		Dog1 dog = new Dog1(driver);

		SoftAssertions.assertSoftly(softAssertions -> {

			softAssertions.assertThat(driver.findElement(By.xpath(
					"//*[@id=\"app\"]/div/div/div/div[4]/div/div[1]/div/div/div/div[1]/div[2]/div[2]/div/div/div"))
					.equals(2));

		});

		Thread.sleep(5000);

	}

}