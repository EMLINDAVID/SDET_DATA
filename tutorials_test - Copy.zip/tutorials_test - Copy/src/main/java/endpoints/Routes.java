package endpoints;

public class Routes {

	
	public static String baseuri="http://localhost:8080";
	public static String post_basePath="/api/tutorials";
	public static String get_basePath="/api/tutorials";
	public static String getid_basePath="/api/tutorials/{id}";
	public static String deleteid_basePath="/tutorials/{id}";
	public static String deleteall_basePath="/tutorials";
	public static String delete_basePath="/api/tutorials/{id}";
	public static String update_basePath="/api/tutorials/{id}";
	
}
