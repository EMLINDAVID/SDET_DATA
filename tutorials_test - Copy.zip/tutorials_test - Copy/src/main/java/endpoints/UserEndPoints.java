package endpoints;

import payload.UserModel;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class UserEndPoints {

	
	public static Response createUser(UserModel payload) {
		//RestAssured.useRelaxedHTTPSValidation();
		Response response=RestAssured.given().baseUri(Routes.baseuri).
				basePath(Routes.post_basePath)
				.contentType("application/json").
				accept(ContentType.JSON).body(payload).when().post();
		
		return response;
	}
	public static Response getUserbyId(String id) {
		RestAssured.useRelaxedHTTPSValidation();

		Response response=RestAssured.given().baseUri(Routes.baseuri).
				basePath(Routes.getid_basePath)
				.pathParam("id",id).
				contentType("application/json").accept(ContentType.JSON)
				.when().get();
		
		return response;
	}
	public static Response getUser()
	{
		RestAssured.useRelaxedHTTPSValidation();
		Response response = RestAssured.given()
				.baseUri(Routes.baseuri)
				.basePath(Routes.get_basePath)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;
	}
	
	public static Response deleteUser(String id) {
		RestAssured.useRelaxedHTTPSValidation();

		Response response=RestAssured.given().baseUri(Routes.baseuri).
				basePath(Routes.delete_basePath)
				.pathParam("id", id).
				contentType("application/json").accept(ContentType.JSON)
				.when().delete();
		
		return response;
	}
	
//	public static Response updateUserbyid(String username,UserModel payload) {
//		RestAssured.useRelaxedHTTPSValidation();
//
//		Response response=RestAssured.given().baseUri(Routes.baseuri).
//				basePath(Routes.update_basePath)
//				.pathParam("username", username).
//				contentType("application/json").accept(ContentType.JSON).body(payload)
//				.when().put();
//		
//		return response;
//	}
	public static Response updateUser(String id,UserModel payload) {
		RestAssured.useRelaxedHTTPSValidation();

		Response response=RestAssured.given().baseUri(Routes.baseuri).
				basePath(Routes.update_basePath)
				.pathParam("id", id).
				contentType("application/json").accept(ContentType.JSON).body(payload)
				.when().put();
		
		return response;
	}
	
//	public static Response loginuser(UserModel payload) {
//		RestAssured.useRelaxedHTTPSValidation();
//		Response response=RestAssured.given().baseUri(Routes.baseuri).
//				basePath(Routes.getlogin_basePath).body(payload).when().get();
//		return response;
//		
//	}
//	
//	public static Response logoutuser(UserModel payload) {
//		RestAssured.useRelaxedHTTPSValidation();
//		Response response=RestAssured.given().baseUri(Routes.baseuri).
//				basePath(Routes.getlogout_basePath).body(payload).when().get();
//		return response;
//		
//	}
}
