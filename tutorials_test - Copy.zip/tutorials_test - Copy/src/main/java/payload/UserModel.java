package payload;

public class UserModel {


	private String title;
	private String descripton;
	private boolean publisher;
	public boolean isPublisher() {
		return publisher;
	}
	public void setPublisher(boolean publisher) {
		this.publisher = publisher;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getDescripton() {
		return descripton;
	}
	public void setDescripton(String descripton) {
		this.descripton = descripton;
	}
}
